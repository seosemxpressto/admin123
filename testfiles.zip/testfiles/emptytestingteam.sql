-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.6.31-log - MySQL Community Server (GPL)
-- Server OS:                    Win64
-- HeidiSQL Version:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping structure for table testingteam.amazon_credentials_info
CREATE TABLE IF NOT EXISTS `amazon_credentials_info` (
  `amazon_credentials_info_id` int(11) NOT NULL,
  `access_key` varchar(50) DEFAULT NULL,
  `secret_key` varchar(50) DEFAULT NULL,
  `bucket_name` varchar(50) DEFAULT NULL,
  `status_id` int(11) NOT NULL,
  PRIMARY KEY (`amazon_credentials_info_id`),
  KEY `FKamazon_credentials_status_id` (`status_id`),
  CONSTRAINT `FKamazon_credentials_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT=' ';

-- Data exporting was unselected.


-- Dumping structure for table testingteam.amc_euipmentplacein_master
CREATE TABLE IF NOT EXISTS `amc_euipmentplacein_master` (
  `equipment_place_id` int(11) NOT NULL AUTO_INCREMENT,
  `eq_description` varchar(50) DEFAULT NULL,
  `status_id` int(11) DEFAULT NULL,
  `hospital_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`equipment_place_id`),
  KEY `equip_status_id` (`status_id`),
  KEY `FK_f226un69b39iukamynnsnypdv` (`hospital_id`),
  CONSTRAINT `FK_f226un69b39iukamynnsnypdv` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `equip_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.amc_inventory_details
CREATE TABLE IF NOT EXISTS `amc_inventory_details` (
  `amc_id` int(10) NOT NULL,
  `equipment_name` varchar(50) NOT NULL,
  `date_of_purchase` date NOT NULL,
  `amount` double(20,2) DEFAULT NULL,
  `deprecation` varchar(50) DEFAULT NULL,
  `warranty_year` varchar(50) DEFAULT NULL,
  `amc_status` char(1) DEFAULT NULL,
  `renewal_date` date DEFAULT NULL,
  `equipment_placed_location` int(11) DEFAULT NULL,
  `No_of_units` int(50) NOT NULL DEFAULT '-1',
  `supplier_id` int(10) DEFAULT NULL,
  `remainder_days` varchar(255) DEFAULT NULL,
  `amc_yes_no_id` int(11) DEFAULT NULL,
  `loan_selef_id` int(11) DEFAULT NULL,
  `status_id` int(11) DEFAULT NULL,
  `email_id` varchar(50) DEFAULT NULL,
  `Notes` varchar(250) DEFAULT NULL,
  `warrenty_month` varchar(250) DEFAULT NULL,
  `agency_name` varchar(250) DEFAULT NULL,
  `contact_person` varchar(250) DEFAULT NULL,
  `mobile_no` varchar(50) DEFAULT NULL,
  `hospital_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`amc_id`),
  KEY `supplierId_Fk` (`supplier_id`),
  KEY `FK_a6cw8dq9mkf4yecfiavjmiu4f` (`amc_yes_no_id`),
  KEY `FK_o6pl0rk363xgseh3i7p7l93ej` (`loan_selef_id`),
  KEY `FK_ixehhu61mai3gwj818vdt3jem` (`status_id`),
  KEY `equip_place_area` (`equipment_placed_location`),
  CONSTRAINT `FK_a6cw8dq9mkf4yecfiavjmiu4f` FOREIGN KEY (`amc_yes_no_id`) REFERENCES `yes_no_master` (`yes_no_master_id`),
  CONSTRAINT `FK_ixehhu61mai3gwj818vdt3jem` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_o6pl0rk363xgseh3i7p7l93ej` FOREIGN KEY (`loan_selef_id`) REFERENCES `loan_self_master` (`loan_selef_id`),
  CONSTRAINT `equip_place_area` FOREIGN KEY (`equipment_placed_location`) REFERENCES `amc_euipmentplacein_master` (`equipment_place_id`),
  CONSTRAINT `supplierId_Fk` FOREIGN KEY (`supplier_id`) REFERENCES `supplier_detailsmaster` (`supplier_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.amc_remainder_days
CREATE TABLE IF NOT EXISTS `amc_remainder_days` (
  `amc_remaider_id` int(11) NOT NULL AUTO_INCREMENT,
  `remainder_value` int(11) NOT NULL DEFAULT '0',
  `status_id` int(11) DEFAULT NULL,
  `amc_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`amc_remaider_id`),
  KEY `fk_status_id` (`status_id`),
  KEY `fk_amc_id` (`amc_id`),
  CONSTRAINT `fk_amc_id` FOREIGN KEY (`amc_id`) REFERENCES `amc_inventory_details` (`amc_id`),
  CONSTRAINT `fk_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.annual_year_master
CREATE TABLE IF NOT EXISTS `annual_year_master` (
  `annual_year_master_id` int(8) NOT NULL,
  `annual_year` int(11) NOT NULL,
  `annual_start_date` date NOT NULL,
  `annual_end_date` date NOT NULL,
  `fiscal_start_date` date NOT NULL,
  `fiscal_end_date` date NOT NULL,
  `status_id` int(11) NOT NULL,
  PRIMARY KEY (`annual_year_master_id`),
  KEY `annual_year_status_id` (`status_id`),
  CONSTRAINT `annual_year_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.appointment_details
CREATE TABLE IF NOT EXISTS `appointment_details` (
  `appointment_id` int(8) NOT NULL AUTO_INCREMENT,
  `appointment_token_id` int(8) NOT NULL,
  `appointment_date` date NOT NULL,
  `cycle_status` char(1) NOT NULL,
  `payment_status` char(1) DEFAULT 'N',
  `fees_paid` double(10,2) DEFAULT '0.00',
  `hospital_id` int(8) NOT NULL,
  `user_id` int(8) NOT NULL,
  `appointment_time_id` int(8) DEFAULT NULL,
  `duration_id` int(8) DEFAULT NULL,
  `service_map_id` int(8) NOT NULL,
  `appointment_name` varchar(50) NOT NULL,
  `contact_no` varchar(20) NOT NULL,
  `gender_id` int(11) DEFAULT NULL,
  `emp_id` int(11) NOT NULL,
  `age` int(11) DEFAULT '0',
  `status_id` int(11) NOT NULL DEFAULT '0',
  `appointment_time` varchar(50) DEFAULT '0',
  `doctor_fee` double(10,2) DEFAULT '0.00',
  `hospital_fee` double(10,2) DEFAULT '0.00',
  `app_receipt_no` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`appointment_id`),
  KEY `FK_appointment_details_hospital_id` (`hospital_id`),
  KEY `FK_appointment_details_user_id` (`user_id`),
  KEY `FK5_appointment_timeId` (`appointment_time_id`),
  KEY `FK_appointment_details_duration_id` (`duration_id`),
  KEY `FK_appointment_details_emp_id` (`emp_id`),
  KEY `FK_appointment_details_gender_id` (`gender_id`),
  KEY `FK_appointment_details_service_id` (`service_map_id`),
  KEY `FK_appointment_details_status_id` (`status_id`),
  CONSTRAINT `FK5_appointment_timeId` FOREIGN KEY (`appointment_time_id`) REFERENCES `time_master_details` (`time_master_Id`),
  CONSTRAINT `FK_appointment_details_duration_id` FOREIGN KEY (`duration_id`) REFERENCES `duration_master` (`duration_Id`),
  CONSTRAINT `FK_appointment_details_emp_id` FOREIGN KEY (`emp_id`) REFERENCES `emp_info` (`emp_id`),
  CONSTRAINT `FK_appointment_details_gender_id` FOREIGN KEY (`gender_id`) REFERENCES `gender_master` (`gender_id`),
  CONSTRAINT `FK_appointment_details_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_appointment_details_service_id` FOREIGN KEY (`service_map_id`) REFERENCES `doctor_service_map` (`doctor_service_EmpId`),
  CONSTRAINT `FK_appointment_details_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_appointment_details_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.appointment_info
CREATE TABLE IF NOT EXISTS `appointment_info` (
  `appointment_info_id` int(11) NOT NULL AUTO_INCREMENT,
  `cycle_status` char(50) DEFAULT NULL,
  `serviceMap_id` int(11) NOT NULL,
  `patient_map_Id` int(11) NOT NULL,
  `book_master_id` int(11) NOT NULL,
  `appointment_times_details_id` int(11) NOT NULL,
  `hospital_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `notes` varchar(500) DEFAULT NULL,
  `opd_number` varchar(500) DEFAULT NULL,
  `lastUpdated` datetime NOT NULL,
  PRIMARY KEY (`appointment_info_id`),
  KEY `appointment_info_serviceMapId` (`serviceMap_id`),
  KEY `appointment_info_booing_master_id` (`book_master_id`),
  KEY `appointment_info_appointment_times_details_id` (`appointment_times_details_id`),
  KEY `appointment_info_hospital_id` (`hospital_id`),
  KEY `appointment_info_user_id` (`user_id`),
  KEY `appointment_info_status_id` (`status_id`),
  KEY `appointment_info_patientmap_id` (`patient_map_Id`),
  CONSTRAINT `appointment_info_appointment_times_details_id` FOREIGN KEY (`appointment_times_details_id`) REFERENCES `appointment_times_details` (`appointment_times_details_Id`),
  CONSTRAINT `appointment_info_booing_master_id` FOREIGN KEY (`book_master_id`) REFERENCES `booking_status_master` (`booking_status_master_id`),
  CONSTRAINT `appointment_info_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `appointment_info_patientmap_id` FOREIGN KEY (`patient_map_Id`) REFERENCES `patient_map` (`patient_fees_payment_map_id`),
  CONSTRAINT `appointment_info_serviceMapId` FOREIGN KEY (`serviceMap_id`) REFERENCES `service_empmap_details` (`app_service_empmap_id`),
  CONSTRAINT `appointment_info_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `appointment_info_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.appointment_schedule_details
CREATE TABLE IF NOT EXISTS `appointment_schedule_details` (
  `appointment_schedule_details_id` int(11) NOT NULL AUTO_INCREMENT,
  `appointment_date` date NOT NULL,
  `cycle_status` char(1) NOT NULL,
  `payment_status` char(1) NOT NULL DEFAULT 'N',
  `service_map_id` int(11) NOT NULL,
  `from_time` varchar(50) NOT NULL,
  `to_atime` varchar(50) NOT NULL,
  `dateOfBirth` varchar(50) DEFAULT NULL,
  `contact_no` varchar(50) DEFAULT NULL,
  `emp_id` int(11) NOT NULL,
  `age` int(11) DEFAULT NULL,
  `note` varchar(50) DEFAULT NULL,
  `hospital_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `app_receipt_no` varchar(50) DEFAULT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `status_id` int(11) NOT NULL,
  `last_updated` datetime NOT NULL,
  `patientfees_payment_mapId` int(11) NOT NULL,
  `appointment_name` varchar(255) DEFAULT NULL,
  `gender_id` int(11) NOT NULL,
  PRIMARY KEY (`appointment_schedule_details_id`),
  KEY `FK_appoint_schdeule_empid` (`emp_id`),
  KEY `FK_appoint_schdeule_hospital_id` (`hospital_id`),
  KEY `FK_appoint_schdeule_user_id` (`user_id`),
  KEY `FK_appoint_schdeule_status_id` (`status_id`),
  KEY `FK_appoint_schdeule_service_map_id` (`service_map_id`),
  KEY `FK_appoint_schedule_patient_id` (`patient_id`),
  KEY `FK_appoint_schedule_patientfees_paymentmapId` (`patientfees_payment_mapId`),
  KEY `FK_k8oreqdaev9asa2vymelnv00t` (`gender_id`),
  CONSTRAINT `FK_appoint_schdeule_empid` FOREIGN KEY (`emp_id`) REFERENCES `emp_info` (`emp_id`),
  CONSTRAINT `FK_appoint_schdeule_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_appoint_schdeule_service_map_id` FOREIGN KEY (`service_map_id`) REFERENCES `service_empmap_details` (`app_service_empmap_id`),
  CONSTRAINT `FK_appoint_schdeule_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_appoint_schdeule_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`),
  CONSTRAINT `FK_appoint_schedule_patient_id` FOREIGN KEY (`patient_id`) REFERENCES `patient_personal_details` (`patient_id`),
  CONSTRAINT `FK_appoint_schedule_patientfees_paymentmapId` FOREIGN KEY (`patientfees_payment_mapId`) REFERENCES `patient_map` (`patient_fees_payment_map_id`),
  CONSTRAINT `FK_k8oreqdaev9asa2vymelnv00t` FOREIGN KEY (`gender_id`) REFERENCES `gender_master` (`gender_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.appointment_times_details
CREATE TABLE IF NOT EXISTS `appointment_times_details` (
  `appointment_times_details_Id` int(11) NOT NULL AUTO_INCREMENT,
  `from_time` varchar(50) DEFAULT NULL,
  `to_time` varchar(50) DEFAULT NULL,
  `appointment_type` int(11) NOT NULL,
  `appointmentOrBlockDate` date NOT NULL,
  `emp_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `hospital_id` int(11) NOT NULL,
  PRIMARY KEY (`appointment_times_details_Id`),
  KEY `appointment_times_details_typeId` (`appointment_type`),
  KEY `appointment_times_details_status_id` (`status_id`),
  KEY `appointment_times_details_hospital_id` (`hospital_id`),
  KEY `appointment_times_details_emp_id` (`emp_id`),
  CONSTRAINT `appointment_times_details_emp_id` FOREIGN KEY (`emp_id`) REFERENCES `emp_info` (`emp_id`),
  CONSTRAINT `appointment_times_details_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `appointment_times_details_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `appointment_times_details_typeId` FOREIGN KEY (`appointment_type`) REFERENCES `appointment_type_master` (`appointment_block_master_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.appointment_type_master
CREATE TABLE IF NOT EXISTS `appointment_type_master` (
  `appointment_block_master_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(50) NOT NULL DEFAULT '0',
  `status_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`appointment_block_master_id`),
  KEY `appointment_block_master_status_id` (`status_id`),
  CONSTRAINT `appointment_block_master_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.attendance_details
CREATE TABLE IF NOT EXISTS `attendance_details` (
  `attendance_details_id` int(8) NOT NULL,
  `attendance_setup_id` int(8) NOT NULL,
  `emp_id` int(8) NOT NULL,
  `shift_id` int(8) NOT NULL,
  `attendance_status_id` int(8) NOT NULL,
  `leave_status` char(5) NOT NULL DEFAULT 'N',
  `time_in` varchar(10) DEFAULT NULL,
  `time_out` varchar(10) DEFAULT NULL,
  `total_hrs` double(5,2) DEFAULT NULL,
  `ot_hrs` double(5,2) DEFAULT NULL,
  `annual_year_id` int(8) NOT NULL,
  `work_on_leave` char(1) NOT NULL DEFAULT 'N',
  `worked_on_leave` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`attendance_details_id`),
  KEY `atteandance_details_setup_id` (`attendance_setup_id`),
  KEY `attendance_details_emp_id` (`emp_id`),
  KEY `attendance_details_shif_id` (`shift_id`),
  KEY `attendance_details_status_id` (`attendance_status_id`),
  KEY `attendance_details_leave_type_id` (`leave_status`),
  KEY `attendance_details_year_id` (`annual_year_id`),
  CONSTRAINT `atteandance_details_setup_id` FOREIGN KEY (`attendance_setup_id`) REFERENCES `attendance_setup` (`attendance_setup_id`),
  CONSTRAINT `attendance_details_emp_id` FOREIGN KEY (`emp_id`) REFERENCES `emp_info` (`emp_id`),
  CONSTRAINT `attendance_details_shif_id` FOREIGN KEY (`shift_id`) REFERENCES `shift_master` (`shift_master_id`),
  CONSTRAINT `attendance_details_status_id` FOREIGN KEY (`attendance_status_id`) REFERENCES `attendance_status_master` (`attendance_status_master_id`),
  CONSTRAINT `attendance_details_year_id` FOREIGN KEY (`annual_year_id`) REFERENCES `annual_year_master` (`annual_year_master_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.attendance_leave_details
CREATE TABLE IF NOT EXISTS `attendance_leave_details` (
  `attendance_leave_details_id` int(8) NOT NULL,
  `attendance_details_id` int(8) NOT NULL,
  `leave_type_id` int(8) NOT NULL,
  PRIMARY KEY (`attendance_leave_details_id`),
  KEY `attendance_leave_parent_details_id` (`attendance_details_id`),
  KEY `attendance_leave_details_type_id` (`leave_type_id`),
  CONSTRAINT `attendance_leave_details_type_id` FOREIGN KEY (`leave_type_id`) REFERENCES `leave_master` (`leave_master_id`),
  CONSTRAINT `attendance_leave_parent_details_id` FOREIGN KEY (`attendance_details_id`) REFERENCES `attendance_details` (`attendance_details_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.attendance_setup
CREATE TABLE IF NOT EXISTS `attendance_setup` (
  `attendance_setup_id` int(8) NOT NULL,
  `attendance_date` date NOT NULL,
  `hospital_id` int(8) NOT NULL,
  `user_id` int(8) NOT NULL,
  `last_updated` datetime NOT NULL,
  PRIMARY KEY (`attendance_setup_id`),
  KEY `attendance_setup_hospital_id` (`hospital_id`),
  KEY `attendance_setup_user_id` (`user_id`),
  CONSTRAINT `attendance_setup_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `attendance_setup_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.attendance_status_master
CREATE TABLE IF NOT EXISTS `attendance_status_master` (
  `attendance_status_master_id` int(1) NOT NULL,
  `attendance_status_code` varchar(5) NOT NULL,
  `attendance_status_desc` varchar(50) NOT NULL,
  `attendance_value` double(3,1) NOT NULL,
  `status_id` int(1) NOT NULL,
  PRIMARY KEY (`attendance_status_master_id`),
  KEY `attendance_master_status_id` (`status_id`),
  CONSTRAINT `attendance_master_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.availability_type_master
CREATE TABLE IF NOT EXISTS `availability_type_master` (
  `availability_type_master_id` int(8) NOT NULL,
  `availability_type_name` varchar(10) NOT NULL,
  `status_id` int(8) NOT NULL,
  PRIMARY KEY (`availability_type_master_id`),
  KEY `FK_availability_type_master_status_id` (`status_id`),
  CONSTRAINT `FK_availability_type_master_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.bank_master
CREATE TABLE IF NOT EXISTS `bank_master` (
  `bank_id` int(8) NOT NULL,
  `bank_name` varchar(200) NOT NULL,
  `status_id` int(8) NOT NULL,
  PRIMARY KEY (`bank_id`),
  KEY `bank_master_status_id` (`status_id`),
  CONSTRAINT `bank_master_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.bed_master
CREATE TABLE IF NOT EXISTS `bed_master` (
  `bed_id` int(8) NOT NULL,
  `room_id` int(8) NOT NULL,
  `bed_desc` varchar(20) NOT NULL,
  `user_id` int(8) NOT NULL,
  `status_id` int(8) NOT NULL,
  `last_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `hospital_id` int(11) NOT NULL,
  PRIMARY KEY (`bed_id`),
  KEY `FK_bed_master_room_id` (`room_id`),
  KEY `FK_bed_master_status_id` (`status_id`),
  KEY `FK_bed_master_user_id` (`user_id`),
  KEY `FK_1psg8ux0qw8cvc7u1xwignqon` (`hospital_id`),
  CONSTRAINT `FK_1psg8ux0qw8cvc7u1xwignqon` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_bed_master_room_id` FOREIGN KEY (`room_id`) REFERENCES `room_master` (`room_id`),
  CONSTRAINT `FK_bed_master_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_bed_master_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.blood_group_master
CREATE TABLE IF NOT EXISTS `blood_group_master` (
  `blood_group_master_id` int(8) NOT NULL AUTO_INCREMENT,
  `blood_group_name` varchar(10) NOT NULL,
  `status_id` int(1) NOT NULL,
  `is_editable_id` int(2) NOT NULL,
  `hospital_id` int(8) NOT NULL,
  `user_id` int(8) NOT NULL,
  PRIMARY KEY (`blood_group_master_id`),
  KEY `FK_blood_group_master_status_id` (`status_id`),
  KEY `FK_blood_group_master_hospital_id` (`hospital_id`),
  KEY `FK_blood_group_master_user_id` (`user_id`),
  KEY `FK_blood_group_master_is_editable` (`is_editable_id`),
  CONSTRAINT `FK_blood_group_master_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_blood_group_master_is_editable` FOREIGN KEY (`is_editable_id`) REFERENCES `is_editable_master` (`is_editable_id`),
  CONSTRAINT `FK_blood_group_master_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_blood_group_master_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.booking_status_master
CREATE TABLE IF NOT EXISTS `booking_status_master` (
  `booking_status_master_id` int(11) NOT NULL,
  `description` varchar(50) NOT NULL,
  `status_id` int(11) NOT NULL,
  PRIMARY KEY (`booking_status_master_id`),
  KEY `booking_status_master_status_id` (`status_id`),
  CONSTRAINT `booking_status_master_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.calendar_settings_master
CREATE TABLE IF NOT EXISTS `calendar_settings_master` (
  `cal_settting_master_id` int(11) NOT NULL AUTO_INCREMENT,
  `week_day_id` int(11) NOT NULL,
  `start_time` varchar(50) DEFAULT NULL,
  `interval_id` int(11) DEFAULT NULL,
  `hospital_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `end_days` int(11) NOT NULL,
  PRIMARY KEY (`cal_settting_master_id`),
  KEY `FK_cal_settings_master_hospital_id` (`hospital_id`),
  KEY `FK_cal_settings_master_status_id` (`status_id`),
  KEY `FK_cal_seetings_master_week_day_id` (`week_day_id`),
  KEY `FK_cal_setting_master_interval_id` (`interval_id`),
  CONSTRAINT `FK_cal_seetings_master_week_day_id` FOREIGN KEY (`week_day_id`) REFERENCES `week_master` (`week_id`),
  CONSTRAINT `FK_cal_setting_master_interval_id` FOREIGN KEY (`interval_id`) REFERENCES `duration_master` (`duration_Id`),
  CONSTRAINT `FK_cal_settings_master_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_cal_settings_master_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.charge_category_master
CREATE TABLE IF NOT EXISTS `charge_category_master` (
  `charge_category_id` int(8) NOT NULL,
  `charge_category_name` varchar(100) NOT NULL,
  `hospital_id` int(8) NOT NULL,
  `user_id` int(8) NOT NULL,
  `status_id` int(1) NOT NULL,
  `last_updated` datetime NOT NULL,
  PRIMARY KEY (`charge_category_id`),
  KEY `FK_charge_category_master_hospital_id` (`hospital_id`),
  KEY `FK_charge_category_master_user_id` (`user_id`),
  KEY `FK_charge_category_master_status_id` (`status_id`),
  CONSTRAINT `FK_charge_category_master_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_charge_category_master_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_charge_category_master_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.charge_item_master
CREATE TABLE IF NOT EXISTS `charge_item_master` (
  `charge_item_id` int(8) NOT NULL,
  `charge_category_id` int(8) NOT NULL,
  `charge_item_name` varchar(100) NOT NULL,
  `charge_item_rate` double(20,2) NOT NULL,
  `status_id` int(1) NOT NULL,
  `last_updated` datetime NOT NULL,
  `hospital_id` int(11) NOT NULL,
  PRIMARY KEY (`charge_item_id`),
  KEY `FK_charge_item_master_category_id` (`charge_category_id`),
  KEY `FK_charge_item_master_status_id` (`status_id`),
  KEY `FK_gemj9guovqhymh7a6pcofefmp` (`hospital_id`),
  CONSTRAINT `FK_charge_item_master_category_id` FOREIGN KEY (`charge_category_id`) REFERENCES `charge_category_master` (`charge_category_id`),
  CONSTRAINT `FK_charge_item_master_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_gemj9guovqhymh7a6pcofefmp` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.check_payement_bank_master
CREATE TABLE IF NOT EXISTS `check_payement_bank_master` (
  `check_bank_id` int(11) NOT NULL AUTO_INCREMENT,
  `bank_name` varchar(25) DEFAULT NULL,
  `account_no` varchar(25) DEFAULT NULL,
  `status_id` int(15) DEFAULT NULL,
  `hospital_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`check_bank_id`),
  KEY `check_status_id` (`status_id`),
  KEY `FK_83dqv0eaq7h3jongkxpfch08x` (`hospital_id`),
  CONSTRAINT `FK_83dqv0eaq7h3jongkxpfch08x` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `check_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.check_payment
CREATE TABLE IF NOT EXISTS `check_payment` (
  `check_payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `check_receipt_no` varchar(25) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `check_bank_id` int(11) NOT NULL,
  `check_payment_bank_id` int(11) NOT NULL,
  `payement_reference_no` varchar(25) DEFAULT NULL,
  `payment_remarks` varchar(25) DEFAULT NULL,
  `payment_amount` double DEFAULT NULL,
  `hospital_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `last_updated` datetime DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL,
  `reason` varchar(250) DEFAULT NULL,
  `emp_id` int(11) DEFAULT NULL,
  `cheque_number` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`check_payment_id`),
  KEY `fk_check_bank_id` (`check_bank_id`),
  KEY `FK_check_bank_master_id` (`check_payment_bank_id`),
  KEY `FK_payemt_status_id` (`status_id`),
  KEY `FK_user_id` (`user_id`),
  KEY `FK_hospital_id` (`hospital_id`),
  KEY `FK_checkpayment_emp_id` (`emp_id`),
  CONSTRAINT `FK_check_bank_master_id` FOREIGN KEY (`check_payment_bank_id`) REFERENCES `check_payement_bank_master` (`check_bank_id`),
  CONSTRAINT `FK_checkpayment_emp_id` FOREIGN KEY (`emp_id`) REFERENCES `emp_office_info` (`emp_id`) ON UPDATE SET NULL,
  CONSTRAINT `FK_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_payemt_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`),
  CONSTRAINT `fk_check_bank_id` FOREIGN KEY (`check_bank_id`) REFERENCES `vocher_bank_mster` (`vocher_bank_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.check_payment_genral
CREATE TABLE IF NOT EXISTS `check_payment_genral` (
  `check_payment_genral_id` int(11) NOT NULL AUTO_INCREMENT,
  `check_receipt_no` varchar(50) NOT NULL,
  `payment_date` date NOT NULL,
  `check_bank_id` int(11) NOT NULL,
  `check_payment_bank_id` int(11) NOT NULL,
  `payement_reference_no` varchar(50) NOT NULL,
  `payment_remarks` varchar(50) NOT NULL,
  `payment_amount` double NOT NULL,
  `hospital_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `last_updated` datetime NOT NULL,
  `name` varchar(50) NOT NULL,
  `reason` varchar(50) NOT NULL,
  `cheque_number` varchar(50) NOT NULL,
  PRIMARY KEY (`check_payment_genral_id`),
  KEY `FK_user_id_genral` (`user_id`),
  KEY `FK_check_genral_status_id` (`status_id`),
  KEY `FK_check_genral_hospital_id` (`hospital_id`),
  KEY `FK_chek_bank_genral_id` (`check_bank_id`),
  KEY `FK_chek_payment_bank_id` (`check_payment_bank_id`),
  CONSTRAINT `FK_check_genral_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_check_genral_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_chek_bank_genral_id` FOREIGN KEY (`check_bank_id`) REFERENCES `vocher_bank_mster` (`vocher_bank_id`),
  CONSTRAINT `FK_chek_payment_bank_id` FOREIGN KEY (`check_payment_bank_id`) REFERENCES `check_payement_bank_master` (`check_bank_id`),
  CONSTRAINT `FK_user_id_genral` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.city_master
CREATE TABLE IF NOT EXISTS `city_master` (
  `city_id` int(8) NOT NULL DEFAULT '0',
  `state_id` int(8) NOT NULL DEFAULT '0',
  `city_name` varchar(100) NOT NULL DEFAULT '',
  `status_id` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`city_id`),
  KEY `FK_city_state_id` (`state_id`),
  KEY `FK_city_status_id` (`status_id`),
  CONSTRAINT `FK_city_state_id` FOREIGN KEY (`state_id`) REFERENCES `state_master` (`state_id`),
  CONSTRAINT `FK_city_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.color_picker
CREATE TABLE IF NOT EXISTS `color_picker` (
  `color_picker_id` int(11) NOT NULL,
  `code` varchar(50) DEFAULT NULL,
  `status_id` int(11) NOT NULL,
  PRIMARY KEY (`color_picker_id`),
  KEY `FK_color_picker_status_id` (`status_id`),
  CONSTRAINT `FK_color_picker_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.common_factor
CREATE TABLE IF NOT EXISTS `common_factor` (
  `common_factor_id` int(11) NOT NULL AUTO_INCREMENT,
  `common_factor_name` varchar(50) NOT NULL,
  `status_id` int(8) NOT NULL,
  `hospital_id` int(11) NOT NULL,
  PRIMARY KEY (`common_factor_id`),
  KEY `FK_common_factor_status_id` (`status_id`),
  KEY `FK_8pyift0b2wdsismra9cmwscyo` (`hospital_id`),
  CONSTRAINT `FK_common_factor_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_common_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.complaint_category_master
CREATE TABLE IF NOT EXISTS `complaint_category_master` (
  `complaint_category_id` int(11) NOT NULL AUTO_INCREMENT,
  `complaint_category_desc` text NOT NULL,
  `hospital_id` int(8) NOT NULL,
  `user_id` int(8) NOT NULL,
  `status_id` int(8) NOT NULL,
  `is_editable_id` int(2) NOT NULL,
  PRIMARY KEY (`complaint_category_id`),
  KEY `FK_compliant_category_master_hospital_master` (`hospital_id`),
  KEY `FK_compliant_category_master_login_master` (`user_id`),
  KEY `FK_compliant_category_master_status_master` (`status_id`),
  KEY `FK_compliant_category_master_is_editable_master` (`is_editable_id`),
  CONSTRAINT `FK_complaint_category_master_hospital_master` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_complaint_category_master_is_editable_master` FOREIGN KEY (`is_editable_id`) REFERENCES `is_editable_master` (`is_editable_id`),
  CONSTRAINT `FK_complaint_category_master_login_master` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`),
  CONSTRAINT `FK_complaint_category_master_status_master` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.complaint_master
CREATE TABLE IF NOT EXISTS `complaint_master` (
  `complaint_id` int(11) NOT NULL AUTO_INCREMENT,
  `complaint_desc` text NOT NULL,
  `complaint_category_id` int(3) NOT NULL,
  `hospital_id` int(8) NOT NULL,
  `user_id` int(8) NOT NULL,
  `status_id` int(8) NOT NULL,
  `is_editable_id` int(2) NOT NULL,
  PRIMARY KEY (`complaint_id`),
  KEY `FK_compliant_master1_hospital_master` (`hospital_id`),
  KEY `FK_compliant_master1_login_master` (`user_id`),
  KEY `FK_compliant_master1_status_master` (`status_id`),
  KEY `FK_compliant_master1_is_editable_master` (`is_editable_id`),
  KEY `FK_complaint_master1_complaint_category` (`complaint_category_id`),
  CONSTRAINT `FK_complaint_master1_complaint_category` FOREIGN KEY (`complaint_category_id`) REFERENCES `complaint_category_master` (`complaint_category_id`),
  CONSTRAINT `FK_complaint_master1_hospital_master` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_complaint_master1_is_editable_master` FOREIGN KEY (`is_editable_id`) REFERENCES `is_editable_master` (`is_editable_id`),
  CONSTRAINT `FK_complaint_master1_login_master` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`),
  CONSTRAINT `FK_complaint_master1_status_master` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.custom_service_setup
CREATE TABLE IF NOT EXISTS `custom_service_setup` (
  `custom_service_id` int(11) NOT NULL AUTO_INCREMENT,
  `service_name` varchar(50) NOT NULL,
  `status_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `hospital_id` int(11) NOT NULL,
  PRIMARY KEY (`custom_service_id`),
  KEY `FK_cutom_service_status_id` (`status_id`),
  KEY `FK_custom_service_user_id` (`user_id`),
  KEY `FK_custom_service_hospital_id` (`hospital_id`),
  CONSTRAINT `FK_custom_service_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_custom_service_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`),
  CONSTRAINT `FK_cutom_service_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.department_master
CREATE TABLE IF NOT EXISTS `department_master` (
  `dept_id` int(11) NOT NULL,
  `dept_long_name` varchar(200) NOT NULL,
  `dept_short_name` varchar(10) DEFAULT NULL,
  `last_updated` datetime NOT NULL,
  `hospital_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `deapt_status_id` int(11) NOT NULL,
  PRIMARY KEY (`dept_id`),
  KEY `FK_5yqobrhrrmxw5w7dytpyyllwo` (`hospital_id`),
  KEY `FK_qarn37e739s5r8h1sgbloyvxp` (`status_id`),
  KEY `FK_6v2jsgojd2hkmj6tw6l53lya4` (`user_id`),
  KEY `FK_dept_satus_id` (`deapt_status_id`),
  CONSTRAINT `FK_5yqobrhrrmxw5w7dytpyyllwo` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_6v2jsgojd2hkmj6tw6l53lya4` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`),
  CONSTRAINT `FK_dept_satus_id` FOREIGN KEY (`deapt_status_id`) REFERENCES `department_status` (`depart_status_id`),
  CONSTRAINT `FK_qarn37e739s5r8h1sgbloyvxp` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.department_status
CREATE TABLE IF NOT EXISTS `department_status` (
  `depart_status_id` int(11) NOT NULL,
  `description` varchar(50) NOT NULL,
  `status_id` int(11) NOT NULL,
  PRIMARY KEY (`depart_status_id`),
  KEY `FK_depatstatus_status_id` (`status_id`),
  CONSTRAINT `FK_depatstatus_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.deposite_details
CREATE TABLE IF NOT EXISTS `deposite_details` (
  `deposite_id` int(11) NOT NULL AUTO_INCREMENT,
  `bank_id` int(11) NOT NULL,
  `date_of_deposite` date NOT NULL,
  `amount` double NOT NULL,
  `status_id` int(11) NOT NULL,
  `hospital_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `deposite_notes` varchar(50) DEFAULT NULL,
  `last_updated` datetime DEFAULT NULL,
  PRIMARY KEY (`deposite_id`),
  KEY `FK_deposite_status_id` (`status_id`),
  KEY `FK_deposite_user_id` (`user_id`),
  KEY `FK_deposite_hospital_id` (`hospital_id`),
  KEY `FK_deposite_bank_id` (`bank_id`),
  CONSTRAINT `FK_deposite_bank_id` FOREIGN KEY (`bank_id`) REFERENCES `check_payement_bank_master` (`check_bank_id`),
  CONSTRAINT `FK_deposite_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_deposite_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_deposite_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.designation_category_master
CREATE TABLE IF NOT EXISTS `designation_category_master` (
  `designation_category_id` int(8) NOT NULL AUTO_INCREMENT,
  `designation_category_name` varchar(200) NOT NULL,
  `user_id` int(8) NOT NULL,
  `status_id` int(8) NOT NULL,
  `last_updated` datetime NOT NULL,
  `hospital_id` int(8) NOT NULL,
  `is_editable_id` int(2) NOT NULL,
  PRIMARY KEY (`designation_category_id`),
  KEY `FK_designation_category_master_user_id` (`user_id`),
  KEY `FK_designation_category_master_status_id` (`status_id`),
  KEY `FK_designation_category_master_hospital_id` (`hospital_id`),
  KEY `FK_designation_category_master_is_editable_id` (`is_editable_id`),
  CONSTRAINT `FK_designation_category_master_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_designation_category_master_is_editable_id` FOREIGN KEY (`is_editable_id`) REFERENCES `is_editable_master` (`is_editable_id`),
  CONSTRAINT `FK_designation_category_master_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_designation_category_master_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.designation_master
CREATE TABLE IF NOT EXISTS `designation_master` (
  `designation_id` int(8) NOT NULL,
  `designation_name` varchar(200) NOT NULL,
  `user_id` int(8) NOT NULL,
  `hospital_id` int(8) NOT NULL,
  `designation_category_id` int(8) NOT NULL,
  `status_id` int(8) NOT NULL,
  `last_updated` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`designation_id`),
  KEY `FK_designation_master_status_id` (`status_id`),
  KEY `FK_designation_master_user_id` (`user_id`),
  KEY `FK_designation_master_hospital_id` (`hospital_id`),
  KEY `FK_designation_master_category_id` (`designation_category_id`),
  CONSTRAINT `FK_designation_master_category_id` FOREIGN KEY (`designation_category_id`) REFERENCES `designation_category_master` (`designation_category_id`),
  CONSTRAINT `FK_designation_master_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_designation_master_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_designation_master_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.diet_master
CREATE TABLE IF NOT EXISTS `diet_master` (
  `diet_id` int(3) NOT NULL AUTO_INCREMENT,
  `diet_desc` text NOT NULL,
  `hospital_id` int(8) NOT NULL,
  `user_id` int(8) NOT NULL,
  `status_id` int(8) NOT NULL,
  `is_editable_id` int(2) NOT NULL,
  PRIMARY KEY (`diet_id`),
  KEY `FK_diet_master_hospital_master` (`hospital_id`),
  KEY `FK_diet_master_login_master` (`user_id`),
  KEY `FK_diet_master_status_master` (`status_id`),
  KEY `FK_diet_master_is_editable_master` (`is_editable_id`),
  CONSTRAINT `FK_diet_master_hospital_master` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_diet_master_is_editable_master` FOREIGN KEY (`is_editable_id`) REFERENCES `is_editable_master` (`is_editable_id`),
  CONSTRAINT `FK_diet_master_login_master` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`),
  CONSTRAINT `FK_diet_master_status_master` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.discharge_form
CREATE TABLE IF NOT EXISTS `discharge_form` (
  `discharge_id` int(20) NOT NULL,
  `ipd_id` int(20) DEFAULT NULL,
  `complaints` longtext,
  `past_history` longtext,
  `family_history` longtext,
  `procedure_done` longtext,
  `investigations` longtext,
  `advice` longtext,
  `user_id` int(20) DEFAULT NULL,
  `hospital_id` int(20) DEFAULT NULL,
  `status_id` int(20) DEFAULT NULL,
  `last_update` datetime DEFAULT NULL,
  `description` longtext,
  `title` varchar(255) DEFAULT NULL,
  `discharge_notes_id` int(11) NOT NULL,
  PRIMARY KEY (`discharge_id`),
  KEY `FK_discharge_form_ipd_id` (`ipd_id`),
  KEY `FK_discharge_form_user_id` (`user_id`),
  KEY `FK_discharge_form_hospital_id` (`hospital_id`),
  KEY `FK_discharge_form_status_id` (`status_id`),
  KEY `FK_9fqx9ub24o2bn84b4w2kkhk0g` (`discharge_notes_id`),
  CONSTRAINT `FK_9fqx9ub24o2bn84b4w2kkhk0g` FOREIGN KEY (`discharge_notes_id`) REFERENCES `discharge_notes_master` (`discharge_notes_id`),
  CONSTRAINT `FK_discharge_form_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_discharge_form_ipd_id` FOREIGN KEY (`ipd_id`) REFERENCES `ipd_info` (`ipd_id`),
  CONSTRAINT `FK_discharge_form_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_discharge_form_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.discharge_notes_master
CREATE TABLE IF NOT EXISTS `discharge_notes_master` (
  `discharge_notes_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` longtext,
  `last_updated` datetime NOT NULL,
  `title` varchar(255) NOT NULL,
  `hospital_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`discharge_notes_id`),
  KEY `FK_l2i6wxrxhnfcxnkwmemugndy4` (`hospital_id`),
  KEY `FK_kc56ctaqr668d8wk4a9qcvvnw` (`status_id`),
  KEY `FK_44mkdrg2h09yfxmnp7vpvbqun` (`user_id`),
  CONSTRAINT `FK_44mkdrg2h09yfxmnp7vpvbqun` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`),
  CONSTRAINT `FK_kc56ctaqr668d8wk4a9qcvvnw` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_l2i6wxrxhnfcxnkwmemugndy4` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.discharge_type_master
CREATE TABLE IF NOT EXISTS `discharge_type_master` (
  `discharge_type_id` int(8) NOT NULL,
  `discharge_type_name` varchar(50) NOT NULL,
  `status_id` int(8) NOT NULL,
  PRIMARY KEY (`discharge_type_id`),
  KEY `FK_discharge_type_master_status_id` (`status_id`),
  CONSTRAINT `FK_discharge_type_master_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.doctor_service_map
CREATE TABLE IF NOT EXISTS `doctor_service_map` (
  `doctor_service_EmpId` int(11) NOT NULL AUTO_INCREMENT,
  `emp_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `service_type_status` char(50) NOT NULL,
  `total_amt` double NOT NULL,
  `hospital_amt` double NOT NULL,
  `doctor_amt` double NOT NULL,
  `depatment_id` int(11) NOT NULL,
  `app_status` char(1) NOT NULL DEFAULT 'N',
  `docPercentage` double DEFAULT NULL,
  `hosPercentage` double DEFAULT NULL,
  PRIMARY KEY (`doctor_service_EmpId`),
  KEY `FK_s6ef29vesxc1x0pxdldosa50p` (`emp_id`),
  KEY `FK_lvu74qk47n4ckh7ffb5wao9yw` (`service_id`),
  KEY `FK_gm43r369cjyvbucdbb5a7akxk` (`status_id`),
  KEY `FK_department_id` (`depatment_id`),
  CONSTRAINT `FK_department_id` FOREIGN KEY (`depatment_id`) REFERENCES `department_master` (`dept_id`),
  CONSTRAINT `FK_gm43r369cjyvbucdbb5a7akxk` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_lvu74qk47n4ckh7ffb5wao9yw` FOREIGN KEY (`service_id`) REFERENCES `doctor_service_master` (`service_Id`),
  CONSTRAINT `FK_s6ef29vesxc1x0pxdldosa50p` FOREIGN KEY (`emp_id`) REFERENCES `emp_info` (`emp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.doctor_service_master
CREATE TABLE IF NOT EXISTS `doctor_service_master` (
  `service_Id` int(11) NOT NULL AUTO_INCREMENT,
  `cost` float DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `service_name` varchar(255) NOT NULL,
  `duration_id` int(11) NOT NULL,
  `hospital_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  PRIMARY KEY (`service_Id`),
  KEY `FK_1bivgrp0c8av5y1tw9ajnqguj` (`duration_id`),
  KEY `FK_higes1bcud8a9bp2o8fxe8sqn` (`hospital_id`),
  KEY `FK_oqdcb9ry9wiclble4wdycqs60` (`status_id`),
  CONSTRAINT `FK_1bivgrp0c8av5y1tw9ajnqguj` FOREIGN KEY (`duration_id`) REFERENCES `duration_master` (`duration_Id`),
  CONSTRAINT `FK_higes1bcud8a9bp2o8fxe8sqn` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_oqdcb9ry9wiclble4wdycqs60` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.dosage_master
CREATE TABLE IF NOT EXISTS `dosage_master` (
  `dosage_master_id` int(11) NOT NULL AUTO_INCREMENT,
  `dosage_name` varchar(255) NOT NULL,
  `hospital_id` int(11) DEFAULT NULL,
  `status_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`dosage_master_id`),
  KEY `FK_al8mqgdo9i2okh9rhknvvati` (`hospital_id`),
  KEY `FK_89fas7qdc9vfdeupjiof55i9l` (`status_id`),
  KEY `FK_msiwl1kuds8my23s4kkwlf8ij` (`user_id`),
  CONSTRAINT `FK_89fas7qdc9vfdeupjiof55i9l` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_al8mqgdo9i2okh9rhknvvati` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_msiwl1kuds8my23s4kkwlf8ij` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.dosage_master_map
CREATE TABLE IF NOT EXISTS `dosage_master_map` (
  `dosage_master_map_id` int(10) NOT NULL,
  `dosage_master_id` int(10) NOT NULL,
  `opd_prescription_details_id` int(10) NOT NULL,
  `staus_id` int(10) NOT NULL,
  PRIMARY KEY (`dosage_master_map_id`),
  KEY `FK_dosage_master_map_dosage_master_id` (`dosage_master_id`),
  KEY `FK_dosage_master_map_status_id` (`staus_id`),
  KEY `FK_dosage_master_map_opd_prescription_details_id` (`opd_prescription_details_id`),
  KEY `FK_druso4028bqerfc06b9lmm9kf` (`opd_prescription_details_id`),
  CONSTRAINT `FK_dosage_master_map_dosage_master_id` FOREIGN KEY (`dosage_master_id`) REFERENCES `dosage_master` (`dosage_master_id`),
  CONSTRAINT `FK_dosage_master_map_status_id` FOREIGN KEY (`staus_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_druso4028bqerfc06b9lmm9kf` FOREIGN KEY (`opd_prescription_details_id`) REFERENCES `opd_prescription_details` (`opd_prescription_details_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.drinking_master
CREATE TABLE IF NOT EXISTS `drinking_master` (
  `drinking_id` int(11) NOT NULL AUTO_INCREMENT,
  `drinking_consume_type` text NOT NULL,
  `hospital_id` int(8) NOT NULL,
  `user_id` int(8) NOT NULL,
  `status_id` int(8) NOT NULL,
  `is_editable_id` int(2) NOT NULL,
  PRIMARY KEY (`drinking_id`),
  KEY `FK_drinking_master_hospital_master` (`hospital_id`),
  KEY `FK_drinking_master_login_master` (`user_id`),
  KEY `FK_drinking_master_status_master` (`status_id`),
  KEY `FK_drinking_master_is_editable_master` (`is_editable_id`),
  CONSTRAINT `FK_drinking_master_hospital_master` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_drinking_master_is_editable_master` FOREIGN KEY (`is_editable_id`) REFERENCES `is_editable_master` (`is_editable_id`),
  CONSTRAINT `FK_drinking_master_login_master` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`),
  CONSTRAINT `FK_drinking_master_status_master` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.drug_master
CREATE TABLE IF NOT EXISTS `drug_master` (
  `drug_master_id` int(11) NOT NULL AUTO_INCREMENT,
  `drug_name` varchar(255) NOT NULL,
  `hospital_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `drug_type_id` int(11) NOT NULL,
  PRIMARY KEY (`drug_master_id`),
  KEY `FK_pks3vkbaacglmfrw2vfthr11d` (`hospital_id`),
  KEY `FK_luwswpr482ni2pgypi20i8s6e` (`user_id`),
  KEY `FK_f7wcpq3d7etip2hs4qvmfilb6` (`status_id`),
  KEY `FK_q56igjm46actow67cua8e9usp` (`drug_type_id`),
  CONSTRAINT `FK_f7wcpq3d7etip2hs4qvmfilb6` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_luwswpr482ni2pgypi20i8s6e` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`),
  CONSTRAINT `FK_pks3vkbaacglmfrw2vfthr11d` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_q56igjm46actow67cua8e9usp` FOREIGN KEY (`drug_type_id`) REFERENCES `drug_type_master` (`drug_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.drug_type_master
CREATE TABLE IF NOT EXISTS `drug_type_master` (
  `drug_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `drug_type_name` varchar(255) NOT NULL,
  `hospital_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`drug_type_id`),
  KEY `FK_hrq0n1x6ilakcn70imjqvilty` (`hospital_id`),
  KEY `FK_4g9vdgs7kxu5gmv0a91entn1k` (`status_id`),
  KEY `FK_iq2raehg003f7d7tyv5d2rp4k` (`user_id`),
  CONSTRAINT `FK_4g9vdgs7kxu5gmv0a91entn1k` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_hrq0n1x6ilakcn70imjqvilty` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_iq2raehg003f7d7tyv5d2rp4k` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.duration_master
CREATE TABLE IF NOT EXISTS `duration_master` (
  `duration_Id` int(11) NOT NULL,
  `duration_value` varchar(255) DEFAULT NULL,
  `status_id` int(11) NOT NULL,
  PRIMARY KEY (`duration_Id`),
  KEY `FK_1f0qxkshf6ega3hfkwx5ckdu6` (`status_id`),
  CONSTRAINT `FK_1f0qxkshf6ega3hfkwx5ckdu6` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.employee_availability_details
CREATE TABLE IF NOT EXISTS `employee_availability_details` (
  `employee_avail_details_id` int(11) NOT NULL AUTO_INCREMENT,
  `week_day_id` int(11) NOT NULL,
  `from_time` varchar(50) NOT NULL,
  `to_time` varchar(50) NOT NULL,
  `avail_status` char(50) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `hospital_id` int(11) NOT NULL,
  PRIMARY KEY (`employee_avail_details_id`),
  KEY `FK_employee_avail_details_week_day_id` (`week_day_id`),
  KEY `FK_employee_avail_details_status_id` (`status_id`),
  KEY `FK_employee_avail_details_emp_id` (`emp_id`),
  KEY `FK_employee_avail_details_hospital_id` (`hospital_id`),
  CONSTRAINT `FK_employee_avail_details_emp_id` FOREIGN KEY (`emp_id`) REFERENCES `emp_info` (`emp_id`),
  CONSTRAINT `FK_employee_avail_details_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_employee_avail_details_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_employee_avail_details_week_day_id` FOREIGN KEY (`week_day_id`) REFERENCES `week_master` (`week_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.employee_break_timings_details
CREATE TABLE IF NOT EXISTS `employee_break_timings_details` (
  `employee_break_time_id` int(11) NOT NULL AUTO_INCREMENT,
  `from_time` varchar(50) DEFAULT NULL,
  `to_time` varchar(50) DEFAULT NULL,
  `employee_week_id` int(11) DEFAULT NULL,
  `emp_id` int(11) NOT NULL,
  `description` varchar(50) DEFAULT NULL,
  `status_id` int(11) DEFAULT NULL,
  `hospital_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`employee_break_time_id`),
  KEY `FK_employee_break_status_id` (`status_id`),
  KEY `FK_employee_break_time_emp_id` (`emp_id`),
  KEY `FK_employee_break_time_hospital_id` (`hospital_id`),
  KEY `FK_employee_break_time_empoyee_week_id` (`employee_week_id`),
  CONSTRAINT `FK_employee_break_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_employee_break_time_emp_id` FOREIGN KEY (`emp_id`) REFERENCES `emp_info` (`emp_id`),
  CONSTRAINT `FK_employee_break_time_empoyee_week_id` FOREIGN KEY (`employee_week_id`) REFERENCES `employee_availability_details` (`employee_avail_details_id`),
  CONSTRAINT `FK_employee_break_time_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.employee_other_income
CREATE TABLE IF NOT EXISTS `employee_other_income` (
  `employee_other_income_id` int(10) NOT NULL AUTO_INCREMENT,
  `emp_id` int(10) NOT NULL,
  `date` date NOT NULL,
  `remarks` varchar(250) NOT NULL,
  `amount` double NOT NULL,
  `status_id` int(10) NOT NULL,
  `payslip_emp_info_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`employee_other_income_id`),
  KEY `FK_employee_other_income_emp_id` (`emp_id`),
  KEY `FK_employee_other_income_status_id` (`status_id`),
  KEY `FKemployee_other_income_payslip_emp_info_id` (`payslip_emp_info_id`),
  CONSTRAINT `FK_employee_other_income_emp_id` FOREIGN KEY (`emp_id`) REFERENCES `emp_info` (`emp_id`),
  CONSTRAINT `FK_employee_other_income_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FKemployee_other_income_payslip_emp_info_id` FOREIGN KEY (`payslip_emp_info_id`) REFERENCES `payslip_emp_info` (`payslip_emp_info_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.emp_account_details
CREATE TABLE IF NOT EXISTS `emp_account_details` (
  `emp_account_details_id` int(8) NOT NULL,
  `emp_id` int(8) NOT NULL,
  `pf_acc_no` varchar(50) DEFAULT NULL,
  `pf_join_date` date DEFAULT NULL,
  `esi_acc_no` varchar(50) DEFAULT NULL,
  `pan_acc_no` varchar(10) DEFAULT NULL,
  `bank_acc_no` varchar(30) DEFAULT NULL,
  `bank_id` varchar(50) DEFAULT NULL,
  `bank_acc_name` varchar(100) DEFAULT NULL,
  `last_updated` datetime NOT NULL,
  `user_id` int(8) NOT NULL,
  `status_id` int(1) NOT NULL,
  PRIMARY KEY (`emp_account_details_id`),
  KEY `emp_account_details_emp_id` (`emp_id`),
  KEY `emp_account_details_user_id` (`user_id`),
  KEY `emp_account_details_status_id` (`status_id`),
  CONSTRAINT `emp_account_details_emp_id` FOREIGN KEY (`emp_id`) REFERENCES `emp_info` (`emp_id`),
  CONSTRAINT `emp_account_details_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `emp_account_details_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.emp_consultant_info
CREATE TABLE IF NOT EXISTS `emp_consultant_info` (
  `emp_consultant_id` int(8) NOT NULL,
  `emp_id` int(8) DEFAULT NULL,
  `consultatnt_prefix_id` varchar(100) DEFAULT NULL,
  `consultatnt_fee` double(10,2) DEFAULT NULL,
  `hospital_id` int(8) DEFAULT NULL,
  `user_id` int(8) DEFAULT NULL,
  `last_update` datetime DEFAULT NULL,
  PRIMARY KEY (`emp_consultant_id`),
  KEY `FK_emp_consultant_info_hospital_id` (`hospital_id`),
  KEY `FK_emp_consultant_info_user_id` (`user_id`),
  KEY `FK_emp_consultant_info_emp_id` (`emp_id`),
  CONSTRAINT `FK_emp_consultant_info_emp_id` FOREIGN KEY (`emp_id`) REFERENCES `emp_info` (`emp_id`),
  CONSTRAINT `FK_emp_consultant_info_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_emp_consultant_info_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.emp_info
CREATE TABLE IF NOT EXISTS `emp_info` (
  `emp_id` int(8) NOT NULL AUTO_INCREMENT,
  `personal_id` int(8) NOT NULL,
  `user_id` int(8) NOT NULL,
  `hospital_id` int(8) NOT NULL,
  `status_id` int(8) NOT NULL,
  `emp_prefix_id` varchar(20) DEFAULT NULL,
  `last_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`emp_id`),
  KEY `FK_emp_info_personal_id` (`personal_id`),
  KEY `FK_emp_info_status_id` (`status_id`),
  KEY `FK_emp_info_user_id` (`user_id`),
  KEY `FK_emp_info_hospital_id` (`hospital_id`),
  CONSTRAINT `FK_emp_info_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_emp_info_personal_id` FOREIGN KEY (`personal_id`) REFERENCES `emp_personal_info` (`personal_id`),
  CONSTRAINT `FK_emp_info_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_emp_info_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.emp_leave_apply
CREATE TABLE IF NOT EXISTS `emp_leave_apply` (
  `emp_leave_info_id` int(8) NOT NULL,
  `emp_id` int(8) NOT NULL,
  `leave_type_id` int(8) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `start_session_id` int(8) NOT NULL,
  `end_session_id` int(8) NOT NULL,
  `days_cap` double NOT NULL,
  `user_id` int(8) NOT NULL,
  `status_id` int(8) NOT NULL,
  `annual_year_id` int(8) NOT NULL,
  `leave_posted_date` datetime NOT NULL,
  PRIMARY KEY (`emp_leave_info_id`),
  KEY `emp_leave_info_emp_id` (`emp_id`),
  KEY `emp_leave_info_leave_type_id` (`leave_type_id`),
  KEY `emp_leave_info_st_session_id` (`start_session_id`),
  KEY `emp_leave_info_ed_session_id` (`end_session_id`),
  KEY `emp_leave_info_user_id` (`user_id`),
  KEY `emp_leave_info_annual_year_id` (`annual_year_id`),
  KEY `emp_leave_info_status_id` (`status_id`),
  CONSTRAINT `emp_leave_info_annual_year_id` FOREIGN KEY (`annual_year_id`) REFERENCES `annual_year_master` (`annual_year_master_id`),
  CONSTRAINT `emp_leave_info_ed_session_id` FOREIGN KEY (`end_session_id`) REFERENCES `work_session_master` (`work_session_master_id`),
  CONSTRAINT `emp_leave_info_emp_id` FOREIGN KEY (`emp_id`) REFERENCES `emp_info` (`emp_id`),
  CONSTRAINT `emp_leave_info_leave_type_id` FOREIGN KEY (`leave_type_id`) REFERENCES `leave_master` (`leave_master_id`),
  CONSTRAINT `emp_leave_info_st_session_id` FOREIGN KEY (`start_session_id`) REFERENCES `work_session_master` (`work_session_master_id`),
  CONSTRAINT `emp_leave_info_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `emp_leave_info_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.emp_leave_assign
CREATE TABLE IF NOT EXISTS `emp_leave_assign` (
  `emp_leave_assign_id` int(8) NOT NULL,
  `emp_id` int(8) NOT NULL,
  `leave_type_id` int(8) NOT NULL,
  `days_cap` double NOT NULL,
  `annual_year_id` int(8) NOT NULL,
  `status_id` int(8) NOT NULL,
  `user_id` int(8) NOT NULL,
  `last_updated` datetime NOT NULL,
  PRIMARY KEY (`emp_leave_assign_id`),
  KEY `emp_leave_assign_emp_id` (`emp_id`),
  KEY `emp_leave_assign_type_id` (`leave_type_id`),
  KEY `emp_leave_assign_annual_type_id` (`annual_year_id`),
  KEY `emp_leave_assign_user_id` (`user_id`),
  KEY `emp_leave_assign_status_d` (`status_id`),
  CONSTRAINT `emp_leave_assign_annual_type_id` FOREIGN KEY (`annual_year_id`) REFERENCES `annual_year_master` (`annual_year_master_id`),
  CONSTRAINT `emp_leave_assign_emp_id` FOREIGN KEY (`emp_id`) REFERENCES `emp_info` (`emp_id`),
  CONSTRAINT `emp_leave_assign_status_d` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `emp_leave_assign_type_id` FOREIGN KEY (`leave_type_id`) REFERENCES `leave_master` (`leave_master_id`),
  CONSTRAINT `emp_leave_assign_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.emp_leave_reply
CREATE TABLE IF NOT EXISTS `emp_leave_reply` (
  `emp_leave_reply_id` int(8) NOT NULL,
  `emp_leave_apply_id` int(8) NOT NULL,
  `leave_status_id` int(8) NOT NULL,
  `reply_dated` datetime NOT NULL,
  `user_id` int(8) NOT NULL,
  `status_id` int(8) NOT NULL,
  `reason_notes` text,
  PRIMARY KEY (`emp_leave_reply_id`),
  KEY `emp_leave_applied_id` (`emp_leave_apply_id`),
  KEY `emp_leave_reply_status_id` (`status_id`),
  KEY `emp_leave_reply_master_id` (`leave_status_id`),
  KEY `emp_leave_reply_user_id` (`user_id`),
  CONSTRAINT `emp_leave_applied_id` FOREIGN KEY (`emp_leave_apply_id`) REFERENCES `emp_leave_apply` (`emp_leave_info_id`),
  CONSTRAINT `emp_leave_reply_master_id` FOREIGN KEY (`leave_status_id`) REFERENCES `leave_status_master` (`leave_status_master_id`),
  CONSTRAINT `emp_leave_reply_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `emp_leave_reply_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.emp_loan_details
CREATE TABLE IF NOT EXISTS `emp_loan_details` (
  `emp_loan_details_id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_loan_setup_id` int(11) NOT NULL,
  `emi_number` int(11) NOT NULL,
  `emi_amount` double NOT NULL,
  `emi_principal` double NOT NULL,
  `emi_interest` double NOT NULL,
  `emi_principal_balance` double NOT NULL,
  `emi_interest_balance` double NOT NULL,
  `emi_date` date DEFAULT NULL,
  `payslip_emp_info_id` int(11) DEFAULT NULL,
  `status_id` int(11) NOT NULL,
  PRIMARY KEY (`emp_loan_details_id`),
  KEY `FK_emp_loan_details_emp_loan_setup_id` (`emp_loan_setup_id`),
  KEY `FK_emp_loan_details_payslip_emp_info_id` (`payslip_emp_info_id`),
  KEY `FK_g3jhccvsjjfoakphhi7euyr9c` (`status_id`),
  CONSTRAINT `FK_emp_loan_details_emp_loan_setup_id` FOREIGN KEY (`emp_loan_setup_id`) REFERENCES `emp_loan_setup` (`emp_loan_setup_id`),
  CONSTRAINT `FK_emp_loan_details_payslip_emp_info_id` FOREIGN KEY (`payslip_emp_info_id`) REFERENCES `payslip_emp_info` (`payslip_emp_info_id`) ON DELETE SET NULL,
  CONSTRAINT `FK_g3jhccvsjjfoakphhi7euyr9c` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.emp_loan_emi_details
CREATE TABLE IF NOT EXISTS `emp_loan_emi_details` (
  `emp_loan_emi_details_id` int(8) NOT NULL AUTO_INCREMENT,
  `emp_loan_id` int(8) NOT NULL,
  `principal_amount` double(20,2) NOT NULL,
  `interest_amount` double(20,2) NOT NULL,
  `loan_emi_date` date NOT NULL,
  `loan_payment_type_id` int(1) NOT NULL,
  `status_id` int(1) NOT NULL,
  PRIMARY KEY (`emp_loan_emi_details_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.emp_loan_info
CREATE TABLE IF NOT EXISTS `emp_loan_info` (
  `emp_loan_info_id` int(8) NOT NULL AUTO_INCREMENT,
  `emp_id` int(8) NOT NULL,
  `loan_amount` double(20,2) NOT NULL,
  `loan_interest_rate` double(20,2) DEFAULT '0.00',
  `loan_tenure` int(8) NOT NULL,
  `loan_emi_amount` double(20,2) NOT NULL,
  `loan_start_date` date NOT NULL,
  `loan_closed_type_id` int(1) NOT NULL,
  `loan_closed_date` date DEFAULT NULL,
  `loan_description` text,
  `user_id` int(8) NOT NULL,
  `last_updated` datetime NOT NULL,
  `status_id` int(1) NOT NULL,
  PRIMARY KEY (`emp_loan_info_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.emp_loan_setup
CREATE TABLE IF NOT EXISTS `emp_loan_setup` (
  `emp_loan_setup_id` int(10) NOT NULL AUTO_INCREMENT,
  `emp_id` int(10) NOT NULL,
  `loan_created_date` date NOT NULL,
  `loan_start_date` date NOT NULL,
  `loan_end_date` date NOT NULL,
  `loan_amount` double NOT NULL,
  `interest_rate` double NOT NULL,
  `emi_amt` double NOT NULL,
  `loan_status` char(50) NOT NULL,
  `loan_closed_date` date NOT NULL,
  `update_datetime` datetime NOT NULL,
  `term` int(10) NOT NULL,
  `remarks` varchar(250) DEFAULT NULL,
  `status_id` int(8) NOT NULL,
  `hospital_id` int(11) NOT NULL,
  PRIMARY KEY (`emp_loan_setup_id`),
  KEY `FK_emp_loan_setup_emp_id` (`emp_id`),
  KEY `FK_emp_loan_setup_status_id` (`status_id`),
  KEY `FK_3na88rs89dqofy1lqythfyels` (`hospital_id`),
  CONSTRAINT `FK_3na88rs89dqofy1lqythfyels` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_emp_loan_setup_emp_id` FOREIGN KEY (`emp_id`) REFERENCES `emp_info` (`emp_id`),
  CONSTRAINT `FK_emp_loan_setup_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.emp_office_info
CREATE TABLE IF NOT EXISTS `emp_office_info` (
  `emp_official_id` int(8) NOT NULL AUTO_INCREMENT,
  `emp_id` int(8) NOT NULL,
  `dept_id` int(8) NOT NULL,
  `designation_category_id` int(8) NOT NULL,
  `designation_id` int(8) NOT NULL,
  `emp_type_id` int(8) NOT NULL,
  `emp_qualify` varchar(100) NOT NULL,
  `emp_doj` date NOT NULL DEFAULT '0000-00-00',
  `user_id` int(8) NOT NULL,
  `status_id` int(8) NOT NULL,
  `last_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`emp_official_id`),
  UNIQUE KEY `UK_scyryiccynt1sgiq5h1qdw1ro` (`emp_id`),
  KEY `FK_emp_office_info_dept_id` (`dept_id`),
  KEY `FK_emp_office_info_designation_id` (`designation_id`),
  KEY `FK_emp_office_info_status_id` (`status_id`),
  KEY `FK_emp_office_info_emp_type_id` (`emp_type_id`),
  KEY `FK_emp_office_info_emp_id` (`emp_id`),
  KEY `FK_emp_office_info_designation_category_id` (`designation_category_id`),
  KEY `FK_emp_office_info_user_id` (`user_id`),
  CONSTRAINT `FK_emp_office_info_dept_id` FOREIGN KEY (`dept_id`) REFERENCES `department_master` (`dept_id`),
  CONSTRAINT `FK_emp_office_info_designation_category_id` FOREIGN KEY (`designation_category_id`) REFERENCES `designation_category_master` (`designation_category_id`),
  CONSTRAINT `FK_emp_office_info_designation_id` FOREIGN KEY (`designation_id`) REFERENCES `designation_master` (`designation_id`),
  CONSTRAINT `FK_emp_office_info_emp_id` FOREIGN KEY (`emp_id`) REFERENCES `emp_info` (`emp_id`),
  CONSTRAINT `FK_emp_office_info_emp_type_id` FOREIGN KEY (`emp_type_id`) REFERENCES `emp_type_master` (`emp_type_id`),
  CONSTRAINT `FK_emp_office_info_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_emp_office_info_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.emp_personal_info
CREATE TABLE IF NOT EXISTS `emp_personal_info` (
  `personal_id` int(8) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(100) DEFAULT NULL,
  `middle_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `gender_type` int(8) DEFAULT '0',
  `date_of_birth` date DEFAULT '0000-00-00',
  `caddress1` varchar(100) DEFAULT NULL,
  `caddress2` varchar(100) DEFAULT NULL,
  `ccity_id` int(8) DEFAULT '0',
  `paddress1` varchar(100) DEFAULT NULL,
  `paddress2` varchar(100) DEFAULT NULL,
  `pcity_id` int(8) DEFAULT '0',
  `phone_no` varchar(20) DEFAULT NULL,
  `mobile_no` varchar(20) DEFAULT NULL,
  `email_id` varchar(50) DEFAULT NULL,
  `photo_path` text,
  `proof_id` int(2) DEFAULT NULL,
  `proof_num` varchar(100) DEFAULT NULL,
  `status_id` int(8) NOT NULL,
  `last_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`personal_id`),
  KEY `FK_emp_personal_info_status_id` (`status_id`),
  KEY `FK_emp_personal_info_ccity_id` (`ccity_id`),
  KEY `FK_emp_personal_info_city_id` (`pcity_id`),
  KEY `FK_emp_personal_info_gender_id` (`gender_type`),
  KEY `FK_emp_personal_info_proof_id` (`proof_id`),
  CONSTRAINT `FK_emp_personal_info_ccity_id` FOREIGN KEY (`ccity_id`) REFERENCES `city_master` (`city_id`),
  CONSTRAINT `FK_emp_personal_info_city_id` FOREIGN KEY (`pcity_id`) REFERENCES `city_master` (`city_id`),
  CONSTRAINT `FK_emp_personal_info_gender_id` FOREIGN KEY (`gender_type`) REFERENCES `gender_master` (`gender_id`),
  CONSTRAINT `FK_emp_personal_info_proof_id` FOREIGN KEY (`proof_id`) REFERENCES `govt_proof_master` (`proof_id`),
  CONSTRAINT `FK_emp_personal_info_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.emp_referal_info
CREATE TABLE IF NOT EXISTS `emp_referal_info` (
  `emp_referal_id` int(8) NOT NULL,
  `emp_id` int(8) NOT NULL,
  `personal_id` int(8) NOT NULL,
  `relation_ship` varchar(100) DEFAULT NULL,
  `referal_count` int(8) NOT NULL,
  `status_id` int(8) NOT NULL,
  `last_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`emp_referal_id`),
  KEY `FK_emp_referal_info_status_id` (`status_id`),
  KEY `FK_emp_referal_info_emp_id` (`emp_id`),
  KEY `FK_emp_referal_info_personal_id` (`personal_id`),
  CONSTRAINT `FK_emp_referal_info_emp_id` FOREIGN KEY (`emp_id`) REFERENCES `emp_info` (`emp_id`),
  CONSTRAINT `FK_emp_referal_info_personal_id` FOREIGN KEY (`personal_id`) REFERENCES `emp_personal_info` (`personal_id`),
  CONSTRAINT `FK_emp_referal_info_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.emp_salary_breakup
CREATE TABLE IF NOT EXISTS `emp_salary_breakup` (
  `emp_salary_breakup_id` int(8) NOT NULL,
  `salary_setup_id` int(8) NOT NULL,
  `salaryheads_id` int(8) NOT NULL,
  `salaryheads_cal_id` int(11) NOT NULL,
  `salaryheads_value` double(20,2) NOT NULL,
  `salaryheads_total` double(20,2) NOT NULL,
  PRIMARY KEY (`emp_salary_breakup_id`),
  KEY `emp_salary_breakup_setup_id` (`salary_setup_id`),
  KEY `emp_salary_breakup_heads_id` (`salaryheads_id`),
  KEY `emp_salary_breakup_cal_id` (`salaryheads_cal_id`),
  CONSTRAINT `emp_salary_breakup_cal_id` FOREIGN KEY (`salaryheads_cal_id`) REFERENCES `salaryheads_cal_type_master` (`salaryheads_cal_type_master_id`),
  CONSTRAINT `emp_salary_breakup_heads_id` FOREIGN KEY (`salaryheads_id`) REFERENCES `salaryheads_master` (`salaryheads_master_id`),
  CONSTRAINT `emp_salary_breakup_setup_id` FOREIGN KEY (`salary_setup_id`) REFERENCES `emp_salary_setup` (`emp_salary_setup_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.emp_salary_setup
CREATE TABLE IF NOT EXISTS `emp_salary_setup` (
  `emp_salary_setup_id` int(8) NOT NULL,
  `emp_id` int(8) NOT NULL,
  `salary_strucuture_id` int(11) NOT NULL,
  `basis_pay` double(20,2) NOT NULL,
  `ctc_pay` double(20,2) NOT NULL,
  `gross_pay` double(20,2) NOT NULL,
  `net_pay` double(20,2) NOT NULL,
  `effective_date` date NOT NULL,
  `hospital_id` int(8) NOT NULL,
  `user_id` int(8) NOT NULL,
  `status_id` int(8) NOT NULL,
  `last_updated` datetime NOT NULL,
  `permonth_salary` double(20,2) NOT NULL,
  PRIMARY KEY (`emp_salary_setup_id`),
  KEY `emp_salary_setup_emp_id` (`emp_id`),
  KEY `emp_salary_setup_structure_id` (`salary_strucuture_id`),
  KEY `emp_salary_setup_user_id` (`user_id`),
  KEY `emp_salary_setup_status_id` (`status_id`),
  KEY `emp_salary_setup_hospital_id` (`hospital_id`),
  CONSTRAINT `emp_salary_setup_emp_id` FOREIGN KEY (`emp_id`) REFERENCES `emp_info` (`emp_id`),
  CONSTRAINT `emp_salary_setup_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `emp_salary_setup_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `emp_salary_setup_structure_id` FOREIGN KEY (`salary_strucuture_id`) REFERENCES `salary_strucutre_master` (`salary_structure_master_id`),
  CONSTRAINT `emp_salary_setup_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.emp_shift_assign
CREATE TABLE IF NOT EXISTS `emp_shift_assign` (
  `emp_shift_assign` int(8) NOT NULL,
  `emp_id` int(8) NOT NULL,
  `shift_id` int(8) NOT NULL,
  `shift_from_date` date NOT NULL,
  `shift_to_date` date NOT NULL,
  `user_id` int(8) NOT NULL,
  `status_id` int(8) NOT NULL,
  `last_updated` datetime NOT NULL,
  PRIMARY KEY (`emp_shift_assign`),
  KEY `emp_shift_assign_emp_id` (`emp_id`),
  KEY `emp_shift_assign_user_id` (`user_id`),
  KEY `emp_shift_assign_status_id` (`status_id`),
  KEY `emp_shift_assign_shift_master_id` (`shift_id`),
  CONSTRAINT `emp_shift_assign_emp_id` FOREIGN KEY (`emp_id`) REFERENCES `emp_info` (`emp_id`),
  CONSTRAINT `emp_shift_assign_shift_master_id` FOREIGN KEY (`shift_id`) REFERENCES `shift_master` (`shift_master_id`),
  CONSTRAINT `emp_shift_assign_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `emp_shift_assign_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.emp_terminate_info
CREATE TABLE IF NOT EXISTS `emp_terminate_info` (
  `emp_terminate_id` int(8) NOT NULL,
  `emp_id` int(8) NOT NULL,
  `emp_terminate_date` date DEFAULT '0000-00-00',
  `emp_terminate_reason` text,
  `emp_terminate_status` int(8) NOT NULL,
  `status_id` int(8) NOT NULL,
  `last_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`emp_terminate_id`),
  KEY `FK_emp_terminate_info_emp_id` (`emp_id`),
  KEY `FK_emp_terminate_info_status_id` (`status_id`),
  CONSTRAINT `FK_emp_terminate_info_emp_id` FOREIGN KEY (`emp_id`) REFERENCES `emp_info` (`emp_id`),
  CONSTRAINT `FK_emp_terminate_info_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.emp_type_master
CREATE TABLE IF NOT EXISTS `emp_type_master` (
  `emp_type_id` int(8) NOT NULL AUTO_INCREMENT,
  `emp_type_desc` varchar(200) NOT NULL,
  `user_id` int(8) NOT NULL,
  `status_id` int(8) NOT NULL,
  `hospital_id` int(8) NOT NULL,
  `last_updated` datetime NOT NULL,
  `is_editable_id` int(2) NOT NULL,
  PRIMARY KEY (`emp_type_id`),
  KEY `FK_emp_type_master_status_id` (`status_id`),
  KEY `FK_emp_type_master_user_id` (`user_id`),
  KEY `FK_emp_type_hospital_id` (`hospital_id`),
  KEY `FK_emp_type_master_is_editable_id` (`is_editable_id`),
  CONSTRAINT `FK_emp_type_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_emp_type_master_is_editable_id` FOREIGN KEY (`is_editable_id`) REFERENCES `is_editable_master` (`is_editable_id`),
  CONSTRAINT `FK_emp_type_master_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_emp_type_master_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.emp_weekly_holiday
CREATE TABLE IF NOT EXISTS `emp_weekly_holiday` (
  `emp_weekly_id` int(8) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `week_id` int(11) NOT NULL,
  `user_id` int(8) DEFAULT NULL,
  `last_updated` datetime NOT NULL,
  PRIMARY KEY (`emp_weekly_id`),
  KEY `emp_weekly_emp_id` (`emp_id`),
  KEY `emp_weekly_week_id` (`week_id`),
  KEY `emp_weekly_holiday_user_id` (`user_id`),
  CONSTRAINT `emp_weekly_emp_id` FOREIGN KEY (`emp_id`) REFERENCES `emp_info` (`emp_id`),
  CONSTRAINT `emp_weekly_holiday_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`),
  CONSTRAINT `emp_weekly_week_id` FOREIGN KEY (`week_id`) REFERENCES `week_master` (`week_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.etymology_master
CREATE TABLE IF NOT EXISTS `etymology_master` (
  `etymology_id` int(11) NOT NULL AUTO_INCREMENT,
  `etymology_reason` text NOT NULL,
  `hospital_id` int(8) NOT NULL,
  `user_id` int(8) NOT NULL,
  `status_id` int(8) NOT NULL,
  `is_editable_id` int(2) NOT NULL,
  PRIMARY KEY (`etymology_id`),
  KEY `FK_compliant_master1_hospital_master` (`hospital_id`),
  KEY `FK_compliant_master1_login_master` (`user_id`),
  KEY `FK_compliant_master1_status_master` (`status_id`),
  KEY `FK_compliant_master1_is_editable_master` (`is_editable_id`),
  CONSTRAINT `etymology_master_ibfk_1` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `etymology_master_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`),
  CONSTRAINT `etymology_master_ibfk_3` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `etymology_master_ibfk_4` FOREIGN KEY (`is_editable_id`) REFERENCES `is_editable_master` (`is_editable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.expense_details
CREATE TABLE IF NOT EXISTS `expense_details` (
  `expense_details_id` int(11) NOT NULL AUTO_INCREMENT,
  `cheque_no` varchar(255) DEFAULT NULL,
  `emp_id` int(11) DEFAULT NULL,
  `payment_amount` double NOT NULL,
  `payment_date` date NOT NULL,
  `receiver_name` varchar(255) NOT NULL,
  `receiver_reason` varchar(255) NOT NULL,
  `bank_id` int(11) DEFAULT NULL,
  `expense_map_id` int(11) NOT NULL,
  `hospital_id` int(11) NOT NULL,
  `purpose_id` int(11) NOT NULL,
  `receiver_type_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`expense_details_id`),
  KEY `FK_ssyx7ow2e1sagd4kspb66rdm6` (`bank_id`),
  KEY `FK_puvmtjjnqe00qmltxt78iyyx5` (`expense_map_id`),
  KEY `FK_agyw3cd8j9k4s70pt6ku32l8x` (`hospital_id`),
  KEY `FK_4rhl6ojmlsxrrveegha0qcbf4` (`purpose_id`),
  KEY `FK_o2hrrw54y6mcu5u3ctmrqumdk` (`receiver_type_id`),
  KEY `FK_nkq1u0p6wwhq8uvjfodncdxxc` (`status_id`),
  KEY `FK_4ofs8ph9ny9o9pnkef9wys6sa` (`user_id`),
  KEY `FK_expense_details_emp_info` (`emp_id`),
  CONSTRAINT `FK_4ofs8ph9ny9o9pnkef9wys6sa` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`),
  CONSTRAINT `FK_4rhl6ojmlsxrrveegha0qcbf4` FOREIGN KEY (`purpose_id`) REFERENCES `purpose_master` (`purpose_id`),
  CONSTRAINT `FK_agyw3cd8j9k4s70pt6ku32l8x` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_expense_details_emp_info` FOREIGN KEY (`emp_id`) REFERENCES `emp_info` (`emp_id`),
  CONSTRAINT `FK_nkq1u0p6wwhq8uvjfodncdxxc` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_o2hrrw54y6mcu5u3ctmrqumdk` FOREIGN KEY (`receiver_type_id`) REFERENCES `receiver_type_master` (`receiver_type_id`),
  CONSTRAINT `FK_puvmtjjnqe00qmltxt78iyyx5` FOREIGN KEY (`expense_map_id`) REFERENCES `expense_map_details` (`expense_map_id`),
  CONSTRAINT `FK_ssyx7ow2e1sagd4kspb66rdm6` FOREIGN KEY (`bank_id`) REFERENCES `bank_master` (`bank_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.expense_map_details
CREATE TABLE IF NOT EXISTS `expense_map_details` (
  `expense_map_id` int(11) NOT NULL AUTO_INCREMENT,
  `hospital_id` int(11) NOT NULL,
  `payment_type_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`expense_map_id`),
  KEY `FK_b6ppursg5muirxr2047kjorq7` (`hospital_id`),
  KEY `FK_82ts91w1yp0uqmekyb22axlm5` (`payment_type_id`),
  KEY `FK_2ffpnam6b82luiu17hfswqg7l` (`status_id`),
  KEY `FK_p6pojo8695a8413m1ea3f81g6` (`user_id`),
  CONSTRAINT `FK_2ffpnam6b82luiu17hfswqg7l` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_82ts91w1yp0uqmekyb22axlm5` FOREIGN KEY (`payment_type_id`) REFERENCES `payment_type_master` (`payment_type_id`),
  CONSTRAINT `FK_b6ppursg5muirxr2047kjorq7` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_p6pojo8695a8413m1ea3f81g6` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.expense_voucher_details
CREATE TABLE IF NOT EXISTS `expense_voucher_details` (
  `expense_voucher_details_id` int(11) NOT NULL AUTO_INCREMENT,
  `voucher_serial_no` varchar(15) NOT NULL,
  `expense_map_id` int(11) NOT NULL,
  `hospital_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `expense_details_id` int(11) NOT NULL,
  PRIMARY KEY (`expense_voucher_details_id`),
  KEY `FK_cxws9lk9lweuswjl6rascsup9` (`expense_map_id`),
  KEY `FK_9iqpmegye6arybjmen9vmnxw8` (`hospital_id`),
  KEY `FK_2ptm87ydewx844nvgy9rhdfk3` (`status_id`),
  KEY `FK_fm1bj1gb47n84bfj4kxf7ohxd` (`user_id`),
  KEY `FK_nmr9mku8st7u50896nxwvq7sw` (`expense_details_id`),
  CONSTRAINT `FK_2ptm87ydewx844nvgy9rhdfk3` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_9iqpmegye6arybjmen9vmnxw8` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_cxws9lk9lweuswjl6rascsup9` FOREIGN KEY (`expense_map_id`) REFERENCES `expense_map_details` (`expense_map_id`),
  CONSTRAINT `FK_fm1bj1gb47n84bfj4kxf7ohxd` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`),
  CONSTRAINT `FK_nmr9mku8st7u50896nxwvq7sw` FOREIGN KEY (`expense_details_id`) REFERENCES `expense_details` (`expense_details_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.filepath_master
CREATE TABLE IF NOT EXISTS `filepath_master` (
  `file_path_id` int(8) NOT NULL,
  `file_path` varchar(300) NOT NULL,
  `status_id` int(1) NOT NULL,
  PRIMARY KEY (`file_path_id`),
  KEY `FK_filepath_master_status_id` (`status_id`),
  CONSTRAINT `FK_filepath_master_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.floor_master
CREATE TABLE IF NOT EXISTS `floor_master` (
  `floor_id` int(8) NOT NULL,
  `hospital_id` int(8) NOT NULL,
  `floor_short_name` varchar(200) DEFAULT NULL,
  `floor_desc` varchar(200) NOT NULL,
  `user_id` int(8) NOT NULL,
  `status_id` int(1) NOT NULL,
  `last_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`floor_id`),
  KEY `FK_floor_master_hospital_id` (`hospital_id`),
  KEY `FK_floor_master_status_id` (`status_id`),
  KEY `FK_floor_master_user_id` (`user_id`),
  CONSTRAINT `FK_floor_master_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_floor_master_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_floor_master_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.font_family_master
CREATE TABLE IF NOT EXISTS `font_family_master` (
  `font_family_master_id` int(11) NOT NULL AUTO_INCREMENT,
  `font_family_name` varchar(255) DEFAULT NULL,
  `status_id` int(11) NOT NULL,
  PRIMARY KEY (`font_family_master_id`),
  KEY `FK_h01wojtar8fbdchi0y3khot9n` (`status_id`),
  CONSTRAINT `FK_h01wojtar8fbdchi0y3khot9n` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.food_intake_master
CREATE TABLE IF NOT EXISTS `food_intake_master` (
  `food_intake_master_id` int(11) NOT NULL AUTO_INCREMENT,
  `food_intake_name` varchar(255) NOT NULL,
  `status_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`food_intake_master_id`),
  KEY `FK_mdh9j3metj6c89ata9hbc0kxt` (`status_id`),
  KEY `FK_m4mttnmnsc2u8mqvejf6n20cd` (`user_id`),
  CONSTRAINT `FK_m4mttnmnsc2u8mqvejf6n20cd` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`),
  CONSTRAINT `FK_mdh9j3metj6c89ata9hbc0kxt` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.gender_master
CREATE TABLE IF NOT EXISTS `gender_master` (
  `gender_id` int(8) NOT NULL,
  `gender_name` varchar(20) NOT NULL,
  `status_id` int(8) NOT NULL,
  PRIMARY KEY (`gender_id`),
  KEY `FK_gender_master_status_id` (`status_id`),
  CONSTRAINT `FK_gender_master_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.govt_proof_master
CREATE TABLE IF NOT EXISTS `govt_proof_master` (
  `proof_id` int(2) NOT NULL DEFAULT '0',
  `proof_name` varchar(50) DEFAULT NULL,
  `status_id` int(2) DEFAULT NULL,
  PRIMARY KEY (`proof_id`),
  KEY `FK_govt_proof_master` (`status_id`),
  CONSTRAINT `FK_govt_proof_master` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.guardian_type_master
CREATE TABLE IF NOT EXISTS `guardian_type_master` (
  `guardian_type_master_id` int(8) NOT NULL,
  `guardian_type_name` varchar(20) NOT NULL,
  `guardian_type_full_name` varchar(20) NOT NULL,
  `status_id` int(8) NOT NULL,
  PRIMARY KEY (`guardian_type_master_id`),
  KEY `FK_guardian_type_master_status_id` (`status_id`),
  CONSTRAINT `FK_guardian_type_master_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.header_image_path
CREATE TABLE IF NOT EXISTS `header_image_path` (
  `heade_image_path_id` int(11) NOT NULL AUTO_INCREMENT,
  `filepath` varchar(50) NOT NULL,
  `status_id` int(11) NOT NULL,
  `hospital_id` int(11) NOT NULL,
  PRIMARY KEY (`heade_image_path_id`),
  KEY `FK_headerimagepath_statusId` (`status_id`),
  KEY `FK_19plvrvd7a0s87afj3wpxp41o` (`hospital_id`),
  CONSTRAINT `FK_19plvrvd7a0s87afj3wpxp41o` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_headerimagepath_statusId` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.health_status_master
CREATE TABLE IF NOT EXISTS `health_status_master` (
  `health_status_id` int(11) NOT NULL AUTO_INCREMENT,
  `health_status` text NOT NULL,
  `hospital_id` int(8) NOT NULL,
  `user_id` int(8) NOT NULL,
  `status_id` int(8) NOT NULL,
  `is_editable_id` int(2) NOT NULL,
  PRIMARY KEY (`health_status_id`),
  KEY `FK_health_status_master_hospital_master` (`hospital_id`),
  KEY `FK_health_status_master_login_master` (`user_id`),
  KEY `FK_health_status_master_status_master` (`status_id`),
  KEY `FK_health_status_master_is_editable_master` (`is_editable_id`),
  CONSTRAINT `FK_health_status_master_hospital_master` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_health_status_master_is_editable_master` FOREIGN KEY (`is_editable_id`) REFERENCES `is_editable_master` (`is_editable_id`),
  CONSTRAINT `FK_health_status_master_login_master` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`),
  CONSTRAINT `FK_health_status_master_status_master` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.holiday_master
CREATE TABLE IF NOT EXISTS `holiday_master` (
  `holiday_master_id` int(8) NOT NULL,
  `holiday_date` date NOT NULL,
  `holiday_short_name` varchar(25) NOT NULL,
  `annual_year_id` int(8) NOT NULL,
  `hospital_id` int(8) NOT NULL,
  `user_id` int(8) NOT NULL,
  `status_id` int(8) NOT NULL,
  `last_updated` datetime NOT NULL,
  PRIMARY KEY (`holiday_master_id`),
  KEY `holiday_master_hospital_id` (`hospital_id`),
  KEY `holiday_master_user_id` (`user_id`),
  KEY `holiday_master_annual_year_id` (`annual_year_id`),
  KEY `holiday_master_status_id` (`status_id`),
  CONSTRAINT `holiday_master_annual_year_id` FOREIGN KEY (`annual_year_id`) REFERENCES `annual_year_master` (`annual_year_master_id`),
  CONSTRAINT `holiday_master_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `holiday_master_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `holiday_master_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.hospital_master
CREATE TABLE IF NOT EXISTS `hospital_master` (
  `hospital_id` int(8) NOT NULL AUTO_INCREMENT,
  `organization` varchar(200) NOT NULL,
  `address1` text,
  `address2` text,
  `city_id` int(8) NOT NULL,
  `phone_no` varchar(20) NOT NULL,
  `mobile_no` varchar(20) NOT NULL,
  `fax_no` varchar(20) DEFAULT NULL,
  `email_id` varchar(100) DEFAULT NULL,
  `contact_person_name` varchar(100) DEFAULT NULL,
  `tin_no` varchar(20) DEFAULT NULL,
  `license_no` varchar(20) DEFAULT NULL,
  `ima_reg_no` varchar(100) DEFAULT NULL,
  `cst_no` varchar(20) DEFAULT NULL,
  `service_tax` double(6,3) DEFAULT '0.000',
  `cess_tax` double(6,3) DEFAULT '0.000',
  `user_id` int(11) NOT NULL,
  `status_id` int(8) NOT NULL,
  `last_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `payslip_attendance_details_option` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`hospital_id`),
  KEY `FK_hospital_master_user_id` (`user_id`),
  KEY `FK_hospital_master_status_id` (`status_id`),
  KEY `FK_hospital_master_city_id` (`city_id`),
  CONSTRAINT `FK_hospital_master_city_id` FOREIGN KEY (`city_id`) REFERENCES `city_master` (`city_id`),
  CONSTRAINT `FK_hospital_master_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_hospital_master_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.indexing_common_specific_master
CREATE TABLE IF NOT EXISTS `indexing_common_specific_master` (
  `index_comm_spe_id` int(3) NOT NULL AUTO_INCREMENT,
  `index_comm_spe_desc` varchar(50) NOT NULL,
  `status_id` int(3) NOT NULL,
  PRIMARY KEY (`index_comm_spe_id`),
  KEY `FKstatus_id` (`status_id`),
  CONSTRAINT `FKstatus_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.indexing_hosp_setup
CREATE TABLE IF NOT EXISTS `indexing_hosp_setup` (
  `index_hosp_id` int(3) NOT NULL AUTO_INCREMENT,
  `indexing_master_id` int(3) NOT NULL,
  `prefix_value` varchar(50) NOT NULL,
  `num_value` int(7) NOT NULL,
  `hospital_id` int(7) NOT NULL,
  `user_id` int(7) NOT NULL,
  `status_id` int(7) NOT NULL,
  `last_updated` datetime NOT NULL,
  PRIMARY KEY (`index_hosp_id`),
  KEY `FK1_indexing_master_id` (`indexing_master_id`),
  KEY `FK2_hospital_id` (`hospital_id`),
  KEY `FK3_user_id` (`user_id`),
  KEY `FK4_status_id` (`status_id`),
  CONSTRAINT `FK1_indexing_master_id` FOREIGN KEY (`indexing_master_id`) REFERENCES `indexing_master` (`indexing_master_id`),
  CONSTRAINT `FK2_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK3_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`),
  CONSTRAINT `FK4_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.indexing_hosp_year
CREATE TABLE IF NOT EXISTS `indexing_hosp_year` (
  `index_hosp_year_id` int(5) NOT NULL AUTO_INCREMENT,
  `finan_year_option` varchar(5) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `last_updated` datetime NOT NULL,
  `user_id` int(5) NOT NULL,
  `hospital_id` int(5) NOT NULL,
  `status_id` int(5) NOT NULL,
  PRIMARY KEY (`index_hosp_year_id`),
  KEY `FK1_user_id` (`user_id`),
  KEY `FK2_status_id` (`status_id`),
  KEY `FK3_hospital_id` (`hospital_id`),
  CONSTRAINT `FK1_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`),
  CONSTRAINT `FK2_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK3_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.indexing_master
CREATE TABLE IF NOT EXISTS `indexing_master` (
  `indexing_master_id` int(3) NOT NULL AUTO_INCREMENT,
  `index_name` varchar(50) NOT NULL,
  `index_type` int(3) NOT NULL,
  `status_id` int(3) NOT NULL,
  PRIMARY KEY (`indexing_master_id`),
  KEY `FK1_status_id` (`status_id`),
  KEY `FK2_index_type` (`index_type`),
  CONSTRAINT `FK1_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK2_index_type` FOREIGN KEY (`index_type`) REFERENCES `indexing_common_specific_master` (`index_comm_spe_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.inventory_journal_details
CREATE TABLE IF NOT EXISTS `inventory_journal_details` (
  `inventory_journal_details_id` int(8) NOT NULL,
  `item_id` int(1) NOT NULL DEFAULT '0',
  `item_qty` int(8) DEFAULT '0',
  `item_per_rate` double(20,3) DEFAULT '0.000',
  `item_sale_rate` double(20,3) DEFAULT '0.000',
  `item_total_rate` double(20,3) DEFAULT '0.000',
  `type` int(1) NOT NULL DEFAULT '0',
  `status_id` int(1) NOT NULL DEFAULT '0',
  `operation_history_id` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`inventory_journal_details_id`),
  KEY `FK_inventory_journal_details_type_id` (`type`),
  KEY `FK_inventory_journal_details_status_id` (`status_id`),
  KEY `FK_inventory_journal_details_item_id` (`item_id`),
  KEY `FK_inventory_journal_details_operation_history_id` (`operation_history_id`),
  CONSTRAINT `FK_inventory_journal_details_item_id` FOREIGN KEY (`item_id`) REFERENCES `item_master` (`item_id`),
  CONSTRAINT `FK_inventory_journal_details_operation_history_id` FOREIGN KEY (`operation_history_id`) REFERENCES `operation_history_form` (`operation_id`),
  CONSTRAINT `FK_inventory_journal_details_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_inventory_journal_details_type_id` FOREIGN KEY (`type`) REFERENCES `inventory_type_master` (`inventory_type_master_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.inventory_type_master
CREATE TABLE IF NOT EXISTS `inventory_type_master` (
  `inventory_type_master_id` int(1) NOT NULL,
  `desc` varchar(150) NOT NULL DEFAULT '',
  `status_id` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`inventory_type_master_id`),
  KEY `FK_inventory_type_master_status_id` (`status_id`),
  CONSTRAINT `FK_inventory_type_master_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.ipd_charges_billing
CREATE TABLE IF NOT EXISTS `ipd_charges_billing` (
  `ipd_charges_billing_id` int(8) NOT NULL,
  `ipd_id` int(8) NOT NULL,
  `charge_billing_date` date NOT NULL,
  `charge_item_id` int(8) NOT NULL,
  `charge_item_rate` double(20,2) NOT NULL,
  `charge_item_qty` int(11) NOT NULL,
  `charge_item_discount_rate` double(20,2) DEFAULT '0.00',
  `charge_item_total` double(20,2) NOT NULL,
  `hospital_id` int(8) NOT NULL,
  `user_id` int(8) NOT NULL,
  `status_id` int(8) NOT NULL,
  `last_updated` datetime NOT NULL,
  PRIMARY KEY (`ipd_charges_billing_id`),
  KEY `FK_ipd_charges_billing_charge_item_id` (`charge_item_id`),
  KEY `FK_ipd_charges_billing_hospital_id` (`hospital_id`),
  KEY `FK_ipd_charges_billing_user_id` (`user_id`),
  KEY `FK_ipd_charges_billing_status_id` (`status_id`),
  KEY `FK_ipd_charges_billing_ipd_id` (`ipd_id`),
  CONSTRAINT `FK_ipd_charges_billing_charge_item_id` FOREIGN KEY (`charge_item_id`) REFERENCES `charge_item_master` (`charge_item_id`),
  CONSTRAINT `FK_ipd_charges_billing_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_ipd_charges_billing_ipd_id` FOREIGN KEY (`ipd_id`) REFERENCES `ipd_info` (`ipd_id`),
  CONSTRAINT `FK_ipd_charges_billing_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_ipd_charges_billing_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.ipd_doctor_fees
CREATE TABLE IF NOT EXISTS `ipd_doctor_fees` (
  `ipd_doctor_fees_id` int(11) NOT NULL AUTO_INCREMENT,
  `ipd_id` int(11) DEFAULT NULL,
  `emp_id` int(11) DEFAULT NULL,
  `operation_id` int(11) DEFAULT NULL,
  `treatment_date` date DEFAULT NULL,
  `fees` double DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ipd_doctor_fees_id`),
  KEY `FK_ipd_doctor_fees_ipd_id` (`ipd_id`),
  KEY `FK_ipd_doctor_fees_emp_id` (`emp_id`),
  KEY `FK_ipd_doctor_fees_operation_id` (`operation_id`),
  CONSTRAINT `FK_ipd_doctor_fees_emp_id` FOREIGN KEY (`emp_id`) REFERENCES `emp_info` (`emp_id`),
  CONSTRAINT `FK_ipd_doctor_fees_ipd_id` FOREIGN KEY (`ipd_id`) REFERENCES `ipd_info` (`ipd_id`) ON DELETE CASCADE,
  CONSTRAINT `FK_ipd_doctor_fees_operation_id` FOREIGN KEY (`operation_id`) REFERENCES `operation_history_form` (`operation_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.ipd_final_billing
CREATE TABLE IF NOT EXISTS `ipd_final_billing` (
  `final_billing_id` int(8) NOT NULL AUTO_INCREMENT,
  `ipd_id` int(8) NOT NULL,
  `total_room_charges` double(20,2) DEFAULT '0.00',
  `total_general_charges` double(20,2) DEFAULT '0.00',
  `total_doctor_fees` double(20,2) DEFAULT '0.00',
  `ot_charges` double(20,2) DEFAULT '0.00',
  `sub_total_amount` double(20,2) DEFAULT '0.00',
  `room_discount` double(20,2) DEFAULT '0.00',
  `miscellaneous_discount` double(20,2) DEFAULT '0.00',
  `tax2_percentage` double(6,3) DEFAULT '0.000',
  `total_payment_amount` double(20,2) DEFAULT '0.00',
  `net_total_amount` double(20,2) DEFAULT '0.00',
  `discount_amount` double(20,2) DEFAULT '0.00',
  `grand_total_amt` double(20,2) DEFAULT '0.00',
  `hospital_id` int(8) NOT NULL,
  `user_id` int(8) NOT NULL,
  `status_id` int(8) NOT NULL,
  `last_updated` datetime NOT NULL,
  `total_pharmacy_fees` double DEFAULT NULL,
  PRIMARY KEY (`final_billing_id`),
  KEY `FK_ipd_final_billing_ipd_id` (`ipd_id`),
  KEY `FK_ipd_final_billing_user_id` (`user_id`),
  KEY `FK_ipd_final_billing_hospital_id` (`hospital_id`),
  KEY `FK_ipd_final_billing_status_id` (`status_id`),
  CONSTRAINT `FK_ipd_final_billing_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_ipd_final_billing_ipd_id` FOREIGN KEY (`ipd_id`) REFERENCES `ipd_info` (`ipd_id`),
  CONSTRAINT `FK_ipd_final_billing_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_ipd_final_billing_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.ipd_info
CREATE TABLE IF NOT EXISTS `ipd_info` (
  `ipd_id` int(8) NOT NULL,
  `ipd_custom_id` varchar(20) DEFAULT NULL,
  `Reg_no` varchar(100) DEFAULT NULL,
  `patient_id` int(8) NOT NULL,
  `department_id` int(8) NOT NULL,
  `consultant` int(20) DEFAULT NULL,
  `hospital_id` int(8) NOT NULL,
  `user_id` int(8) NOT NULL,
  `admission_date` datetime NOT NULL,
  `discharge_date` datetime DEFAULT NULL,
  `discharge_type_id` int(1) DEFAULT NULL,
  `discharge_status` char(1) DEFAULT 'N',
  `status_id` int(8) DEFAULT NULL,
  `last_updated` datetime NOT NULL,
  PRIMARY KEY (`ipd_id`),
  KEY `FK_ipd_info_discharge_type_id` (`discharge_type_id`),
  KEY `FK_ipd_info_department_id` (`department_id`),
  KEY `FK_ipd_info_patient_id` (`patient_id`),
  KEY `FK_ipd_info_hospital_id` (`hospital_id`),
  KEY `FK_ipd_info_user_id` (`user_id`),
  KEY `FK_ipd_info_status_id` (`status_id`),
  KEY `FK_ipd_info_emp_id` (`consultant`),
  CONSTRAINT `FK_ipd_info_department_id` FOREIGN KEY (`department_id`) REFERENCES `department_master` (`dept_id`),
  CONSTRAINT `FK_ipd_info_discharge_type_id` FOREIGN KEY (`discharge_type_id`) REFERENCES `discharge_type_master` (`discharge_type_id`),
  CONSTRAINT `FK_ipd_info_emp_id` FOREIGN KEY (`consultant`) REFERENCES `emp_info` (`emp_id`),
  CONSTRAINT `FK_ipd_info_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_ipd_info_patient_id` FOREIGN KEY (`patient_id`) REFERENCES `patient_personal_details` (`patient_id`),
  CONSTRAINT `FK_ipd_info_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_ipd_info_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.ipd_payment_details
CREATE TABLE IF NOT EXISTS `ipd_payment_details` (
  `ipd_payment_details_id` int(8) NOT NULL,
  `payment_receipt_no` varchar(25) DEFAULT NULL,
  `payment_date` date NOT NULL,
  `payment_method_id` int(8) NOT NULL,
  `payment_ref_no` varchar(20) DEFAULT NULL,
  `payment_remarks` varchar(250) DEFAULT NULL,
  `payment_amount` double(20,2) NOT NULL,
  `hospital_id` int(8) NOT NULL,
  `user_id` int(8) NOT NULL,
  `ipd_id` int(8) NOT NULL,
  `advance_type` varchar(3) DEFAULT NULL,
  `status_id` int(8) NOT NULL,
  `last_updated` datetime NOT NULL,
  PRIMARY KEY (`ipd_payment_details_id`),
  KEY `FK_ipd_payment_details_payment_method_id` (`payment_method_id`),
  KEY `FK_ipd_payment_details_ipd_id` (`ipd_id`),
  KEY `FK_ipd_payment_details_user_id` (`user_id`),
  KEY `FK_ipd_payment_details_status_id` (`status_id`),
  KEY `FK_ipd_payment_details_hospital_id` (`hospital_id`),
  CONSTRAINT `FK_ipd_payment_details_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_ipd_payment_details_ipd_id` FOREIGN KEY (`ipd_id`) REFERENCES `ipd_info` (`ipd_id`),
  CONSTRAINT `FK_ipd_payment_details_payment_method_id` FOREIGN KEY (`payment_method_id`) REFERENCES `payment_method_master` (`payment_method_id`),
  CONSTRAINT `FK_ipd_payment_details_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_ipd_payment_details_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.ipd_room_billing
CREATE TABLE IF NOT EXISTS `ipd_room_billing` (
  `ipd_room_info_id` int(8) NOT NULL,
  `ipd_id` int(8) NOT NULL,
  `hospital_id` int(11) NOT NULL,
  `user_id` int(8) NOT NULL,
  `room_status_id` int(8) NOT NULL,
  `rent_per_day` double(20,2) DEFAULT '0.00',
  `days_occupied` int(8) DEFAULT '0',
  `additional_charge_amount` double(20,2) DEFAULT '0.00',
  `discount_amount` double(20,2) DEFAULT '0.00',
  `total_amount` double(20,2) DEFAULT '0.00',
  `last_updated` datetime NOT NULL,
  PRIMARY KEY (`ipd_room_info_id`),
  KEY `FK_ipd_room_billing_ipd_id` (`ipd_id`),
  KEY `FK_ipd_room_billing_room_status_id` (`room_status_id`),
  KEY `FK_ipd_room_billing_hospital_id` (`hospital_id`),
  KEY `FK_ipd_room_billing_user_id` (`user_id`),
  CONSTRAINT `FK_ipd_room_billing_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_ipd_room_billing_ipd_id` FOREIGN KEY (`ipd_id`) REFERENCES `ipd_info` (`ipd_id`),
  CONSTRAINT `FK_ipd_room_billing_room_status_id` FOREIGN KEY (`room_status_id`) REFERENCES `room_available_status_info` (`room_status_id`),
  CONSTRAINT `FK_ipd_room_billing_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.is_editable_master
CREATE TABLE IF NOT EXISTS `is_editable_master` (
  `is_editable_id` int(2) NOT NULL AUTO_INCREMENT,
  `is_editable_desc` varchar(50) NOT NULL DEFAULT '0',
  `status` char(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`is_editable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.item_category_master
CREATE TABLE IF NOT EXISTS `item_category_master` (
  `category_id` int(8) NOT NULL,
  `category_code` varchar(200) DEFAULT '',
  `category_desc` varchar(200) NOT NULL DEFAULT '',
  `system_date` varchar(20) NOT NULL DEFAULT '0000-00-00 00:00:00',
  `hospital_id` int(8) NOT NULL,
  `user_id` int(8) NOT NULL DEFAULT '0',
  `status_id` int(1) NOT NULL DEFAULT '1',
  `last_updated` datetime NOT NULL,
  PRIMARY KEY (`category_id`),
  KEY `FK_item_category_master_hospital_id` (`hospital_id`),
  KEY `FK_item_category_master_user_id` (`user_id`),
  KEY `FK_item_category_master_status_id` (`status_id`),
  CONSTRAINT `FK_item_category_master_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_item_category_master_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_item_category_master_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.item_master
CREATE TABLE IF NOT EXISTS `item_master` (
  `item_id` int(8) NOT NULL,
  `category_id` int(8) NOT NULL DEFAULT '0',
  `item_code` varchar(200) NOT NULL DEFAULT '',
  `item_desc` varchar(200) NOT NULL DEFAULT '',
  `pack_type_id` int(8) NOT NULL DEFAULT '0',
  `item_per` int(8) NOT NULL DEFAULT '0',
  `item_rate` double(20,5) NOT NULL DEFAULT '0.00000',
  `item_min_stock` int(8) NOT NULL DEFAULT '0',
  `hospital_id` int(8) NOT NULL DEFAULT '0',
  `user_id` int(8) NOT NULL DEFAULT '0',
  `status_id` int(1) NOT NULL DEFAULT '1',
  `last_updated` datetime NOT NULL,
  PRIMARY KEY (`item_id`),
  KEY `FK_item_master_user_id` (`user_id`),
  KEY `FK_item_master_status_id` (`status_id`),
  KEY `FK_item_master_item_unit_type_id` (`pack_type_id`),
  KEY `FK_item_master_category_id` (`category_id`),
  KEY `FK_item_master_hospital_id` (`hospital_id`),
  CONSTRAINT `FK_item_master_category_id` FOREIGN KEY (`category_id`) REFERENCES `item_category_master` (`category_id`),
  CONSTRAINT `FK_item_master_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_item_master_item_unit_type_id` FOREIGN KEY (`pack_type_id`) REFERENCES `item_unit_type_master` (`item_unit_type_id`),
  CONSTRAINT `FK_item_master_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_item_master_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.item_unit_type_master
CREATE TABLE IF NOT EXISTS `item_unit_type_master` (
  `item_unit_type_id` int(8) NOT NULL,
  `item_type_name` varchar(200) NOT NULL DEFAULT '',
  `status_id` int(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`item_unit_type_id`),
  KEY `FK_item_unit_type_master_status_id` (`status_id`),
  CONSTRAINT `FK_item_unit_type_master_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.leave_gender_master
CREATE TABLE IF NOT EXISTS `leave_gender_master` (
  `leave_gender_master_id` int(1) NOT NULL,
  `leave_gender_name` varchar(10) NOT NULL,
  `status_id` int(11) NOT NULL,
  PRIMARY KEY (`leave_gender_master_id`),
  KEY `leave_gender_status_id` (`status_id`),
  CONSTRAINT `leave_gender_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.leave_master
CREATE TABLE IF NOT EXISTS `leave_master` (
  `leave_master_id` int(8) NOT NULL,
  `leave_code` varchar(10) NOT NULL,
  `leave_name` varchar(100) NOT NULL,
  `leave_days` double NOT NULL,
  `gender_option` int(1) DEFAULT NULL,
  `encashable_option` int(1) NOT NULL,
  `carry_forward_option` int(1) DEFAULT NULL,
  `leave_pay_id` int(1) NOT NULL,
  `hospital_id` int(8) NOT NULL,
  `status_id` int(8) NOT NULL,
  `user_id` int(8) NOT NULL,
  `last_updated` datetime NOT NULL,
  `visibility_status` varchar(255) NOT NULL,
  PRIMARY KEY (`leave_master_id`),
  KEY `leave_master_hospital_id` (`hospital_id`),
  KEY `leave_master_status_id` (`status_id`),
  KEY `leave_master_user_id` (`user_id`),
  KEY `leave_master_gender_id` (`gender_option`),
  KEY `leave_master_encash_opt_id` (`encashable_option`),
  KEY `leave_master_carry_id` (`carry_forward_option`),
  KEY `leave_master_pay_id` (`leave_pay_id`),
  CONSTRAINT `leave_master_carry_id` FOREIGN KEY (`carry_forward_option`) REFERENCES `yes_no_master` (`yes_no_master_id`),
  CONSTRAINT `leave_master_encash_opt_id` FOREIGN KEY (`encashable_option`) REFERENCES `yes_no_master` (`yes_no_master_id`),
  CONSTRAINT `leave_master_gender_id` FOREIGN KEY (`gender_option`) REFERENCES `leave_gender_master` (`leave_gender_master_id`),
  CONSTRAINT `leave_master_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `leave_master_pay_id` FOREIGN KEY (`leave_pay_id`) REFERENCES `leave_pay_master` (`leave_pay_master_id`),
  CONSTRAINT `leave_master_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `leave_master_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.leave_pay_master
CREATE TABLE IF NOT EXISTS `leave_pay_master` (
  `leave_pay_master_id` int(8) NOT NULL,
  `leave_pay_name` varchar(100) NOT NULL,
  `status_id` int(1) NOT NULL,
  PRIMARY KEY (`leave_pay_master_id`),
  KEY `leave_pay_master_status_id` (`status_id`),
  CONSTRAINT `leave_pay_master_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.leave_status_master
CREATE TABLE IF NOT EXISTS `leave_status_master` (
  `leave_status_master_id` int(8) NOT NULL,
  `leave_status_name` varchar(25) NOT NULL,
  `status_id` int(8) NOT NULL,
  PRIMARY KEY (`leave_status_master_id`),
  KEY `status_id` (`status_id`),
  CONSTRAINT `status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.loan_closed_status_master
CREATE TABLE IF NOT EXISTS `loan_closed_status_master` (
  `loan_closed_status_master` int(8) NOT NULL AUTO_INCREMENT,
  `loan_closed_Status_name` varchar(50) NOT NULL,
  `status_id` int(1) NOT NULL,
  PRIMARY KEY (`loan_closed_status_master`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.loan_payment_type_master
CREATE TABLE IF NOT EXISTS `loan_payment_type_master` (
  `loan_payment_type_master_id` int(8) NOT NULL AUTO_INCREMENT,
  `loan_payment_type_name` varchar(50) NOT NULL,
  `status_id` int(8) NOT NULL,
  PRIMARY KEY (`loan_payment_type_master_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.loan_self_master
CREATE TABLE IF NOT EXISTS `loan_self_master` (
  `loan_selef_id` int(11) NOT NULL,
  `loan_self_name` varchar(10) NOT NULL,
  `status_id` int(11) NOT NULL,
  PRIMARY KEY (`loan_selef_id`),
  KEY `status_id_Fk` (`status_id`),
  CONSTRAINT `status_id_Fk` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.login_master
CREATE TABLE IF NOT EXISTS `login_master` (
  `user_id` int(8) NOT NULL AUTO_INCREMENT,
  `emp_id` int(8) DEFAULT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_password` varchar(200) NOT NULL,
  `user_type_id` int(8) NOT NULL,
  `status_id` int(8) NOT NULL,
  `last_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `hospital_id` int(11) NOT NULL,
  PRIMARY KEY (`user_id`),
  KEY `FK_login_master_status_id` (`status_id`),
  KEY `FK_login_master_user_type_id` (`user_type_id`),
  KEY `FK_psk403uapca0spt21xn3dfqk2` (`hospital_id`),
  KEY `FK_login_master_emp_id` (`emp_id`),
  CONSTRAINT `FK_login_master_emp_id` FOREIGN KEY (`emp_id`) REFERENCES `emp_info` (`emp_id`),
  CONSTRAINT `FK_login_master_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_login_master_user_type_id` FOREIGN KEY (`user_type_id`) REFERENCES `user_type_master` (`user_type_id`),
  CONSTRAINT `FK_psk403uapca0spt21xn3dfqk2` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.martial_type_master
CREATE TABLE IF NOT EXISTS `martial_type_master` (
  `martial_status_master_id` int(8) NOT NULL,
  `martial_type_name` varchar(50) NOT NULL,
  `status_id` int(8) NOT NULL,
  PRIMARY KEY (`martial_status_master_id`),
  KEY `FK_martial_type_master_status_id` (`status_id`),
  CONSTRAINT `FK_martial_type_master_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.menu_master
CREATE TABLE IF NOT EXISTS `menu_master` (
  `menu_id` int(3) NOT NULL AUTO_INCREMENT,
  `menu_name` varchar(50) NOT NULL DEFAULT '',
  `link` varchar(150) DEFAULT NULL,
  `menu_type` varchar(10) NOT NULL DEFAULT '',
  `group_head` int(3) DEFAULT NULL,
  `sub_group_head` int(3) DEFAULT NULL,
  `priority_id` int(4) NOT NULL DEFAULT '0',
  `menu_url_name` varchar(150) DEFAULT NULL,
  `status_id` int(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`menu_id`),
  KEY `fk_menu_master_status_master1_idx` (`status_id`),
  CONSTRAINT `fk_menu_master_status_master1` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.menu_master_super
CREATE TABLE IF NOT EXISTS `menu_master_super` (
  `menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `group_head` int(11) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `menu_name` varchar(255) NOT NULL,
  `menu_type` varchar(255) NOT NULL,
  `menu_url_name` varchar(255) DEFAULT NULL,
  `priority_id` int(11) NOT NULL,
  `sub_group_head` int(11) DEFAULT NULL,
  `status_id` int(11) NOT NULL,
  PRIMARY KEY (`menu_id`),
  KEY `FK_pxn6rnmi6be1k2llo4n2xhip3` (`status_id`),
  CONSTRAINT `FK_pxn6rnmi6be1k2llo4n2xhip3` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.month_master
CREATE TABLE IF NOT EXISTS `month_master` (
  `month_master_id` int(2) NOT NULL AUTO_INCREMENT,
  `month_name` varchar(100) NOT NULL,
  `status_id` int(2) DEFAULT NULL,
  PRIMARY KEY (`month_master_id`),
  KEY `month_status_id` (`status_id`),
  CONSTRAINT `month_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.mysample
CREATE TABLE IF NOT EXISTS `mysample` (
  `personID` int(11) DEFAULT NULL,
  `USERNAME` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.opd_common_factor
CREATE TABLE IF NOT EXISTS `opd_common_factor` (
  `opd_common_factor_id` int(11) NOT NULL AUTO_INCREMENT,
  `common_factor_id` int(11) DEFAULT NULL,
  `opd_patient_map_id` int(11) DEFAULT NULL,
  `status_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`opd_common_factor_id`),
  KEY `FK_l7uanvtes65iei71f8kor2xuv` (`common_factor_id`),
  KEY `FK_477bjhj6df7vhfo4kghrimcf9` (`opd_patient_map_id`),
  KEY `FK_gntgeif121hv5fcxktfws364r` (`status_id`),
  CONSTRAINT `FK_477bjhj6df7vhfo4kghrimcf9` FOREIGN KEY (`opd_patient_map_id`) REFERENCES `opd_patient_map` (`opd_patient_map_id`),
  CONSTRAINT `FK_gntgeif121hv5fcxktfws364r` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_l7uanvtes65iei71f8kor2xuv` FOREIGN KEY (`common_factor_id`) REFERENCES `common_factor` (`common_factor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.opd_consultation_details
CREATE TABLE IF NOT EXISTS `opd_consultation_details` (
  `opd_consultation_details_id` int(8) NOT NULL,
  `patient_id` int(8) NOT NULL,
  `appointment_id` int(8) NOT NULL,
  `findings` text,
  `clinical_notes` text,
  `prescription` text,
  `user_id` int(8) NOT NULL,
  `status_id` int(8) NOT NULL,
  `last_updated` datetime NOT NULL,
  PRIMARY KEY (`opd_consultation_details_id`),
  KEY `FK_opd_consultation_details_patient_id` (`patient_id`),
  KEY `FK_opd_consultation_details_user_id` (`user_id`),
  KEY `FK_opd_consultation_details_status_id` (`status_id`),
  KEY `FK_opd_consultation_details_appointment_id` (`appointment_id`),
  CONSTRAINT `FK_opd_consultation_details_appointment_id` FOREIGN KEY (`appointment_id`) REFERENCES `appointment_details` (`appointment_id`),
  CONSTRAINT `FK_opd_consultation_details_patient_id` FOREIGN KEY (`patient_id`) REFERENCES `patient_personal_details` (`patient_id`),
  CONSTRAINT `FK_opd_consultation_details_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_opd_consultation_details_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.opd_other_services
CREATE TABLE IF NOT EXISTS `opd_other_services` (
  `opd_other_serviced_id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_id` int(11) NOT NULL,
  `serviceid` int(11) NOT NULL,
  `patient_map_id` int(11) NOT NULL,
  `appoint_date` varchar(50) NOT NULL,
  `hospital_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `opd_otherservice_number` varchar(50) DEFAULT NULL,
  `last_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`opd_other_serviced_id`),
  KEY `FK_opd_other_service_emp_id` (`emp_id`),
  KEY `FK_opd_other_service_patient_map_id` (`patient_map_id`),
  KEY `FK_opd_other_service_hospita_id` (`hospital_id`),
  KEY `FK_opd_other_service_status_id` (`status_id`),
  KEY `FK_opd_other_service_service_map_id` (`serviceid`),
  CONSTRAINT `FK_opd_other_service_emp_id` FOREIGN KEY (`emp_id`) REFERENCES `emp_info` (`emp_id`),
  CONSTRAINT `FK_opd_other_service_hospita_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_opd_other_service_patient_map_id` FOREIGN KEY (`patient_map_id`) REFERENCES `patient_map` (`patient_fees_payment_map_id`),
  CONSTRAINT `FK_opd_other_service_service_map_id` FOREIGN KEY (`serviceid`) REFERENCES `service_master` (`app_service_id`),
  CONSTRAINT `FK_opd_other_service_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.opd_patient_map
CREATE TABLE IF NOT EXISTS `opd_patient_map` (
  `opd_patient_map_id` int(11) NOT NULL AUTO_INCREMENT,
  `review_date` date DEFAULT NULL,
  `completed_status` char(50) NOT NULL,
  `appointment_id` int(11) NOT NULL,
  `patient_map_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  PRIMARY KEY (`opd_patient_map_id`),
  KEY `FK_8cvrwxlmsc4hmaows3usuhv8a` (`appointment_id`),
  KEY `FK_rjty4rawx84f7i3imoa4i5cql` (`status_id`),
  KEY `FK_opd_paitne_mapid_patien_map_id` (`patient_map_id`),
  CONSTRAINT `FK_8cvrwxlmsc4hmaows3usuhv8a` FOREIGN KEY (`appointment_id`) REFERENCES `appointment_info` (`appointment_info_id`),
  CONSTRAINT `FK_opd_paitne_mapid_patien_map_id` FOREIGN KEY (`patient_map_id`) REFERENCES `patient_map` (`patient_fees_payment_map_id`),
  CONSTRAINT `FK_rjty4rawx84f7i3imoa4i5cql` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.opd_patient_notes
CREATE TABLE IF NOT EXISTS `opd_patient_notes` (
  `opd_patient_notes_id` int(11) NOT NULL AUTO_INCREMENT,
  `advice` varchar(255) NOT NULL,
  `family_history` varchar(255) NOT NULL,
  `investigation` varchar(255) NOT NULL,
  `past_history` varchar(255) NOT NULL,
  `presentingcomplaints` varchar(255) NOT NULL,
  `procedure_done` varchar(255) NOT NULL,
  `opd_patient_map_id` int(11) NOT NULL,
  `weight` double DEFAULT NULL,
  `height` double DEFAULT NULL,
  `common_factor_id` int(10) DEFAULT NULL,
  `bmi` double DEFAULT NULL,
  PRIMARY KEY (`opd_patient_notes_id`),
  KEY `FK_1tsyl5dmxlqu9yq8stgw1mxe8` (`opd_patient_map_id`),
  KEY `FK_opd_patient_notes_common_factor_id` (`common_factor_id`),
  CONSTRAINT `FK_1tsyl5dmxlqu9yq8stgw1mxe8` FOREIGN KEY (`opd_patient_map_id`) REFERENCES `opd_patient_map` (`opd_patient_map_id`),
  CONSTRAINT `FK_opd_patient_notes_common_factor_id` FOREIGN KEY (`common_factor_id`) REFERENCES `common_factor` (`common_factor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.opd_prescription_details
CREATE TABLE IF NOT EXISTS `opd_prescription_details` (
  `opd_prescription_details_id` int(10) NOT NULL AUTO_INCREMENT,
  `strength` varchar(50) DEFAULT NULL,
  `drug_master_id` int(11) DEFAULT NULL,
  `drug_type_master_id` int(11) DEFAULT NULL,
  `food_intake_master_id` int(11) DEFAULT NULL,
  `opd_patient_map_id` int(11) DEFAULT NULL,
  `morning` varchar(50) DEFAULT NULL,
  `afternoon` varchar(50) DEFAULT NULL,
  `evening` varchar(50) DEFAULT NULL,
  `days` int(11) DEFAULT NULL,
  `status_id` int(10) NOT NULL,
  PRIMARY KEY (`opd_prescription_details_id`),
  KEY `FK_opd_prescription_details_drug_master_id` (`drug_master_id`),
  KEY `FK_opd_prescription_details_drug_type_master_id` (`drug_type_master_id`),
  KEY `FK_opd_prescription_details_food_intake_master_id` (`food_intake_master_id`),
  KEY `FK_opd_prescription_details_opd_patient_map_id` (`opd_patient_map_id`),
  KEY `FK_opd_prescription_details_satus_id` (`status_id`),
  CONSTRAINT `FK_opd_prescription_details_drug_master_id` FOREIGN KEY (`drug_master_id`) REFERENCES `drug_master` (`drug_master_id`),
  CONSTRAINT `FK_opd_prescription_details_drug_type_master_id` FOREIGN KEY (`drug_type_master_id`) REFERENCES `drug_type_master` (`drug_type_id`),
  CONSTRAINT `FK_opd_prescription_details_food_intake_master_id` FOREIGN KEY (`food_intake_master_id`) REFERENCES `food_intake_master` (`food_intake_master_id`),
  CONSTRAINT `FK_opd_prescription_details_opd_patient_map_id` FOREIGN KEY (`opd_patient_map_id`) REFERENCES `opd_patient_map` (`opd_patient_map_id`),
  CONSTRAINT `FK_opd_prescription_details_satus_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.opd_schedular_time
CREATE TABLE IF NOT EXISTS `opd_schedular_time` (
  `opd_schedular_time_id` int(11) NOT NULL AUTO_INCREMENT,
  `schedular_doctor_id` int(11) NOT NULL,
  `start_time` varchar(50) NOT NULL,
  `end_time` varchar(50) DEFAULT NULL,
  `time_interval` int(11) DEFAULT NULL,
  `status_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`opd_schedular_time_id`),
  KEY `FKschedular_status_id` (`status_id`),
  KEY `FKschedular_user_id` (`user_id`),
  KEY `FK_1p44ip8wacwy707ji4ar2ms3t` (`schedular_doctor_id`),
  CONSTRAINT `FK_sch_doctorId` FOREIGN KEY (`schedular_doctor_id`) REFERENCES `emp_info` (`emp_id`),
  CONSTRAINT `FKschedular_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FKschedular_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.opd_service_list
CREATE TABLE IF NOT EXISTS `opd_service_list` (
  `opd_service_id` int(11) NOT NULL AUTO_INCREMENT,
  `opd_service_name` varchar(50) NOT NULL,
  `status_id` int(11) NOT NULL,
  PRIMARY KEY (`opd_service_id`),
  KEY `FK_opd_serivice_status_id` (`status_id`),
  CONSTRAINT `FK_opd_serivice_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.opd_upload_info
CREATE TABLE IF NOT EXISTS `opd_upload_info` (
  `opd_upload_info_id` int(10) NOT NULL AUTO_INCREMENT,
  `file_name` varchar(150) DEFAULT NULL,
  `original_file_name` varchar(150) DEFAULT NULL,
  `opd_patient_map_id` int(8) DEFAULT NULL,
  `file_content_type` varchar(150) DEFAULT NULL,
  `file_location` varchar(150) DEFAULT NULL,
  `size` longblob,
  `upload_date_time` datetime DEFAULT NULL,
  `status_id` int(8) NOT NULL,
  PRIMARY KEY (`opd_upload_info_id`),
  KEY `FK_opd_upload_info_opd_patient_map_id` (`opd_patient_map_id`),
  KEY `FK_opd_upload_info_status_id` (`status_id`),
  CONSTRAINT `FK_opd_upload_info_opd_patient_map_id` FOREIGN KEY (`opd_patient_map_id`) REFERENCES `opd_patient_map` (`opd_patient_map_id`),
  CONSTRAINT `FK_opd_upload_info_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.operation_history_form
CREATE TABLE IF NOT EXISTS `operation_history_form` (
  `operation_id` int(20) NOT NULL,
  `operation_date` date DEFAULT NULL,
  `findings` text,
  `diagnosis` text,
  `procedures` text,
  `op_id` int(20) DEFAULT NULL,
  `ipd_id` int(20) DEFAULT NULL,
  `hospital_id` int(20) DEFAULT NULL,
  `status_id` int(20) DEFAULT NULL,
  `operation_history_id` int(11) DEFAULT NULL,
  `operation_end_date_time` datetime DEFAULT NULL,
  `operation_start_date_time` datetime DEFAULT NULL,
  PRIMARY KEY (`operation_id`),
  KEY `operation_history_form_op_id` (`op_id`),
  KEY `operation_history_form_ipd_id` (`ipd_id`),
  KEY `operation_history_form_hospital_id` (`hospital_id`),
  KEY `operation_history_form_status_id` (`status_id`),
  KEY `FK_3nodjxidgwktl62sto6qlxd0s` (`operation_history_id`),
  KEY `FK_en6on08q7lc759sx8lv26axdw` (`op_id`),
  CONSTRAINT `FK_3nodjxidgwktl62sto6qlxd0s` FOREIGN KEY (`operation_history_id`) REFERENCES `inventory_journal_details` (`operation_history_id`),
  CONSTRAINT `FK_operation_history_form_op_id` FOREIGN KEY (`op_id`) REFERENCES `operation_proceduretype_master` (`procedure_type_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `operation_history_form_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `operation_history_form_ipd_id` FOREIGN KEY (`ipd_id`) REFERENCES `ipd_info` (`ipd_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `operation_history_form_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.operation_proceduretype_master
CREATE TABLE IF NOT EXISTS `operation_proceduretype_master` (
  `procedure_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `procedure_desc` varchar(50) NOT NULL,
  `proc_dept_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `hospital_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`procedure_type_id`),
  KEY `FK_proce_dept_id` (`proc_dept_id`),
  KEY `FK_proc_status_id` (`status_id`),
  KEY `FK_proc_hospital_id` (`hospital_id`),
  KEY `FK_proc_user_id` (`user_id`),
  CONSTRAINT `FK_proc_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_proc_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_proc_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`),
  CONSTRAINT `FK_proce_dept_id` FOREIGN KEY (`proc_dept_id`) REFERENCES `department_master` (`dept_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.operation_support_team
CREATE TABLE IF NOT EXISTS `operation_support_team` (
  `op_support_id` int(20) NOT NULL AUTO_INCREMENT,
  `operation_id` int(20) DEFAULT NULL,
  `emp_id` int(20) DEFAULT NULL,
  `dept_id` int(20) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`op_support_id`),
  KEY `operation_support_team_operation_id` (`operation_id`),
  KEY `operation_support_team_emp_id` (`emp_id`),
  KEY `operation_support_team_dept_id` (`dept_id`),
  CONSTRAINT `operation_support_team_dept_id` FOREIGN KEY (`dept_id`) REFERENCES `department_master` (`dept_id`),
  CONSTRAINT `operation_support_team_emp_id` FOREIGN KEY (`emp_id`) REFERENCES `emp_info` (`emp_id`),
  CONSTRAINT `operation_support_team_operation_id` FOREIGN KEY (`operation_id`) REFERENCES `operation_history_form` (`operation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.operation_type_master
CREATE TABLE IF NOT EXISTS `operation_type_master` (
  `op_id` int(20) NOT NULL AUTO_INCREMENT,
  `op_desc` varchar(200) DEFAULT NULL,
  `hospital_id` int(20) DEFAULT NULL,
  `user_id` int(20) DEFAULT NULL,
  `status_id` int(20) DEFAULT NULL,
  PRIMARY KEY (`op_id`),
  KEY `operation_type_master_hospital_id` (`hospital_id`),
  KEY `operation_type_master_user_id` (`user_id`),
  KEY `operation_type_master_status_id` (`status_id`),
  CONSTRAINT `operation_type_master_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `operation_type_master_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `operation_type_master_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.other_services
CREATE TABLE IF NOT EXISTS `other_services` (
  `other_service_id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_id` int(11) NOT NULL,
  `service_name` int(11) NOT NULL,
  `patient_name` varchar(50) NOT NULL,
  `app_date` date DEFAULT NULL,
  `amount` double DEFAULT NULL,
  `mobile_no` varchar(50) DEFAULT NULL,
  `status_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `last_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `hospital_id` int(11) NOT NULL,
  `others_receipt_no` varchar(50) DEFAULT NULL,
  `other_service_gen_id` varchar(50) DEFAULT NULL,
  `doctor_fee` double DEFAULT NULL,
  `hos_fee` double DEFAULT NULL,
  PRIMARY KEY (`other_service_id`),
  KEY `FK_other_service_emp_id` (`emp_id`),
  KEY `FK_other_services_status_id` (`status_id`),
  KEY `FK_other_services_user_id` (`user_id`),
  KEY `FK_other_service_hospitl_id` (`hospital_id`),
  KEY `FK_other_sesrvice_service_name` (`service_name`),
  CONSTRAINT `FK_other_service_emp_id` FOREIGN KEY (`emp_id`) REFERENCES `emp_info` (`emp_id`),
  CONSTRAINT `FK_other_service_hospitl_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_other_services_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_other_services_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`),
  CONSTRAINT `FK_other_sesrvice_service_name` FOREIGN KEY (`service_name`) REFERENCES `custom_service_setup` (`custom_service_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.page_setup_heading
CREATE TABLE IF NOT EXISTS `page_setup_heading` (
  `page_setup_heading_id` int(11) NOT NULL AUTO_INCREMENT,
  `heading_name` varchar(255) DEFAULT NULL,
  `hospital_id` int(11) NOT NULL,
  `printing_template_master_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  PRIMARY KEY (`page_setup_heading_id`),
  KEY `FK_c3t845axh7k7yq0kj22c8yvvd` (`hospital_id`),
  KEY `FK_2acsklx0h2d8f3ai93p7kod94` (`printing_template_master_id`),
  KEY `FK_r7qrdsf5luvpwppqcvldrbxaw` (`status_id`),
  CONSTRAINT `FK_2acsklx0h2d8f3ai93p7kod94` FOREIGN KEY (`printing_template_master_id`) REFERENCES `printing_template_master` (`printing_template_master_id`),
  CONSTRAINT `FK_c3t845axh7k7yq0kj22c8yvvd` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_r7qrdsf5luvpwppqcvldrbxaw` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.page_setup_values
CREATE TABLE IF NOT EXISTS `page_setup_values` (
  `page_setup_values_id` int(11) NOT NULL AUTO_INCREMENT,
  `font_stretch_id` varchar(255) DEFAULT NULL,
  `indent_param` varchar(255) DEFAULT NULL,
  `indent_value` double DEFAULT NULL,
  `letter_spacing` double DEFAULT NULL,
  `line_height_value` double DEFAULT NULL,
  `line_hieght_param` varchar(255) DEFAULT NULL,
  `margin_bottom_value` double DEFAULT NULL,
  `margin_left_value` double DEFAULT NULL,
  `margin_rigth_value` double DEFAULT NULL,
  `margin_top_value` double DEFAULT NULL,
  `padding_value` double DEFAULT NULL,
  `set_font_size` double DEFAULT NULL,
  `word_space_value` double DEFAULT NULL,
  `alignment_id` int(11) NOT NULL,
  `font_size_params_id` int(11) NOT NULL,
  `font_style_id` int(11) NOT NULL,
  `letter_space_param_id` int(11) NOT NULL,
  `margin_bottom_param_id` int(11) NOT NULL,
  `margin_float_id` int(11) NOT NULL,
  `margin_left_param_id` int(11) NOT NULL,
  `margin_right_param_id` int(11) NOT NULL,
  `margin_top_param_id` int(11) NOT NULL,
  `padding_param_id` int(11) NOT NULL,
  `page_setp_heading_id` int(11) DEFAULT NULL,
  `set_font_family_id` int(11) NOT NULL,
  `text_decoration_id` int(11) NOT NULL,
  `text_transform_id` int(11) NOT NULL,
  `word_space_param_id` int(11) NOT NULL,
  PRIMARY KEY (`page_setup_values_id`),
  KEY `FK_rqbx8ukws3ca75o74hdiigb58` (`alignment_id`),
  KEY `FK_k5u96agf81ixwp11uxwpw00l2` (`font_size_params_id`),
  KEY `FK_bte0yanfwsyxib2p3mxnhil5b` (`font_style_id`),
  KEY `FK_sits87t7iw80cj76uuaqxebiv` (`letter_space_param_id`),
  KEY `FK_rv3r6vu269wa7nac55il5qaj2` (`margin_bottom_param_id`),
  KEY `FK_a4ih70ftyyhwyw0wgw7kgf1em` (`margin_float_id`),
  KEY `FK_ijqq6xredmmjrkuwei9cbc6hw` (`margin_left_param_id`),
  KEY `FK_7txm1avwwepfq9c1nvqtg38ox` (`margin_right_param_id`),
  KEY `FK_1v8rpmdikgqaviuwnchwd4l2c` (`margin_top_param_id`),
  KEY `FK_ngo58cobonucisoyj0p8kwr05` (`padding_param_id`),
  KEY `FK_hh6kvh7flmekymqo82pvlhwku` (`page_setp_heading_id`),
  KEY `FK_hyvg8o9woeqh7j25xtn4aclqv` (`set_font_family_id`),
  KEY `FK_ewmga1jvspnyc73y1nh4ggjp` (`text_decoration_id`),
  KEY `FK_jh1k2i3maotgldc9iiehyf8mm` (`text_transform_id`),
  KEY `FK_ae76ho7y0lyu2evs30fap0f5k` (`word_space_param_id`),
  CONSTRAINT `FK_1v8rpmdikgqaviuwnchwd4l2c` FOREIGN KEY (`margin_top_param_id`) REFERENCES `text_length_master` (`table_length_master_id`),
  CONSTRAINT `FK_7txm1avwwepfq9c1nvqtg38ox` FOREIGN KEY (`margin_right_param_id`) REFERENCES `text_length_master` (`table_length_master_id`),
  CONSTRAINT `FK_a4ih70ftyyhwyw0wgw7kgf1em` FOREIGN KEY (`margin_float_id`) REFERENCES `text_float_master` (`text_float_master_id`),
  CONSTRAINT `FK_ae76ho7y0lyu2evs30fap0f5k` FOREIGN KEY (`word_space_param_id`) REFERENCES `text_length_master` (`table_length_master_id`),
  CONSTRAINT `FK_bte0yanfwsyxib2p3mxnhil5b` FOREIGN KEY (`font_style_id`) REFERENCES `text_font_style_master` (`text_font_style_id`),
  CONSTRAINT `FK_ewmga1jvspnyc73y1nh4ggjp` FOREIGN KEY (`text_decoration_id`) REFERENCES `text_decoration_master` (`text_decoration_master_id`),
  CONSTRAINT `FK_hh6kvh7flmekymqo82pvlhwku` FOREIGN KEY (`page_setp_heading_id`) REFERENCES `page_setup_heading` (`page_setup_heading_id`),
  CONSTRAINT `FK_hyvg8o9woeqh7j25xtn4aclqv` FOREIGN KEY (`set_font_family_id`) REFERENCES `font_family_master` (`font_family_master_id`),
  CONSTRAINT `FK_ijqq6xredmmjrkuwei9cbc6hw` FOREIGN KEY (`margin_left_param_id`) REFERENCES `text_length_master` (`table_length_master_id`),
  CONSTRAINT `FK_jh1k2i3maotgldc9iiehyf8mm` FOREIGN KEY (`text_transform_id`) REFERENCES `text_transform_master` (`text_transform_master_id`),
  CONSTRAINT `FK_k5u96agf81ixwp11uxwpw00l2` FOREIGN KEY (`font_size_params_id`) REFERENCES `text_length_master` (`table_length_master_id`),
  CONSTRAINT `FK_ngo58cobonucisoyj0p8kwr05` FOREIGN KEY (`padding_param_id`) REFERENCES `text_length_master` (`table_length_master_id`),
  CONSTRAINT `FK_rqbx8ukws3ca75o74hdiigb58` FOREIGN KEY (`alignment_id`) REFERENCES `text_align_master` (`text_align_master_id`),
  CONSTRAINT `FK_rv3r6vu269wa7nac55il5qaj2` FOREIGN KEY (`margin_bottom_param_id`) REFERENCES `text_length_master` (`table_length_master_id`),
  CONSTRAINT `FK_sits87t7iw80cj76uuaqxebiv` FOREIGN KEY (`letter_space_param_id`) REFERENCES `text_length_master` (`table_length_master_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.pathology_master
CREATE TABLE IF NOT EXISTS `pathology_master` (
  `pathology_id` int(11) NOT NULL AUTO_INCREMENT,
  `pathology_desc` text NOT NULL,
  `hospital_id` int(8) NOT NULL,
  `user_id` int(8) NOT NULL,
  `status_id` int(8) NOT NULL,
  `is_editable_id` int(2) NOT NULL,
  PRIMARY KEY (`pathology_id`),
  KEY `FK_compliant_master1_hospital_master` (`hospital_id`),
  KEY `FK_compliant_master1_login_master` (`user_id`),
  KEY `FK_compliant_master1_status_master` (`status_id`),
  KEY `FK_compliant_master1_is_editable_master` (`is_editable_id`),
  CONSTRAINT `pathology_master_ibfk_1` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `pathology_master_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`),
  CONSTRAINT `pathology_master_ibfk_3` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `pathology_master_ibfk_4` FOREIGN KEY (`is_editable_id`) REFERENCES `is_editable_master` (`is_editable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.patient_charges_billing
CREATE TABLE IF NOT EXISTS `patient_charges_billing` (
  `patient_charges_billing_id` int(11) NOT NULL AUTO_INCREMENT,
  `charge_billing_date` date NOT NULL,
  `charge_item_discount_rate` double DEFAULT NULL,
  `charge_item_qty` int(11) NOT NULL,
  `charge_item_rate` double NOT NULL,
  `charge_item_total` double NOT NULL,
  `last_updated` datetime NOT NULL,
  `charge_item_id` int(11) NOT NULL,
  `hospital_id` int(11) NOT NULL,
  `patient_fees_payment_map_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`patient_charges_billing_id`),
  KEY `FK_2dwpieui6qldodnu50vrbek0f` (`charge_item_id`),
  KEY `FK_97b1bv9njrchogcwwfkya1eae` (`hospital_id`),
  KEY `FK_oap8t8y2ok1b24e36t292fu1` (`patient_fees_payment_map_id`),
  KEY `FK_gy0ae5d9hax3e30fftrbusfu3` (`status_id`),
  KEY `FK_2rp98mw2hoc2o96sj1tewo3iy` (`user_id`),
  CONSTRAINT `FK_2dwpieui6qldodnu50vrbek0f` FOREIGN KEY (`charge_item_id`) REFERENCES `charge_item_master` (`charge_item_id`),
  CONSTRAINT `FK_2rp98mw2hoc2o96sj1tewo3iy` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`),
  CONSTRAINT `FK_97b1bv9njrchogcwwfkya1eae` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_gy0ae5d9hax3e30fftrbusfu3` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_oap8t8y2ok1b24e36t292fu1` FOREIGN KEY (`patient_fees_payment_map_id`) REFERENCES `patient_map` (`patient_fees_payment_map_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.patient_complaint_details
CREATE TABLE IF NOT EXISTS `patient_complaint_details` (
  `patient_complaint_details_id` int(11) NOT NULL AUTO_INCREMENT,
  `notes` longtext,
  `times` int(11) DEFAULT NULL,
  `complaint_category_id` int(11) DEFAULT NULL,
  `complaint_id` int(11) NOT NULL,
  `hospital_id` int(11) NOT NULL,
  `patient_fees_payment_map_id` int(11) NOT NULL,
  `persistence_id` int(11) NOT NULL,
  `severity_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `period_count` int(11) DEFAULT NULL,
  `health_status_id` int(11) DEFAULT NULL,
  `period_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`patient_complaint_details_id`),
  KEY `FK_4kidnemdf08uu2v15ncbt57up` (`complaint_category_id`),
  KEY `FK_5mfx8p1rweb6h3o526t3urxw1` (`complaint_id`),
  KEY `FK_k6orsdik3gdosx5nli9ang9aj` (`hospital_id`),
  KEY `FK_555shoy5cnmdnefcrgtn05p2w` (`patient_fees_payment_map_id`),
  KEY `FK_2dljtrh0qklytwxrpddl2jgwe` (`persistence_id`),
  KEY `FK_k8m4egbnoi1stkap63nat7sjj` (`severity_id`),
  KEY `FK_hjaeu5vsr7b40t190imtbev9s` (`status_id`),
  KEY `FK_dpbm5spq7rc3pn6aabtieni6n` (`user_id`),
  KEY `FK_t5tpumgp6rjnrt5upgr90h64y` (`health_status_id`),
  KEY `FK_4xvvh6uv342r771jt53j7t893` (`period_id`),
  CONSTRAINT `FK_2dljtrh0qklytwxrpddl2jgwe` FOREIGN KEY (`persistence_id`) REFERENCES `persistence_master` (`persistence_id`),
  CONSTRAINT `FK_4kidnemdf08uu2v15ncbt57up` FOREIGN KEY (`complaint_category_id`) REFERENCES `complaint_category_master` (`complaint_category_id`),
  CONSTRAINT `FK_4xvvh6uv342r771jt53j7t893` FOREIGN KEY (`period_id`) REFERENCES `period_master` (`period_id`),
  CONSTRAINT `FK_555shoy5cnmdnefcrgtn05p2w` FOREIGN KEY (`patient_fees_payment_map_id`) REFERENCES `patient_map` (`patient_fees_payment_map_id`),
  CONSTRAINT `FK_5mfx8p1rweb6h3o526t3urxw1` FOREIGN KEY (`complaint_id`) REFERENCES `complaint_master` (`complaint_id`),
  CONSTRAINT `FK_dpbm5spq7rc3pn6aabtieni6n` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`),
  CONSTRAINT `FK_hjaeu5vsr7b40t190imtbev9s` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_k6orsdik3gdosx5nli9ang9aj` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_k8m4egbnoi1stkap63nat7sjj` FOREIGN KEY (`severity_id`) REFERENCES `severity_master` (`severity_id`),
  CONSTRAINT `FK_t5tpumgp6rjnrt5upgr90h64y` FOREIGN KEY (`health_status_id`) REFERENCES `health_status_master` (`health_status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.patient_complaint_history
CREATE TABLE IF NOT EXISTS `patient_complaint_history` (
  `patient_complaint_history_id` int(11) NOT NULL AUTO_INCREMENT,
  `hospital_name` varchar(255) DEFAULT NULL,
  `notes` longtext,
  `surgery_detail` longtext,
  `complaint_id` int(11) NOT NULL,
  `hospital_id` int(11) NOT NULL,
  `patient_fees_payment_map_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`patient_complaint_history_id`),
  KEY `FK_npvoqspnh0di6gc1opcbx0hwc` (`complaint_id`),
  KEY `FK_3dm659x7bkf21jsym1viv00ny` (`hospital_id`),
  KEY `FK_j0vmlxfygjtwvedu3uxnfehu8` (`patient_fees_payment_map_id`),
  KEY `FK_28f7aadbajlk9p19bvb4jsp5s` (`status_id`),
  KEY `FK_35y72tx4aai8gy5auauses21a` (`user_id`),
  CONSTRAINT `FK_28f7aadbajlk9p19bvb4jsp5s` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_35y72tx4aai8gy5auauses21a` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`),
  CONSTRAINT `FK_3dm659x7bkf21jsym1viv00ny` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_j0vmlxfygjtwvedu3uxnfehu8` FOREIGN KEY (`patient_fees_payment_map_id`) REFERENCES `patient_map` (`patient_fees_payment_map_id`),
  CONSTRAINT `FK_npvoqspnh0di6gc1opcbx0hwc` FOREIGN KEY (`complaint_id`) REFERENCES `complaint_master` (`complaint_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.patient_examination_details
CREATE TABLE IF NOT EXISTS `patient_examination_details` (
  `patient_examination_details_id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_fees_payment_map_id` int(11) NOT NULL,
  `pulse_rate` int(3) DEFAULT NULL,
  `temp` int(3) DEFAULT NULL,
  `respiration_rate` int(3) DEFAULT NULL,
  `blood_pressure1` int(3) DEFAULT NULL,
  `blood_pressure2` int(3) DEFAULT NULL,
  `heart_rate` int(3) DEFAULT NULL,
  `weight` int(3) DEFAULT NULL,
  `height` int(3) DEFAULT NULL,
  `finding` longtext,
  `mental_desc` longtext,
  `nerves_desc` longtext,
  `impression_desc` longtext,
  `gaif_desc` longtext,
  `motor_desc` longtext,
  `reflexes_desc` longtext,
  `hospital_id` int(8) NOT NULL,
  `user_id` int(8) NOT NULL,
  `status_id` int(8) NOT NULL,
  PRIMARY KEY (`patient_examination_details_id`),
  KEY `FK_patient_examination_details_patient_map` (`patient_fees_payment_map_id`),
  KEY `FK_patient_examination_details_hospital_master` (`hospital_id`),
  KEY `FK_patient_examination_details_login_master` (`user_id`),
  KEY `FK_patient_examination_details_status_master` (`status_id`),
  CONSTRAINT `FK_patient_examination_details_hospital_master` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_patient_examination_details_login_master` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`),
  CONSTRAINT `FK_patient_examination_details_patient_map` FOREIGN KEY (`patient_fees_payment_map_id`) REFERENCES `patient_map` (`patient_fees_payment_map_id`),
  CONSTRAINT `FK_patient_examination_details_status_master` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.patient_family_history
CREATE TABLE IF NOT EXISTS `patient_family_history` (
  `patient_family_history_id` int(11) NOT NULL AUTO_INCREMENT,
  `age` int(11) DEFAULT NULL,
  `notes` longtext NOT NULL,
  `relation_name` varchar(255) NOT NULL,
  `complaint_id` int(11) NOT NULL,
  `health_status_id` int(11) DEFAULT NULL,
  `hospital_id` int(11) NOT NULL,
  `patient_fees_payment_map_id` int(11) NOT NULL,
  `relationship_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`patient_family_history_id`),
  KEY `FK_aixgx7997obshwvyp8l1goexj` (`complaint_id`),
  KEY `FK_h5dmpb07mtg3qjiio4941uxod` (`health_status_id`),
  KEY `FK_gtlxjws92rx3affkfggekilwf` (`hospital_id`),
  KEY `FK_hnvq13ji0octu1ep99hm9ogxk` (`patient_fees_payment_map_id`),
  KEY `FK_iknj5npsp5l6key40p5nmxwxs` (`relationship_id`),
  KEY `FK_ap0e9aeacfxdtug5pxhe6kf1b` (`status_id`),
  KEY `FK_pxriy1st7921adaiacr3pgk21` (`user_id`),
  CONSTRAINT `FK_aixgx7997obshwvyp8l1goexj` FOREIGN KEY (`complaint_id`) REFERENCES `complaint_master` (`complaint_id`),
  CONSTRAINT `FK_ap0e9aeacfxdtug5pxhe6kf1b` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_gtlxjws92rx3affkfggekilwf` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_h5dmpb07mtg3qjiio4941uxod` FOREIGN KEY (`health_status_id`) REFERENCES `health_status_master` (`health_status_id`),
  CONSTRAINT `FK_hnvq13ji0octu1ep99hm9ogxk` FOREIGN KEY (`patient_fees_payment_map_id`) REFERENCES `patient_map` (`patient_fees_payment_map_id`),
  CONSTRAINT `FK_iknj5npsp5l6key40p5nmxwxs` FOREIGN KEY (`relationship_id`) REFERENCES `relationship_master` (`relationship_id`),
  CONSTRAINT `FK_pxriy1st7921adaiacr3pgk21` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.patient_fees_details
CREATE TABLE IF NOT EXISTS `patient_fees_details` (
  `patient_fees_details_id` int(11) NOT NULL AUTO_INCREMENT,
  `discount_amt` double NOT NULL,
  `doctor_fees` double NOT NULL,
  `fees_date` date NOT NULL,
  `hospital_fees` double NOT NULL,
  `last_updated` datetime NOT NULL,
  `refund_amt` double NOT NULL,
  `total_fees` double NOT NULL,
  `emp_id` int(11) DEFAULT NULL,
  `test_patients_details_id` int(11) DEFAULT NULL,
  `hospital_id` int(11) NOT NULL,
  `patient_fees_payment_map_id` int(11) NOT NULL,
  `payment_src_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `emp_charge_type` varchar(255) NOT NULL,
  PRIMARY KEY (`patient_fees_details_id`),
  KEY `FK_bg0bjp78hq7vcug51hxx6w0dq` (`emp_id`),
  KEY `FK_3wsr7mrmjj0s6w4oo7cxjuhwp` (`hospital_id`),
  KEY `FK_6b8kygj5wfclh361jupjrmnvg` (`patient_fees_payment_map_id`),
  KEY `FK_r1ke4r1cca2p1bx67uc7qx8v9` (`payment_src_id`),
  KEY `FK_rcu6q9w915tpgigoo2xot1fvw` (`status_id`),
  KEY `FK_sc4wk36351yr12vbmg6i5f55b` (`user_id`),
  KEY `FK_patient_fees_details_lab_id` (`test_patients_details_id`),
  CONSTRAINT `FK_3wsr7mrmjj0s6w4oo7cxjuhwp` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_6b8kygj5wfclh361jupjrmnvg` FOREIGN KEY (`patient_fees_payment_map_id`) REFERENCES `patient_map` (`patient_fees_payment_map_id`),
  CONSTRAINT `FK_bg0bjp78hq7vcug51hxx6w0dq` FOREIGN KEY (`emp_id`) REFERENCES `emp_info` (`emp_id`),
  CONSTRAINT `FK_patient_fees_details_lab_id` FOREIGN KEY (`test_patients_details_id`) REFERENCES `test_patients_details` (`test_patients_details_id`),
  CONSTRAINT `FK_r1ke4r1cca2p1bx67uc7qx8v9` FOREIGN KEY (`payment_src_id`) REFERENCES `payment_source_master` (`payment_src_id`),
  CONSTRAINT `FK_rcu6q9w915tpgigoo2xot1fvw` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_sc4wk36351yr12vbmg6i5f55b` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.patient_history
CREATE TABLE IF NOT EXISTS `patient_history` (
  `patient_history_id` int(11) NOT NULL AUTO_INCREMENT,
  `allergy_type` longtext,
  `exercise_type` longtext,
  `life_style` longtext,
  `notes` longtext,
  `diet_id` int(11) DEFAULT NULL,
  `drinking_id` int(11) DEFAULT NULL,
  `hospital_id` int(11) NOT NULL,
  `patient_fees_payment_map_id` int(11) NOT NULL,
  `smoking_id` int(11) DEFAULT NULL,
  `status_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`patient_history_id`),
  KEY `FK_erv0tt6tkci4ew4wmsloabt1k` (`diet_id`),
  KEY `FK_9bjf5emvx3e7xluwljhp7rk3c` (`drinking_id`),
  KEY `FK_2yjcp9dsma4tul6n88noi8yul` (`hospital_id`),
  KEY `FK_i7wnut5ptyt57acvbdcuo0gge` (`patient_fees_payment_map_id`),
  KEY `FK_e4b759igmjk3yh6yo28lc4gjy` (`smoking_id`),
  KEY `FK_94vlf3pgq25ru5k1xwir8aymf` (`status_id`),
  KEY `FK_sktu7nc5hn847tnpuiow0pjck` (`user_id`),
  CONSTRAINT `FK_2yjcp9dsma4tul6n88noi8yul` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_94vlf3pgq25ru5k1xwir8aymf` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_9bjf5emvx3e7xluwljhp7rk3c` FOREIGN KEY (`drinking_id`) REFERENCES `drinking_master` (`drinking_id`),
  CONSTRAINT `FK_e4b759igmjk3yh6yo28lc4gjy` FOREIGN KEY (`smoking_id`) REFERENCES `smoking_master` (`smoking_id`),
  CONSTRAINT `FK_erv0tt6tkci4ew4wmsloabt1k` FOREIGN KEY (`diet_id`) REFERENCES `diet_master` (`diet_id`),
  CONSTRAINT `FK_i7wnut5ptyt57acvbdcuo0gge` FOREIGN KEY (`patient_fees_payment_map_id`) REFERENCES `patient_map` (`patient_fees_payment_map_id`),
  CONSTRAINT `FK_sktu7nc5hn847tnpuiow0pjck` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.patient_map
CREATE TABLE IF NOT EXISTS `patient_map` (
  `patient_fees_payment_map_id` int(11) NOT NULL AUTO_INCREMENT,
  `last_updated` date NOT NULL,
  `patient_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `payment_status` char(1) NOT NULL DEFAULT 'N',
  PRIMARY KEY (`patient_fees_payment_map_id`),
  KEY `FK_1myekj6m499hi54wrkast96sb` (`patient_id`),
  KEY `FK_4qi6s1v8nb53jcoe1wruup97d` (`status_id`),
  CONSTRAINT `FK_1myekj6m499hi54wrkast96sb` FOREIGN KEY (`patient_id`) REFERENCES `patient_personal_details` (`patient_id`),
  CONSTRAINT `FK_4qi6s1v8nb53jcoe1wruup97d` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.patient_paymentmode
CREATE TABLE IF NOT EXISTS `patient_paymentmode` (
  `pataient_payment_mod_Id` int(11) NOT NULL,
  `payment_name` varchar(50) NOT NULL,
  `status_id` int(11) NOT NULL,
  PRIMARY KEY (`pataient_payment_mod_Id`),
  KEY `emp_paymentmode_statusIdFK` (`status_id`),
  CONSTRAINT `emp_paymentmode_statusIdFK` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.patient_payment_details
CREATE TABLE IF NOT EXISTS `patient_payment_details` (
  `patient_payment_details` int(11) NOT NULL AUTO_INCREMENT,
  `last_updated` datetime NOT NULL,
  `payment_amount` double NOT NULL,
  `payment_date` date NOT NULL,
  `payment_serial_no` varchar(50) NOT NULL,
  `hospital_id` int(11) NOT NULL,
  `patient_fees_payment_map_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `payment_method_id` int(11) NOT NULL,
  `test_patients_details_id` int(11) DEFAULT NULL,
  `payment_src_id` int(11) NOT NULL,
  PRIMARY KEY (`patient_payment_details`),
  KEY `FK_rnobo1pv6f8ih17sb2yee15ge` (`hospital_id`),
  KEY `FK_aumayg7xnmg59hufuxa7h8q5h` (`patient_fees_payment_map_id`),
  KEY `FK_c7pj5pus375i4fqejwll7wqgt` (`status_id`),
  KEY `FK_1q8bf7mobw0t6i86olc869kgo` (`user_id`),
  KEY `FK_516bcjuykkv836kna2dwu5sg4` (`payment_method_id`),
  KEY `FK_8du2jhqaa0im3dt6yorya8nfi` (`test_patients_details_id`),
  KEY `FK_5gpxl9m2j6q54ai20yihvcykr` (`payment_src_id`),
  CONSTRAINT `FK_1q8bf7mobw0t6i86olc869kgo` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`),
  CONSTRAINT `FK_516bcjuykkv836kna2dwu5sg4` FOREIGN KEY (`payment_method_id`) REFERENCES `payment_method_master` (`payment_method_id`),
  CONSTRAINT `FK_5gpxl9m2j6q54ai20yihvcykr` FOREIGN KEY (`payment_src_id`) REFERENCES `payment_source_master` (`payment_src_id`),
  CONSTRAINT `FK_8du2jhqaa0im3dt6yorya8nfi` FOREIGN KEY (`test_patients_details_id`) REFERENCES `test_patients_details` (`test_patients_details_id`),
  CONSTRAINT `FK_aumayg7xnmg59hufuxa7h8q5h` FOREIGN KEY (`patient_fees_payment_map_id`) REFERENCES `patient_map` (`patient_fees_payment_map_id`),
  CONSTRAINT `FK_c7pj5pus375i4fqejwll7wqgt` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_rnobo1pv6f8ih17sb2yee15ge` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.patient_personal_details
CREATE TABLE IF NOT EXISTS `patient_personal_details` (
  `patient_id` int(8) NOT NULL AUTO_INCREMENT,
  `patient_name` varchar(200) NOT NULL,
  `patient_gender_id` int(8) DEFAULT '0',
  `patient_type_id` int(11) DEFAULT NULL,
  `patient_age` int(3) DEFAULT '0',
  `patient_dob` date DEFAULT '0000-00-00',
  `patient_address` text,
  `patient_pincode` varchar(7) DEFAULT NULL,
  `patient_mobile_contact` varchar(20) DEFAULT NULL,
  `patient_landline_contact` varchar(20) DEFAULT NULL,
  `company_address` text,
  `company_pincode` varchar(7) DEFAULT NULL,
  `company_phone` varchar(20) DEFAULT NULL,
  `guardian_name` varchar(50) DEFAULT NULL,
  `guardian_type_id` int(11) DEFAULT NULL,
  `blood_group_id` int(11) DEFAULT NULL,
  `martial_type_id` int(8) DEFAULT NULL,
  `email_id` varchar(100) DEFAULT '',
  `status_Id` int(2) NOT NULL,
  `user_id` int(8) NOT NULL,
  `hospital_id` int(8) NOT NULL,
  `patient_income` double(20,2) DEFAULT NULL,
  `patient_occupation` varchar(200) DEFAULT NULL,
  `patient_height` double(20,2) DEFAULT NULL,
  `patient_weight` double(20,2) DEFAULT NULL,
  `insurance_status` varchar(200) DEFAULT NULL,
  `mlc_no` varchar(200) DEFAULT NULL,
  `accident_register` varchar(200) DEFAULT NULL,
  `extra_attenders` text,
  `last_updated` datetime NOT NULL,
  `patient_prefix_id` varchar(255) DEFAULT NULL,
  `patient_bmi` double(20,2) DEFAULT NULL,
  `patient_paymentmode_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`patient_id`),
  KEY `FK736AC13D54DA6D59` (`user_id`),
  KEY `FK_patient_personal_details_gender` (`patient_gender_id`),
  KEY `FK_patient_personal_details_hospital_id` (`hospital_id`),
  KEY `FK_patient_personal_details_status_Id` (`status_Id`),
  KEY `FK_patient_personal_details_blood_group_id` (`blood_group_id`),
  KEY `FK_3xi4mnqfsrp7dtqb59813wfjd` (`guardian_type_id`),
  KEY `FK_patient_personal_details_martial_type_id` (`martial_type_id`),
  KEY `FK_patient_personal_details_paymentmode_id` (`patient_paymentmode_id`),
  KEY `FK_patient_personal_details_patient_type_id` (`patient_type_id`),
  CONSTRAINT `FK736AC13D54DA6D59` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`),
  CONSTRAINT `FK_3xi4mnqfsrp7dtqb59813wfjd` FOREIGN KEY (`guardian_type_id`) REFERENCES `guardian_type_master` (`guardian_type_master_id`),
  CONSTRAINT `FK_patient_personal_details_blood_group_id` FOREIGN KEY (`blood_group_id`) REFERENCES `blood_group_master` (`blood_group_master_id`),
  CONSTRAINT `FK_patient_personal_details_gender` FOREIGN KEY (`patient_gender_id`) REFERENCES `gender_master` (`gender_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_patient_personal_details_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_patient_personal_details_martial_type_id` FOREIGN KEY (`martial_type_id`) REFERENCES `martial_type_master` (`martial_status_master_id`),
  CONSTRAINT `FK_patient_personal_details_patient_type_id` FOREIGN KEY (`patient_type_id`) REFERENCES `patient_type_master` (`patient_type_id`),
  CONSTRAINT `FK_patient_personal_details_paymentmode_id` FOREIGN KEY (`patient_paymentmode_id`) REFERENCES `patient_paymentmode` (`pataient_payment_mod_Id`),
  CONSTRAINT `FK_patient_personal_details_status_Id` FOREIGN KEY (`status_Id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.patient_refund_details
CREATE TABLE IF NOT EXISTS `patient_refund_details` (
  `patient_refund_details_id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_fees_payment_map_id` int(11) NOT NULL,
  `payment_method_id` int(11) NOT NULL,
  `test_patient_details_id` int(11) DEFAULT NULL,
  `payment_src_id` int(11) NOT NULL,
  `refund_amt` double NOT NULL,
  `refund_date` date NOT NULL,
  `status_id` int(11) NOT NULL,
  `hospital_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `last_updated` datetime NOT NULL,
  `refund_description` varchar(255) DEFAULT NULL,
  `refund_serial_no` varchar(255) NOT NULL,
  PRIMARY KEY (`patient_refund_details_id`),
  KEY `FK_patient_refund_details_patient_fees_payment_map_id` (`patient_fees_payment_map_id`),
  KEY `FK_patient_refund_details_payment_method_id` (`payment_method_id`),
  KEY `FK_patient_refund_details_test_patient_details_id` (`test_patient_details_id`),
  KEY `FK_patient_refund_details_payment_src_id` (`payment_src_id`),
  KEY `FK_patient_refund_details_status_id` (`status_id`),
  KEY `FK_patient_refund_details_hospital_id` (`hospital_id`),
  KEY `FK_patient_refund_details_user_id` (`user_id`),
  CONSTRAINT `FK_patient_refund_details_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_patient_refund_details_patient_fees_payment_map_id` FOREIGN KEY (`patient_fees_payment_map_id`) REFERENCES `patient_map` (`patient_fees_payment_map_id`),
  CONSTRAINT `FK_patient_refund_details_payment_method_id` FOREIGN KEY (`payment_method_id`) REFERENCES `payment_method_master` (`payment_method_id`),
  CONSTRAINT `FK_patient_refund_details_payment_src_id` FOREIGN KEY (`payment_src_id`) REFERENCES `payment_source_master` (`payment_src_id`),
  CONSTRAINT `FK_patient_refund_details_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_patient_refund_details_test_patient_details_id` FOREIGN KEY (`test_patient_details_id`) REFERENCES `test_patients_details` (`test_patients_details_id`),
  CONSTRAINT `FK_patient_refund_details_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.patient_type_master
CREATE TABLE IF NOT EXISTS `patient_type_master` (
  `patient_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_type_master` varchar(50) NOT NULL,
  `status_id` int(11) NOT NULL,
  PRIMARY KEY (`patient_type_id`),
  KEY `FK_patient_type_master_status_id` (`status_id`),
  CONSTRAINT `FK_patient_type_master_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.payment_method_master
CREATE TABLE IF NOT EXISTS `payment_method_master` (
  `payment_method_id` int(11) NOT NULL AUTO_INCREMENT,
  `last_updated` datetime NOT NULL,
  `payment_method_name` varchar(255) NOT NULL,
  `status_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `hospital_id` int(11) NOT NULL,
  `is_editable_id` int(11) NOT NULL,
  PRIMARY KEY (`payment_method_id`),
  KEY `FK_4kqfne8ruo4f4bmoumohfchku` (`status_id`),
  KEY `FK_cclax6xlqh8q77muibgmi265g` (`user_id`),
  KEY `FK_c8eh9q74xp71h787c3kcvbtxg` (`hospital_id`),
  KEY `FK_ie93ldeobqqmr26xm8ubpndvq` (`is_editable_id`),
  CONSTRAINT `FK_4kqfne8ruo4f4bmoumohfchku` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_c8eh9q74xp71h787c3kcvbtxg` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_cclax6xlqh8q77muibgmi265g` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`),
  CONSTRAINT `FK_ie93ldeobqqmr26xm8ubpndvq` FOREIGN KEY (`is_editable_id`) REFERENCES `is_editable_master` (`is_editable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.payment_number_genrator
CREATE TABLE IF NOT EXISTS `payment_number_genrator` (
  `payment_genrater_id` int(11) NOT NULL AUTO_INCREMENT,
  `payment_number` varchar(255) NOT NULL,
  `hospital_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`payment_genrater_id`),
  KEY `FK_q1h4ns7yl3d5qbb9vfvi6c8y0` (`hospital_id`),
  KEY `FK_c9q567hfrvtfqxfyeg0idhrkg` (`status_id`),
  KEY `FK_lckc713pn2569hj5lx72kj5bu` (`user_id`),
  CONSTRAINT `FK_c9q567hfrvtfqxfyeg0idhrkg` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_lckc713pn2569hj5lx72kj5bu` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`),
  CONSTRAINT `FK_q1h4ns7yl3d5qbb9vfvi6c8y0` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.payment_receive_deatils
CREATE TABLE IF NOT EXISTS `payment_receive_deatils` (
  `payemnt_rcevied_id` int(11) NOT NULL,
  PRIMARY KEY (`payemnt_rcevied_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.payment_remarks_history
CREATE TABLE IF NOT EXISTS `payment_remarks_history` (
  `remarks_id` int(20) NOT NULL,
  `remarks_desc` varchar(200) DEFAULT NULL,
  `hospital_id` int(20) DEFAULT NULL,
  `status_id` int(20) DEFAULT NULL,
  `last_update` datetime DEFAULT NULL,
  PRIMARY KEY (`remarks_id`),
  KEY `payment_remarks_history_hospital_id` (`hospital_id`),
  KEY `payment_remarks_history_status_id` (`status_id`),
  CONSTRAINT `payment_remarks_history_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `payment_remarks_history_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.payment_source_master
CREATE TABLE IF NOT EXISTS `payment_source_master` (
  `payment_src_id` int(11) NOT NULL AUTO_INCREMENT,
  `last_updated` datetime NOT NULL,
  `payment_src_name` varchar(255) NOT NULL,
  `status_id` int(11) NOT NULL,
  PRIMARY KEY (`payment_src_id`),
  KEY `FK_840wwqmm5lxgd2elp7giubbfo` (`status_id`),
  CONSTRAINT `FK_840wwqmm5lxgd2elp7giubbfo` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.payment_type_master
CREATE TABLE IF NOT EXISTS `payment_type_master` (
  `payment_type_id` int(11) NOT NULL,
  `payment_type` varchar(255) NOT NULL,
  PRIMARY KEY (`payment_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.payslip_emp_info
CREATE TABLE IF NOT EXISTS `payslip_emp_info` (
  `payslip_emp_info_id` int(8) NOT NULL AUTO_INCREMENT,
  `payslip_id` int(8) NOT NULL,
  `emp_id` int(8) NOT NULL,
  `basic_total` double(20,2) NOT NULL,
  `income_total` double(20,2) NOT NULL,
  `deduction_total` double(20,2) NOT NULL,
  `net_salary` double(20,2) NOT NULL,
  `last_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `status_id` int(1) NOT NULL,
  `days_worked` int(11) NOT NULL,
  `holiday_leave` int(11) NOT NULL,
  `paid_leave_days` int(11) NOT NULL,
  `unpaid_leave_days` int(11) NOT NULL,
  `weekly_days_leave` int(11) NOT NULL,
  `hospital_id` int(11) NOT NULL,
  PRIMARY KEY (`payslip_emp_info_id`),
  KEY `payslip_emp_info_payslip_id` (`payslip_id`),
  KEY `payslip_emp_id` (`emp_id`),
  KEY `payslip_emp_status_id` (`status_id`),
  KEY `FK_4x6ccb64bx34t5ycdxdad3kl2` (`hospital_id`),
  CONSTRAINT `FK_4x6ccb64bx34t5ycdxdad3kl2` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `payslip_emp_id` FOREIGN KEY (`emp_id`) REFERENCES `emp_info` (`emp_id`),
  CONSTRAINT `payslip_emp_info_payslip_id` FOREIGN KEY (`payslip_id`) REFERENCES `payslip_info` (`payslip_info_id`),
  CONSTRAINT `payslip_emp_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.payslip_info
CREATE TABLE IF NOT EXISTS `payslip_info` (
  `payslip_info_id` int(8) NOT NULL AUTO_INCREMENT,
  `hospital_id` int(8) NOT NULL,
  `annual_year_id` int(8) NOT NULL,
  `month_id` int(8) NOT NULL,
  `salary_total` double(20,2) NOT NULL,
  `account_status` char(1) NOT NULL DEFAULT 'N',
  `generated_date` date NOT NULL,
  `user_id` int(8) NOT NULL,
  `last_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `payslip_start_date` date NOT NULL,
  `payslip_end_date` date NOT NULL,
  `days_in_month` int(11) NOT NULL,
  `working_days` int(8) NOT NULL DEFAULT '0',
  `week_days_leave` int(8) NOT NULL DEFAULT '0',
  `holiday_days_leave` int(8) NOT NULL DEFAULT '0',
  `status_id` int(1) NOT NULL,
  PRIMARY KEY (`payslip_info_id`),
  KEY `payslip_info_annual_year_id` (`annual_year_id`),
  KEY `payslip_info_hospital_id` (`hospital_id`),
  KEY `payslip_info_user_id` (`user_id`),
  KEY `payslip_info_status_id` (`status_id`),
  KEY `payslip_info_month_id` (`month_id`),
  CONSTRAINT `payslip_info_annual_year_id` FOREIGN KEY (`annual_year_id`) REFERENCES `annual_year_master` (`annual_year_master_id`),
  CONSTRAINT `payslip_info_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `payslip_info_month_id` FOREIGN KEY (`month_id`) REFERENCES `month_master` (`month_master_id`),
  CONSTRAINT `payslip_info_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `payslip_info_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.payslip_salary_breakup_info
CREATE TABLE IF NOT EXISTS `payslip_salary_breakup_info` (
  `payslip_salary_breakup_info_id` int(8) NOT NULL AUTO_INCREMENT,
  `payslip_emp_info_id` int(8) NOT NULL,
  `payslip_heads_id` int(8) NOT NULL,
  `payslip_heads_amount` double(20,2) NOT NULL,
  `status_id` int(1) NOT NULL,
  PRIMARY KEY (`payslip_salary_breakup_info_id`),
  KEY `payslip_breakup_emp_info_id` (`payslip_emp_info_id`),
  KEY `payslip_breakup_status_id` (`status_id`),
  KEY `payslip_breakup_heads_id` (`payslip_heads_id`),
  CONSTRAINT `payslip_breakup_emp_info_id` FOREIGN KEY (`payslip_emp_info_id`) REFERENCES `payslip_emp_info` (`payslip_emp_info_id`),
  CONSTRAINT `payslip_breakup_heads_id` FOREIGN KEY (`payslip_heads_id`) REFERENCES `salaryheads_master` (`salaryheads_master_id`),
  CONSTRAINT `payslip_breakup_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.period_master
CREATE TABLE IF NOT EXISTS `period_master` (
  `period_id` int(11) NOT NULL,
  `period_type` varchar(50) NOT NULL,
  `status_id` int(8) NOT NULL,
  PRIMARY KEY (`period_id`),
  KEY `FK__status_master` (`status_id`),
  CONSTRAINT `FK__status_master` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.persistence_master
CREATE TABLE IF NOT EXISTS `persistence_master` (
  `persistence_id` int(11) NOT NULL AUTO_INCREMENT,
  `persistence_info` text NOT NULL,
  `hospital_id` int(8) NOT NULL,
  `user_id` int(8) NOT NULL,
  `status_id` int(8) NOT NULL,
  `is_editable_id` int(2) NOT NULL,
  PRIMARY KEY (`persistence_id`),
  KEY `FK_persistence_master_hospital_master` (`hospital_id`),
  KEY `FK_persistence_master_login_master` (`user_id`),
  KEY `FK_persistence_master_status_master` (`status_id`),
  KEY `FK_persistence_master_is_editable_master` (`is_editable_id`),
  CONSTRAINT `FK_persistence_master_hospital_master` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_persistence_master_is_editable_master` FOREIGN KEY (`is_editable_id`) REFERENCES `is_editable_master` (`is_editable_id`),
  CONSTRAINT `FK_persistence_master_login_master` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`),
  CONSTRAINT `FK_persistence_master_status_master` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.prefix_master
CREATE TABLE IF NOT EXISTS `prefix_master` (
  `prefix_id` int(8) NOT NULL AUTO_INCREMENT,
  `prefix_code` char(10) NOT NULL,
  `prefix_number` varchar(7) NOT NULL,
  `hospital_id` int(8) NOT NULL,
  `user_id` int(8) NOT NULL,
  `prefix_type` int(8) NOT NULL,
  `status_id` int(8) NOT NULL,
  `last_updated` datetime NOT NULL,
  PRIMARY KEY (`prefix_id`),
  KEY `FK_prefix_master_hospital_id` (`hospital_id`),
  KEY `FK_prefix_master_user_id` (`user_id`),
  KEY `FK_prefix_master_status_id` (`status_id`),
  KEY `FK_prefix_master_type_id` (`prefix_type`),
  CONSTRAINT `FK_prefix_master_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_prefix_master_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_prefix_master_type_id` FOREIGN KEY (`prefix_type`) REFERENCES `prefix_type_master` (`prefix_type_master_id`),
  CONSTRAINT `FK_prefix_master_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.prefix_type_master
CREATE TABLE IF NOT EXISTS `prefix_type_master` (
  `prefix_type_master_id` int(8) NOT NULL,
  `prefix_name` varchar(100) NOT NULL,
  `status_id` int(8) NOT NULL,
  `last_updated` datetime NOT NULL,
  PRIMARY KEY (`prefix_type_master_id`),
  KEY `FK_prefix_type_master_status_id` (`status_id`),
  CONSTRAINT `FK_prefix_type_master_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.printing_template_master
CREATE TABLE IF NOT EXISTS `printing_template_master` (
  `printing_template_master_id` int(11) NOT NULL,
  `tempateName` varchar(255) NOT NULL,
  `hospital_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  PRIMARY KEY (`printing_template_master_id`),
  KEY `FK_fr0h1iy4mic1ue25n7kpkq46n` (`hospital_id`),
  KEY `FK_opk033kfvq3wgx6qyrdgm7wpb` (`status_id`),
  CONSTRAINT `FK_fr0h1iy4mic1ue25n7kpkq46n` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_opk033kfvq3wgx6qyrdgm7wpb` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for procedure testingteam.procedureNameSample
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `procedureNameSample`( )
BEGIN
select * from login_master ;         
END//
DELIMITER ;


-- Dumping structure for table testingteam.purpose_master
CREATE TABLE IF NOT EXISTS `purpose_master` (
  `purpose_id` int(11) NOT NULL AUTO_INCREMENT,
  `purpose_info` varchar(255) NOT NULL,
  `hospital_id` int(11) DEFAULT NULL,
  `status_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`purpose_id`),
  KEY `FK_hrgtxilkug95yee3qhpmxbyvq` (`hospital_id`),
  KEY `FK_l4yxfl85kn8uw1sjxtn47vsuy` (`status_id`),
  KEY `FK_e07kbqyi2l9uwfds2ae7fuyg5` (`user_id`),
  CONSTRAINT `FK_e07kbqyi2l9uwfds2ae7fuyg5` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`),
  CONSTRAINT `FK_hrgtxilkug95yee3qhpmxbyvq` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_l4yxfl85kn8uw1sjxtn47vsuy` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.receiver_type_master
CREATE TABLE IF NOT EXISTS `receiver_type_master` (
  `receiver_type_id` int(11) NOT NULL,
  `receiver_type` varchar(255) NOT NULL,
  PRIMARY KEY (`receiver_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.relationship_master
CREATE TABLE IF NOT EXISTS `relationship_master` (
  `relationship_id` int(11) NOT NULL AUTO_INCREMENT,
  `relationship_type` text NOT NULL,
  `hospital_id` int(8) NOT NULL,
  `user_id` int(8) NOT NULL,
  `status_id` int(8) NOT NULL,
  `is_editable_id` int(2) NOT NULL,
  PRIMARY KEY (`relationship_id`),
  KEY `FK_relationship_master_hospital_master` (`hospital_id`),
  KEY `FK_relationship_master_login_master` (`user_id`),
  KEY `FK_relationship_master_status_master` (`status_id`),
  KEY `FK_relationship_master_is_editable_master` (`is_editable_id`),
  CONSTRAINT `FK_relationship_master_hospital_master` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_relationship_master_is_editable_master` FOREIGN KEY (`is_editable_id`) REFERENCES `is_editable_master` (`is_editable_id`),
  CONSTRAINT `FK_relationship_master_login_master` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`),
  CONSTRAINT `FK_relationship_master_status_master` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.rights_master
CREATE TABLE IF NOT EXISTS `rights_master` (
  `rights_id` int(8) NOT NULL,
  `rights_name` varchar(20) NOT NULL,
  `status_id` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`rights_id`),
  KEY `FK_rights_master_status_id` (`status_id`),
  CONSTRAINT `FK_rights_master_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.room_available_status_info
CREATE TABLE IF NOT EXISTS `room_available_status_info` (
  `room_status_id` int(8) NOT NULL,
  `bed_id` int(8) NOT NULL,
  `hospital_id` int(8) NOT NULL,
  `user_id` int(8) NOT NULL,
  `from_date` date DEFAULT NULL,
  `to_date` date DEFAULT NULL,
  `available_status_id` int(8) NOT NULL,
  `last_updated` datetime NOT NULL,
  PRIMARY KEY (`room_status_id`),
  KEY `FK_room_available_status_info_hospital_id` (`hospital_id`),
  KEY `FK_room_available_status_info_user_id` (`user_id`),
  KEY `FK_room_available_status_info_availability_id` (`bed_id`),
  KEY `FK_room_available_status_info_available_status_id` (`available_status_id`),
  CONSTRAINT `FK_room_available_status_info_available_status_id` FOREIGN KEY (`available_status_id`) REFERENCES `availability_type_master` (`availability_type_master_id`),
  CONSTRAINT `FK_room_available_status_info_bed_id` FOREIGN KEY (`bed_id`) REFERENCES `bed_master` (`bed_id`),
  CONSTRAINT `FK_room_available_status_info_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_room_available_status_info_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.room_master
CREATE TABLE IF NOT EXISTS `room_master` (
  `room_id` int(8) NOT NULL,
  `room_name` varchar(100) NOT NULL,
  `ward_id` int(8) NOT NULL,
  `floor_id` int(8) NOT NULL,
  `room_type_id` int(8) NOT NULL,
  `bed_rate` double(20,2) NOT NULL DEFAULT '0.00',
  `advance_amt` double(20,2) DEFAULT '0.00',
  `user_id` int(8) NOT NULL,
  `status_id` int(1) NOT NULL,
  `hospital_id` int(8) NOT NULL,
  `last_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`room_id`),
  KEY `FK_room_master_floor_id` (`floor_id`),
  KEY `FK_room_master_ward_id` (`ward_id`),
  KEY `FK_room_master_status_id` (`status_id`),
  KEY `FK_room_master_user_id` (`user_id`),
  KEY `FK_room_master_room_type_id` (`room_type_id`),
  KEY `FK_room_master_hospital_id` (`hospital_id`),
  CONSTRAINT `FK_room_master_floor_id` FOREIGN KEY (`floor_id`) REFERENCES `floor_master` (`floor_id`),
  CONSTRAINT `FK_room_master_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_room_master_room_type_id` FOREIGN KEY (`room_type_id`) REFERENCES `room_type_master` (`room_type_id`),
  CONSTRAINT `FK_room_master_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_room_master_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`),
  CONSTRAINT `FK_room_master_ward_id` FOREIGN KEY (`ward_id`) REFERENCES `ward_master` (`ward_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.room_transfer_details
CREATE TABLE IF NOT EXISTS `room_transfer_details` (
  `room_transfer_details_id` int(8) NOT NULL,
  `room_status_id` int(8) NOT NULL,
  `src_bed_id` int(8) NOT NULL,
  `des_bed_id` int(8) NOT NULL,
  `transfer_date` date NOT NULL,
  `user_id` int(8) NOT NULL,
  `last_updated` datetime NOT NULL,
  PRIMARY KEY (`room_transfer_details_id`),
  KEY `FK_room_transfer_details_room_status_id` (`room_status_id`),
  KEY `FK_room_transfer_details_src_bed_id` (`src_bed_id`),
  KEY `FK_room_transfer_details_des_bed_id` (`des_bed_id`),
  KEY `FK_room_transfer_details_user_id` (`user_id`),
  CONSTRAINT `FK_room_transfer_details_des_bed_id` FOREIGN KEY (`des_bed_id`) REFERENCES `bed_master` (`bed_id`),
  CONSTRAINT `FK_room_transfer_details_room_status_id` FOREIGN KEY (`room_status_id`) REFERENCES `room_available_status_info` (`room_status_id`),
  CONSTRAINT `FK_room_transfer_details_src_bed_id` FOREIGN KEY (`src_bed_id`) REFERENCES `bed_master` (`bed_id`),
  CONSTRAINT `FK_room_transfer_details_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.room_type_master
CREATE TABLE IF NOT EXISTS `room_type_master` (
  `room_type_id` int(8) NOT NULL,
  `hospital_id` int(8) NOT NULL,
  `room_type_name` varchar(100) NOT NULL,
  `user_id` int(8) NOT NULL,
  `status_id` int(1) NOT NULL,
  `last_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`room_type_id`),
  KEY `FK_room_type_master_hospital_id` (`hospital_id`),
  KEY `FK_room_type_master_status_id` (`status_id`),
  KEY `FK_room_type_master_user_id` (`user_id`),
  CONSTRAINT `FK_room_type_master_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_room_type_master_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_room_type_master_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.salaryheads_cal_type_master
CREATE TABLE IF NOT EXISTS `salaryheads_cal_type_master` (
  `salaryheads_cal_type_master_id` int(8) NOT NULL,
  `salaryheads_cal_type_name` varchar(30) NOT NULL,
  `status_id` int(8) NOT NULL,
  PRIMARY KEY (`salaryheads_cal_type_master_id`),
  KEY `salary_head_value_type_status_id` (`status_id`),
  CONSTRAINT `salary_head_value_type_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.salaryheads_master
CREATE TABLE IF NOT EXISTS `salaryheads_master` (
  `salaryheads_master_id` int(8) NOT NULL AUTO_INCREMENT,
  `salaryheads_master_code` varchar(20) NOT NULL,
  `salaryheads_master_value` varchar(100) NOT NULL,
  `salaryheads_type_id` int(8) NOT NULL,
  `status_id` int(8) NOT NULL,
  `hospital_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `last_updated` date NOT NULL,
  PRIMARY KEY (`salaryheads_master_id`),
  KEY `salaryheads_type_id` (`salaryheads_type_id`),
  KEY `salaryheads_master_status_id` (`status_id`),
  KEY `salaryheads_hospital_id` (`hospital_id`),
  KEY `salaryheads_user_id` (`user_id`),
  CONSTRAINT `salaryheads_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `salaryheads_master_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `salaryheads_type_id` FOREIGN KEY (`salaryheads_type_id`) REFERENCES `salaryheads_primary_type_master` (`salaryheads_primary_type_master_id`),
  CONSTRAINT `salaryheads_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.salaryheads_primary_type_master
CREATE TABLE IF NOT EXISTS `salaryheads_primary_type_master` (
  `salaryheads_primary_type_master_id` int(8) NOT NULL AUTO_INCREMENT,
  `salaryheads_primary_type_name` varchar(20) NOT NULL,
  `status_id` int(11) NOT NULL,
  PRIMARY KEY (`salaryheads_primary_type_master_id`),
  KEY `salary_primary_type_status_id` (`status_id`),
  CONSTRAINT `salary_primary_type_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.salary_structure_details
CREATE TABLE IF NOT EXISTS `salary_structure_details` (
  `salary_structure_details_id` int(8) NOT NULL,
  `salaryheads_id` int(8) NOT NULL,
  `salary_master_id` int(8) NOT NULL,
  `status_id` int(11) NOT NULL,
  PRIMARY KEY (`salary_structure_details_id`),
  KEY `salary_structure_heads_id` (`salaryheads_id`),
  KEY `salary_structure_details_master_id` (`salary_master_id`),
  KEY `FK_oqbj0y8510f8dpqy13v70g8o0` (`status_id`),
  CONSTRAINT `FK_oqbj0y8510f8dpqy13v70g8o0` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `salary_structure_details_master_id` FOREIGN KEY (`salary_master_id`) REFERENCES `salary_strucutre_master` (`salary_structure_master_id`),
  CONSTRAINT `salary_structure_heads_id` FOREIGN KEY (`salaryheads_id`) REFERENCES `salaryheads_master` (`salaryheads_master_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.salary_strucutre_master
CREATE TABLE IF NOT EXISTS `salary_strucutre_master` (
  `salary_structure_master_id` int(8) NOT NULL,
  `salary_structure_name` varchar(100) NOT NULL,
  `user_id` int(8) NOT NULL,
  `hospital_id` int(8) NOT NULL,
  `status_id` int(8) NOT NULL,
  `last_updated` datetime NOT NULL,
  PRIMARY KEY (`salary_structure_master_id`),
  KEY `salary_structure_user_id` (`user_id`),
  KEY `salary_structure_status_id` (`status_id`),
  KEY `salary_structure_hospital_id` (`hospital_id`),
  CONSTRAINT `salary_structure_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `salary_structure_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `salary_structure_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.service_empmap_details
CREATE TABLE IF NOT EXISTS `service_empmap_details` (
  `app_service_empmap_id` int(11) NOT NULL AUTO_INCREMENT,
  `doctor_id` int(11) NOT NULL DEFAULT '0',
  `consultation_fees` double DEFAULT '0',
  `doctor_fees` double DEFAULT '0',
  `hos_fees` double DEFAULT '0',
  `app_service_id` int(11) NOT NULL DEFAULT '0',
  `status_id` int(11) NOT NULL DEFAULT '0',
  `check_status` char(50) DEFAULT NULL,
  `hospital_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`app_service_empmap_id`),
  KEY `FK_app_servicemap_doctor_id` (`doctor_id`),
  KEY `FK_app_servicemap_service_id` (`app_service_id`),
  KEY `FK_app_servicemap_status_id` (`status_id`),
  KEY `FK_app_servicemap_hospital_id` (`hospital_id`),
  KEY `FK_app_servicemap_user_id` (`user_id`),
  CONSTRAINT `FK_app_servicemap_doctor_id` FOREIGN KEY (`doctor_id`) REFERENCES `emp_info` (`emp_id`),
  CONSTRAINT `FK_app_servicemap_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_app_servicemap_service_id` FOREIGN KEY (`app_service_id`) REFERENCES `service_master` (`app_service_id`),
  CONSTRAINT `FK_app_servicemap_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_app_servicemap_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.service_master
CREATE TABLE IF NOT EXISTS `service_master` (
  `app_service_id` int(11) NOT NULL AUTO_INCREMENT,
  `service_name` varchar(50) DEFAULT NULL,
  `duration` varchar(50) NOT NULL,
  `service_color` varchar(50) DEFAULT NULL,
  `service_description` varchar(250) DEFAULT NULL,
  `status_id` int(11) NOT NULL,
  `hospital_id` int(11) NOT NULL,
  `yesorno_id` int(11) NOT NULL,
  `service_code` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`app_service_id`),
  KEY `FK_app_service_status_id` (`status_id`),
  KEY `FK_service_master_hospital_id` (`hospital_id`),
  KEY `FK_service_master_yesorno_id` (`yesorno_id`),
  CONSTRAINT `FK_app_service_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_service_master_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_service_master_yesorno_id` FOREIGN KEY (`yesorno_id`) REFERENCES `yes_no_master` (`yes_no_master_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.session_master
CREATE TABLE IF NOT EXISTS `session_master` (
  `session_id` varchar(100) NOT NULL DEFAULT '',
  `ipaddress` varchar(15) DEFAULT '',
  `start_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `end_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_name` varchar(30) NOT NULL DEFAULT '',
  `user_id` int(15) NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `FK_session_master_user_id` (`user_id`),
  CONSTRAINT `FK_session_master_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Session Master for tracking user sessions';

-- Data exporting was unselected.


-- Dumping structure for table testingteam.setup_header_menu
CREATE TABLE IF NOT EXISTS `setup_header_menu` (
  `setup_header_menu_id` int(8) NOT NULL,
  `setup_header_name` varchar(100) NOT NULL,
  `setup_header_image` varchar(300) DEFAULT '',
  `status_id` int(1) NOT NULL,
  PRIMARY KEY (`setup_header_menu_id`),
  KEY `setup_header_status_id` (`status_id`),
  CONSTRAINT `setup_header_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.setup_header_menu_super
CREATE TABLE IF NOT EXISTS `setup_header_menu_super` (
  `setup_header_menu_id` int(8) NOT NULL,
  `setup_header_name` varchar(150) NOT NULL,
  `setup_header_image` varchar(150) DEFAULT '',
  `status_id` int(1) NOT NULL,
  `setup_header_id` int(11) NOT NULL,
  `setup_header_menu_image` varchar(255) DEFAULT NULL,
  `setup_header_menu_name` varchar(255) NOT NULL,
  PRIMARY KEY (`setup_header_menu_id`),
  KEY `FK_setup_header_super_menu` (`status_id`),
  CONSTRAINT `FK_setup_header_super_menu` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.setup_menu_master
CREATE TABLE IF NOT EXISTS `setup_menu_master` (
  `setup_menu_master_id` int(1) NOT NULL,
  `setup_menu_name` varchar(100) NOT NULL,
  `setup_menu_link` text NOT NULL,
  `setup_menu_image` text NOT NULL,
  `setup_header_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  PRIMARY KEY (`setup_menu_master_id`),
  KEY `setup_menu_header_id` (`setup_header_id`),
  KEY `setup_menu_status_id` (`status_id`),
  CONSTRAINT `setup_menu_header_id` FOREIGN KEY (`setup_header_id`) REFERENCES `setup_header_menu` (`setup_header_menu_id`),
  CONSTRAINT `setup_menu_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.severity_master
CREATE TABLE IF NOT EXISTS `severity_master` (
  `severity_id` int(11) NOT NULL AUTO_INCREMENT,
  `severity_type` text NOT NULL,
  `hospital_id` int(8) NOT NULL,
  `user_id` int(8) NOT NULL,
  `status_id` int(8) NOT NULL,
  `is_editable_id` int(2) NOT NULL,
  PRIMARY KEY (`severity_id`),
  KEY `FK_severity_master_hospital_master` (`hospital_id`),
  KEY `FK_severity_master_login_master` (`user_id`),
  KEY `FK_severity_master_status_master` (`status_id`),
  KEY `FK_severity_master_is_editable_master` (`is_editable_id`),
  CONSTRAINT `FK_severity_master_hospital_master` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_severity_master_is_editable_master` FOREIGN KEY (`is_editable_id`) REFERENCES `is_editable_master` (`is_editable_id`),
  CONSTRAINT `FK_severity_master_login_master` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`),
  CONSTRAINT `FK_severity_master_status_master` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.shift_master
CREATE TABLE IF NOT EXISTS `shift_master` (
  `shift_master_id` int(8) NOT NULL,
  `shift_name` varchar(100) NOT NULL,
  `shift_start_time` varchar(10) NOT NULL,
  `shift_end_time` varchar(10) NOT NULL,
  `shift_late_arrival` int(8) NOT NULL,
  `shift_leave_early` int(8) NOT NULL,
  `hospital_id` int(8) NOT NULL,
  `user_id` int(8) NOT NULL,
  `status_id` int(8) NOT NULL,
  `last_updated` datetime NOT NULL,
  PRIMARY KEY (`shift_master_id`),
  KEY `shift_master_hospital_id` (`hospital_id`),
  KEY `shift_master_user_id` (`user_id`),
  KEY `shift_master_status_id` (`status_id`),
  CONSTRAINT `shift_master_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `shift_master_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `shift_master_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.smoking_master
CREATE TABLE IF NOT EXISTS `smoking_master` (
  `smoking_id` int(11) NOT NULL AUTO_INCREMENT,
  `smoking_type` text NOT NULL,
  `hospital_id` int(8) NOT NULL,
  `user_id` int(8) NOT NULL,
  `status_id` int(8) NOT NULL,
  `is_editable_id` int(2) NOT NULL,
  PRIMARY KEY (`smoking_id`),
  KEY `FK_smoking_master_hospital_master` (`hospital_id`),
  KEY `FK_smoking_master_login_master` (`user_id`),
  KEY `FK_smoking_master_status_master` (`status_id`),
  KEY `FK_smoking_master_is_editable_master` (`is_editable_id`),
  CONSTRAINT `FK_smoking_master_hospital_master` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_smoking_master_is_editable_master` FOREIGN KEY (`is_editable_id`) REFERENCES `is_editable_master` (`is_editable_id`),
  CONSTRAINT `FK_smoking_master_login_master` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`),
  CONSTRAINT `FK_smoking_master_status_master` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.state_master
CREATE TABLE IF NOT EXISTS `state_master` (
  `state_id` int(8) NOT NULL AUTO_INCREMENT,
  `state_name` varchar(200) NOT NULL DEFAULT '',
  `status_id` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`state_id`),
  KEY `FK_state_master_status_master` (`status_id`),
  CONSTRAINT `FK_state_master_status_master` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.status_master
CREATE TABLE IF NOT EXISTS `status_master` (
  `status_id` int(8) NOT NULL AUTO_INCREMENT,
  `status_desc` varchar(15) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT '',
  PRIMARY KEY (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.subscription_details
CREATE TABLE IF NOT EXISTS `subscription_details` (
  `subscription_id` int(5) NOT NULL AUTO_INCREMENT,
  `no_of_logins` int(5) NOT NULL,
  `from_subsdate` date NOT NULL,
  `to_subsdate` date NOT NULL,
  `hospital_id` int(5) NOT NULL,
  `user_id` int(5) NOT NULL,
  `status_id` int(5) NOT NULL,
  `last_updated` datetime NOT NULL,
  PRIMARY KEY (`subscription_id`),
  KEY `hospital_id` (`hospital_id`),
  KEY `subscription_details_ibfk_3` (`status_id`),
  KEY `subscription_details_ibfk_1` (`user_id`),
  CONSTRAINT `subscription_details_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`),
  CONSTRAINT `subscription_details_ibfk_2` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `subscription_details_ibfk_3` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.supplier_detailsmaster
CREATE TABLE IF NOT EXISTS `supplier_detailsmaster` (
  `supplier_id` int(10) NOT NULL,
  `supplier_name` varchar(50) DEFAULT NULL,
  `supplier_address` varchar(250) DEFAULT NULL,
  `supplier_mobileno` varchar(15) DEFAULT NULL,
  `V_emailId` varchar(25) DEFAULT NULL,
  `contact_person` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`supplier_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.symptoms_master
CREATE TABLE IF NOT EXISTS `symptoms_master` (
  `symptoms_id` int(11) NOT NULL AUTO_INCREMENT,
  `symptoms_desc` text NOT NULL,
  `hospital_id` int(8) NOT NULL,
  `user_id` int(8) NOT NULL,
  `status_id` int(8) NOT NULL,
  `is_editable_id` int(2) NOT NULL,
  PRIMARY KEY (`symptoms_id`),
  KEY `FK_compliant_master1_hospital_master` (`hospital_id`),
  KEY `FK_compliant_master1_login_master` (`user_id`),
  KEY `FK_compliant_master1_status_master` (`status_id`),
  KEY `FK_compliant_master1_is_editable_master` (`is_editable_id`),
  CONSTRAINT `symptoms_master_ibfk_1` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `symptoms_master_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`),
  CONSTRAINT `symptoms_master_ibfk_3` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `symptoms_master_ibfk_4` FOREIGN KEY (`is_editable_id`) REFERENCES `is_editable_master` (`is_editable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.temp_drug_master
CREATE TABLE IF NOT EXISTS `temp_drug_master` (
  `temp_drug_master_id` int(11) NOT NULL,
  `drug_master_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`temp_drug_master_id`),
  KEY `FK_ceu7tjfry4m3hkha2t0bd0fmk` (`drug_master_id`),
  KEY `FK_t1c5gpfawhpvnntsd112pmhbp` (`user_id`),
  CONSTRAINT `FK_ceu7tjfry4m3hkha2t0bd0fmk` FOREIGN KEY (`drug_master_id`) REFERENCES `drug_master` (`drug_master_id`),
  CONSTRAINT `FK_t1c5gpfawhpvnntsd112pmhbp` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.temp_item_master
CREATE TABLE IF NOT EXISTS `temp_item_master` (
  `temp_item_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(8) NOT NULL DEFAULT '0',
  `user_id` int(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`temp_item_id`),
  KEY `fk_temp_item_master_item_master1_idx` (`item_id`),
  KEY `fk_temp_item_master_login_master1_idx` (`user_id`),
  CONSTRAINT `fk_temp_item_master_item_master` FOREIGN KEY (`item_id`) REFERENCES `item_master` (`item_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_temp_item_master_login_master` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.test_combo_result_info
CREATE TABLE IF NOT EXISTS `test_combo_result_info` (
  `test_combo_result_info_id` int(11) NOT NULL AUTO_INCREMENT,
  `result` varchar(50) NOT NULL,
  `status_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `test_master_id` int(11) NOT NULL,
  `test_patients_details_id` int(11) NOT NULL,
  `test_profile_id` int(11) DEFAULT NULL,
  `test_type_option_master_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`test_combo_result_info_id`),
  KEY `FK_test_combo_result_info_status_id` (`status_id`),
  KEY `FK_test_combo_result_info_user_id` (`user_id`),
  KEY `FK_8ewkh9d8ye84o5mwrpc5rh6hr` (`test_master_id`),
  KEY `FK_4npm30rrll6a9jkvyoeo5ui9g` (`test_patients_details_id`),
  KEY `FK_15vev3oowpq0fjnqhb961vwmn` (`test_profile_id`),
  KEY `FK_bf50sp7o572jfeypyiwu9skso` (`test_type_option_master_id`),
  CONSTRAINT `FK_15vev3oowpq0fjnqhb961vwmn` FOREIGN KEY (`test_profile_id`) REFERENCES `test_master_main` (`test_master_id`),
  CONSTRAINT `FK_4npm30rrll6a9jkvyoeo5ui9g` FOREIGN KEY (`test_patients_details_id`) REFERENCES `test_patients_details` (`test_patients_details_id`),
  CONSTRAINT `FK_8ewkh9d8ye84o5mwrpc5rh6hr` FOREIGN KEY (`test_master_id`) REFERENCES `test_master_main` (`test_master_id`),
  CONSTRAINT `FK_bf50sp7o572jfeypyiwu9skso` FOREIGN KEY (`test_type_option_master_id`) REFERENCES `test_type_option_master` (`test_type_option_master`),
  CONSTRAINT `FK_test_combo_result_info_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_test_combo_result_info_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.test_final_result_details
CREATE TABLE IF NOT EXISTS `test_final_result_details` (
  `test_final_result_details_id` int(11) NOT NULL AUTO_INCREMENT,
  `test_master_id` int(11) NOT NULL,
  `test_profile_id` int(11) NOT NULL,
  `test_patients_details_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `last_updated` datetime NOT NULL,
  PRIMARY KEY (`test_final_result_details_id`),
  KEY `FK_test_final_result_details_test_master_id` (`test_master_id`),
  KEY `FK_test_final_result_details_test_profile_id` (`test_profile_id`),
  KEY `FK_test_final_result_details_test_patients_details_id` (`test_patients_details_id`),
  KEY `FK_test_final_result_details_status_id` (`status_id`),
  KEY `FK_test_final_result_details_user_id` (`user_id`),
  CONSTRAINT `FK_test_final_result_details_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_test_final_result_details_test_master_id` FOREIGN KEY (`test_master_id`) REFERENCES `test_master_main` (`test_master_id`),
  CONSTRAINT `FK_test_final_result_details_test_patients_details_id` FOREIGN KEY (`test_patients_details_id`) REFERENCES `test_patients_details` (`test_patients_details_id`),
  CONSTRAINT `FK_test_final_result_details_test_profile_id` FOREIGN KEY (`test_profile_id`) REFERENCES `test_master_main` (`test_master_id`),
  CONSTRAINT `FK_test_final_result_details_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.test_image_result_info
CREATE TABLE IF NOT EXISTS `test_image_result_info` (
  `test_image_result_info_id` int(11) NOT NULL AUTO_INCREMENT,
  `file_name` varchar(250) NOT NULL,
  `content_type` varchar(250) NOT NULL,
  `original_file_name` varchar(250) NOT NULL,
  `size` double NOT NULL,
  `result` varchar(250) NOT NULL,
  `status_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `last_updated` datetime NOT NULL,
  `test_master_id` int(11) NOT NULL,
  `test_patients_details_id` int(11) NOT NULL,
  `test_profile_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`test_image_result_info_id`),
  KEY `FK_test_image_result_info_status_id` (`status_id`),
  KEY `FK_test_image_result_info_user_id` (`user_id`),
  KEY `FK_3tsqtktf3q6g9xsqmbx4msjm9` (`test_master_id`),
  KEY `FK_jua98xrre3y48iyno9ohc8a84` (`test_patients_details_id`),
  KEY `FK_9uwtg4c44kojk4ojj7r7p7yc4` (`test_profile_id`),
  CONSTRAINT `FK_3tsqtktf3q6g9xsqmbx4msjm9` FOREIGN KEY (`test_master_id`) REFERENCES `test_master_main` (`test_master_id`),
  CONSTRAINT `FK_9uwtg4c44kojk4ojj7r7p7yc4` FOREIGN KEY (`test_profile_id`) REFERENCES `test_master_main` (`test_master_id`),
  CONSTRAINT `FK_jua98xrre3y48iyno9ohc8a84` FOREIGN KEY (`test_patients_details_id`) REFERENCES `test_patients_details` (`test_patients_details_id`),
  CONSTRAINT `FK_test_image_result_info_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_test_image_result_info_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.test_main_group
CREATE TABLE IF NOT EXISTS `test_main_group` (
  `test_group_id` int(11) NOT NULL AUTO_INCREMENT,
  `test_group_name` varchar(50) NOT NULL,
  `status_id` int(8) NOT NULL,
  `user_id` int(8) NOT NULL,
  `last_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `hospital_id` int(11) NOT NULL,
  PRIMARY KEY (`test_group_id`),
  KEY `FK_test_group_id_status_id` (`status_id`),
  KEY `FK_test_group_id_user_id` (`user_id`),
  KEY `FK_coerwogfafogvanxqfm8e092w` (`hospital_id`),
  CONSTRAINT `FK_test_group_id_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_test_group_id_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_test_group_id_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.test_master_main
CREATE TABLE IF NOT EXISTS `test_master_main` (
  `test_master_id` int(11) NOT NULL AUTO_INCREMENT,
  `test_name` varchar(50) NOT NULL,
  `test_code` varchar(50) NOT NULL,
  `test_description` varchar(250) DEFAULT NULL,
  `is_profile` char(2) NOT NULL,
  `test_group_id` int(11) DEFAULT NULL,
  `test_subgroup_id` int(11) DEFAULT NULL,
  `rate` double NOT NULL,
  `test_method_id` int(11) DEFAULT NULL,
  `sample_type_id` int(11) DEFAULT NULL,
  `units` varchar(50) DEFAULT NULL,
  `range_from` double DEFAULT NULL,
  `range_to` double DEFAULT NULL,
  `lower_bound` double DEFAULT NULL,
  `upper_bound` double DEFAULT NULL,
  `formula` varchar(50) DEFAULT NULL,
  `result_type_id` int(11) DEFAULT NULL,
  `interpretation_notes` varchar(500) DEFAULT NULL,
  `precaution_notes` varchar(500) DEFAULT NULL,
  `additional_naotes` varchar(500) DEFAULT NULL,
  `hospital_id` int(8) DEFAULT NULL,
  `status_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `last_updated` datetime NOT NULL,
  PRIMARY KEY (`test_master_id`),
  KEY `FK_test_master_test_group_id` (`test_group_id`),
  KEY `FK_test_master_test_subgroup_id` (`test_subgroup_id`),
  KEY `FK_test_master_sample_type` (`sample_type_id`),
  KEY `FK_test_master_result_type_id` (`result_type_id`),
  KEY `FK_test_master_status_id` (`status_id`),
  KEY `FK_test_master_test_method_id` (`test_method_id`),
  KEY `FK_test_master_user_id` (`user_id`),
  KEY `FK_test_master_hospital_id` (`hospital_id`),
  CONSTRAINT `FK_test_master_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_test_master_result_type_id` FOREIGN KEY (`result_type_id`) REFERENCES `test_result_type_setup` (`test_result_type_setup_id`),
  CONSTRAINT `FK_test_master_sample_type` FOREIGN KEY (`sample_type_id`) REFERENCES `test_sample_type_master` (`test_sample_type_master_id`),
  CONSTRAINT `FK_test_master_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_test_master_test_group_id` FOREIGN KEY (`test_group_id`) REFERENCES `test_main_group` (`test_group_id`),
  CONSTRAINT `FK_test_master_test_method_id` FOREIGN KEY (`test_method_id`) REFERENCES `test_method_master` (`test_method_master_id`),
  CONSTRAINT `FK_test_master_test_subgroup_id` FOREIGN KEY (`test_subgroup_id`) REFERENCES `test_subgroup_setup` (`test_subgroup_id`),
  CONSTRAINT `FK_test_master_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.test_method_master
CREATE TABLE IF NOT EXISTS `test_method_master` (
  `test_method_master_id` int(11) NOT NULL AUTO_INCREMENT,
  `test_method_name` varchar(50) NOT NULL,
  `status_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `last_updated` datetime NOT NULL,
  `hospital_id` int(8) NOT NULL,
  PRIMARY KEY (`test_method_master_id`),
  KEY `FK_test_method_master_status_id` (`status_id`),
  KEY `FK_test_method_master_user_id` (`user_id`),
  KEY `FK_test_method_master_hospital_id` (`hospital_id`),
  CONSTRAINT `FK_test_method_master_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_test_method_master_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_test_method_master_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.test_patients_details
CREATE TABLE IF NOT EXISTS `test_patients_details` (
  `test_patients_details_id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_type_id` int(11) NOT NULL,
  `test_patient_id` int(11) DEFAULT NULL,
  `date_and_time` datetime NOT NULL,
  `age` varchar(50) DEFAULT NULL,
  `referred_id` int(11) DEFAULT NULL,
  `rate` double NOT NULL,
  `referrer_name` varchar(50) DEFAULT NULL,
  `discount` double NOT NULL,
  `net_amount` double NOT NULL,
  `hospital_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `last_updated` datetime NOT NULL,
  `isIpdFinalBilling` int(11) DEFAULT NULL,
  `is_sampling` int(11) DEFAULT NULL,
  `sampling_address` varchar(255) DEFAULT NULL,
  `sampling_amount` double DEFAULT NULL,
  `sampling_collected_by` varchar(255) DEFAULT NULL,
  `sampling_date` date DEFAULT NULL,
  `test_patient_prefix_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`test_patients_details_id`),
  KEY `FK_test_patients_details_status_id` (`status_id`),
  KEY `FK_test_patients_details_user_id` (`user_id`),
  KEY `FK_test_patients_details_patient_type_id` (`patient_type_id`),
  KEY `FK_test_patients_details_reffered_id` (`referred_id`),
  KEY `FK_test_patients_details_hospital_id` (`hospital_id`),
  KEY `FK_6wovtfqp6ne6n9hy0gro3x2kd` (`test_patient_id`),
  KEY `FK_svkakrcdkdqiwdlo3j44542yx` (`referred_id`),
  CONSTRAINT `FK_svkakrcdkdqiwdlo3j44542yx` FOREIGN KEY (`referred_id`) REFERENCES `emp_info` (`emp_id`),
  CONSTRAINT `FK_test_patients_details_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_test_patients_details_patient_type_id` FOREIGN KEY (`patient_type_id`) REFERENCES `patient_type_master` (`patient_type_id`),
  CONSTRAINT `FK_test_patients_details_reffered_id` FOREIGN KEY (`referred_id`) REFERENCES `emp_office_info` (`emp_official_id`),
  CONSTRAINT `FK_test_patients_details_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_test_patients_details_test_patient_id` FOREIGN KEY (`test_patient_id`) REFERENCES `patient_personal_details` (`patient_id`),
  CONSTRAINT `FK_test_patients_details_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.test_patient_map
CREATE TABLE IF NOT EXISTS `test_patient_map` (
  `test_patient_map_id` int(11) NOT NULL AUTO_INCREMENT,
  `test_patients_details_id` int(11) NOT NULL,
  `test_master_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `last_updated` datetime NOT NULL,
  `isProfile` varchar(255) NOT NULL,
  PRIMARY KEY (`test_patient_map_id`),
  KEY `FK_test_patient_map_test_patients_details_id` (`test_patients_details_id`),
  KEY `FK_test_patient_map_test_master_id` (`test_master_id`),
  KEY `FK_test_patient_map_status_id` (`status_id`),
  KEY `FK_test_patient_map_user_id` (`user_id`),
  CONSTRAINT `FK_test_patient_map_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_test_patient_map_test_master_id` FOREIGN KEY (`test_master_id`) REFERENCES `test_master_main` (`test_master_id`),
  CONSTRAINT `FK_test_patient_map_test_patients_details_id` FOREIGN KEY (`test_patients_details_id`) REFERENCES `test_patients_details` (`test_patients_details_id`),
  CONSTRAINT `FK_test_patient_map_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.test_profile_map
CREATE TABLE IF NOT EXISTS `test_profile_map` (
  `test_profile_map_id` int(11) NOT NULL AUTO_INCREMENT,
  `test_profile_id` int(11) NOT NULL DEFAULT '0',
  `test_master_id` int(11) NOT NULL DEFAULT '0',
  `status_id` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `hospital_id` int(11) NOT NULL DEFAULT '0',
  `last_updated` datetime NOT NULL,
  PRIMARY KEY (`test_profile_map_id`),
  KEY `FK_test_profile_map_test_profile_id` (`test_profile_id`),
  KEY `FK_test_profile_map_test_master_id` (`test_master_id`),
  KEY `FK_test_profile_map_status_id` (`status_id`),
  KEY `FK_test_profile_map_user_id` (`user_id`),
  KEY `FK_test_profile_map_hospital_id` (`hospital_id`),
  CONSTRAINT `FK_test_profile_map_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_test_profile_map_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_test_profile_map_test_master_id` FOREIGN KEY (`test_master_id`) REFERENCES `test_master_main` (`test_master_id`),
  CONSTRAINT `FK_test_profile_map_test_profile_id` FOREIGN KEY (`test_profile_id`) REFERENCES `test_master_main` (`test_master_id`),
  CONSTRAINT `FK_test_profile_map_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.test_profile_name_info
CREATE TABLE IF NOT EXISTS `test_profile_name_info` (
  `test_profile_name_info_id` int(11) NOT NULL AUTO_INCREMENT,
  `test_profile_name` varchar(50) NOT NULL,
  `test_profile_amt` double NOT NULL,
  `test_profile_description` varchar(50) NOT NULL,
  `status_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `last_updated` datetime NOT NULL,
  PRIMARY KEY (`test_profile_name_info_id`),
  KEY `FK_test_profile_name_info_status_id` (`status_id`),
  KEY `FK_test_profile_name_info_user_id` (`user_id`),
  CONSTRAINT `FK_test_profile_name_info_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_test_profile_name_info_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.test_result_option_master
CREATE TABLE IF NOT EXISTS `test_result_option_master` (
  `test_result_option_master_id` int(11) NOT NULL AUTO_INCREMENT,
  `test_result_option_values` int(11) NOT NULL,
  `test_result_type_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `last_updated` datetime NOT NULL,
  PRIMARY KEY (`test_result_option_master_id`),
  KEY `FK_test_result_option_master_test_result_type_id` (`test_result_type_id`),
  KEY `FK_test_result_option_master_status_id` (`status_id`),
  KEY `FK_test_result_option_master_user_id` (`user_id`),
  CONSTRAINT `FK_test_result_option_master_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_test_result_option_master_test_result_type_id` FOREIGN KEY (`test_result_type_id`) REFERENCES `test_result_type_setup` (`test_result_type_setup_id`),
  CONSTRAINT `FK_test_result_option_master_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.test_result_type_setup
CREATE TABLE IF NOT EXISTS `test_result_type_setup` (
  `test_result_type_setup_id` int(11) NOT NULL AUTO_INCREMENT,
  `test_result_type_name` varchar(50) NOT NULL,
  `status_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `last_updated` datetime NOT NULL,
  `hospital_id` int(11) NOT NULL,
  PRIMARY KEY (`test_result_type_setup_id`),
  KEY `FK_test_result_type_setup_status_id` (`status_id`),
  KEY `FK_test_result_type_setup_user_id` (`user_id`),
  KEY `FK_9n9tcbwrle8rx19tstfgel14m` (`hospital_id`),
  CONSTRAINT `FK_test_result_type_setup_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_test_result_type_setup_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_test_result_type_setup_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.test_sample_type_master
CREATE TABLE IF NOT EXISTS `test_sample_type_master` (
  `test_sample_type_master_id` int(11) NOT NULL AUTO_INCREMENT,
  `test_sample_type_name` varchar(50) NOT NULL,
  `status_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `last_updated` datetime NOT NULL,
  `hospital_id` int(11) NOT NULL,
  PRIMARY KEY (`test_sample_type_master_id`),
  KEY `FK_test_sample_type_master_status_id` (`status_id`),
  KEY `FK_status_id_user_id` (`user_id`),
  KEY `FK_a72k1js24muy50i9gmk8w6bai` (`hospital_id`),
  CONSTRAINT `FK_test_sample_type_master_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_test_sample_type_master_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_test_sample_type_master_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.test_subgroup_setup
CREATE TABLE IF NOT EXISTS `test_subgroup_setup` (
  `test_subgroup_id` int(11) NOT NULL AUTO_INCREMENT,
  `test_subgroup_name` varchar(50) NOT NULL,
  `test_subgroup_code` varchar(50) NOT NULL,
  `test_group_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `last_updated` datetime NOT NULL,
  `hospital_id` int(11) NOT NULL,
  PRIMARY KEY (`test_subgroup_id`),
  KEY `FK_test_subgroup_setup_test_group_id` (`test_group_id`),
  KEY `FK_test_subgroup_setup_status_id` (`status_id`),
  KEY `FK_test_subgroup_setup_user_id` (`user_id`),
  KEY `FK_4q55f8qa8syjyclo4lqh8xhkp` (`hospital_id`),
  CONSTRAINT `FK_test_subgroup_setup_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_test_subgroup_setup_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_test_subgroup_setup_test_group_id` FOREIGN KEY (`test_group_id`) REFERENCES `test_main_group` (`test_group_id`),
  CONSTRAINT `FK_test_subgroup_setup_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.test_text_result_info
CREATE TABLE IF NOT EXISTS `test_text_result_info` (
  `test_text_result_info_id` int(11) NOT NULL AUTO_INCREMENT,
  `result` varchar(50) NOT NULL,
  `status_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `test_master_id` int(11) NOT NULL,
  `test_patients_details_id` int(11) NOT NULL,
  `test_profile_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`test_text_result_info_id`),
  KEY `FK_test_text_result_info_status_id` (`status_id`),
  KEY `FK_test_text_result_info_user_id` (`user_id`),
  KEY `FK_igivjebyun3a3bfwh4akcxgs4` (`test_master_id`),
  KEY `FK_mgptmk844k1x7fj42htfippp6` (`test_patients_details_id`),
  KEY `FK_qvty0m5m0bjxyv1c8vf7qukb8` (`test_profile_id`),
  CONSTRAINT `FK_igivjebyun3a3bfwh4akcxgs4` FOREIGN KEY (`test_master_id`) REFERENCES `test_master_main` (`test_master_id`),
  CONSTRAINT `FK_mgptmk844k1x7fj42htfippp6` FOREIGN KEY (`test_patients_details_id`) REFERENCES `test_patients_details` (`test_patients_details_id`),
  CONSTRAINT `FK_qvty0m5m0bjxyv1c8vf7qukb8` FOREIGN KEY (`test_profile_id`) REFERENCES `test_master_main` (`test_master_id`),
  CONSTRAINT `FK_test_text_result_info_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_test_text_result_info_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.test_type_option_master
CREATE TABLE IF NOT EXISTS `test_type_option_master` (
  `test_type_option_master` int(11) NOT NULL AUTO_INCREMENT,
  `test_option_value` varchar(50) NOT NULL,
  `test_master_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `last_updated` datetime NOT NULL,
  `hospital_id` int(11) NOT NULL,
  PRIMARY KEY (`test_type_option_master`),
  KEY `FK_test_type_option_master_status_id` (`status_id`),
  KEY `FK_test_type_option_master_user_id` (`user_id`),
  KEY `FK_test_type_option_master_test_master_id` (`test_master_id`),
  KEY `FK_bc52hvityu3q7l4mcj5f4p670` (`hospital_id`),
  CONSTRAINT `FK_bc52hvityu3q7l4mcj5f4p670` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_test_type_option_master_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_test_type_option_master_test_master_id` FOREIGN KEY (`test_master_id`) REFERENCES `test_master_main` (`test_master_id`),
  CONSTRAINT `FK_test_type_option_master_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.text_align_master
CREATE TABLE IF NOT EXISTS `text_align_master` (
  `text_align_master_id` int(11) NOT NULL AUTO_INCREMENT,
  `text_align_param` varchar(255) DEFAULT NULL,
  `status_id` int(11) NOT NULL,
  PRIMARY KEY (`text_align_master_id`),
  KEY `FK_fogvrj2n3ost41v8yl0oybav5` (`status_id`),
  CONSTRAINT `FK_fogvrj2n3ost41v8yl0oybav5` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.text_decoration_master
CREATE TABLE IF NOT EXISTS `text_decoration_master` (
  `text_decoration_master_id` int(11) NOT NULL AUTO_INCREMENT,
  `text_decoration_params` varchar(255) NOT NULL,
  `status_id` int(11) NOT NULL,
  PRIMARY KEY (`text_decoration_master_id`),
  KEY `FK_6q9761jp5ux0vq740vq2rxcy6` (`status_id`),
  CONSTRAINT `FK_6q9761jp5ux0vq740vq2rxcy6` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.text_float_master
CREATE TABLE IF NOT EXISTS `text_float_master` (
  `text_float_master_id` int(11) NOT NULL AUTO_INCREMENT,
  `float_name` varchar(255) DEFAULT NULL,
  `status_id` int(11) NOT NULL,
  PRIMARY KEY (`text_float_master_id`),
  KEY `FK_4xic2sxaygwwevmig5ucg3g7f` (`status_id`),
  CONSTRAINT `FK_4xic2sxaygwwevmig5ucg3g7f` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.text_font_style_master
CREATE TABLE IF NOT EXISTS `text_font_style_master` (
  `text_font_style_id` int(11) NOT NULL AUTO_INCREMENT,
  `font_style` varchar(255) DEFAULT NULL,
  `status_id` int(11) NOT NULL,
  PRIMARY KEY (`text_font_style_id`),
  KEY `FK_iajkd9kxtle4okvm9s7vejg0w` (`status_id`),
  CONSTRAINT `FK_iajkd9kxtle4okvm9s7vejg0w` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.text_length_master
CREATE TABLE IF NOT EXISTS `text_length_master` (
  `table_length_master_id` int(11) NOT NULL AUTO_INCREMENT,
  `length_params` varchar(255) NOT NULL,
  `status_id` int(11) NOT NULL,
  PRIMARY KEY (`table_length_master_id`),
  KEY `FK_3y7b0yj71jlmpnvxwf3uu82k0` (`status_id`),
  CONSTRAINT `FK_3y7b0yj71jlmpnvxwf3uu82k0` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.text_transform_master
CREATE TABLE IF NOT EXISTS `text_transform_master` (
  `text_transform_master_id` int(11) NOT NULL AUTO_INCREMENT,
  `transform_params` varchar(255) NOT NULL,
  `status_id` int(11) NOT NULL,
  PRIMARY KEY (`text_transform_master_id`),
  KEY `FK_gb87e4xtqmknyn8213mwdmwr9` (`status_id`),
  CONSTRAINT `FK_gb87e4xtqmknyn8213mwdmwr9` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.time_master_details
CREATE TABLE IF NOT EXISTS `time_master_details` (
  `time_master_Id` int(11) NOT NULL AUTO_INCREMENT,
  `time_value` varchar(255) DEFAULT NULL,
  `status_id` int(11) NOT NULL,
  PRIMARY KEY (`time_master_Id`),
  KEY `FK_emwmin43lwdctc2oojou8swv7` (`status_id`),
  CONSTRAINT `FK_emwmin43lwdctc2oojou8swv7` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.timing_duration_master
CREATE TABLE IF NOT EXISTS `timing_duration_master` (
  `timing_master_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(50) NOT NULL,
  `status_id` int(11) NOT NULL,
  PRIMARY KEY (`timing_master_id`),
  KEY `FK_timing_duration_master_status_id` (`status_id`),
  CONSTRAINT `FK_timing_duration_master_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.timing_master
CREATE TABLE IF NOT EXISTS `timing_master` (
  `timing_id` int(11) NOT NULL AUTO_INCREMENT,
  `timing_desc` text NOT NULL,
  `hospital_id` int(8) NOT NULL,
  `user_id` int(8) NOT NULL,
  `status_id` int(8) NOT NULL,
  `is_editable_id` int(2) NOT NULL,
  PRIMARY KEY (`timing_id`),
  KEY `FK_timing_master_hospital_master` (`hospital_id`),
  KEY `FK_timing_master_login_master` (`user_id`),
  KEY `FK_timing_master_status_master` (`status_id`),
  KEY `FK_timing_master_is_editable_master` (`is_editable_id`),
  CONSTRAINT `FK_timing_master_hospital_master` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_timing_master_is_editable_master` FOREIGN KEY (`is_editable_id`) REFERENCES `is_editable_master` (`is_editable_id`),
  CONSTRAINT `FK_timing_master_login_master` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`),
  CONSTRAINT `FK_timing_master_status_master` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.url_navigation_master
CREATE TABLE IF NOT EXISTS `url_navigation_master` (
  `url_id` int(11) NOT NULL AUTO_INCREMENT,
  `navigation` longtext,
  `url` longtext,
  `menu` longtext,
  `status_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`url_id`),
  KEY `FK_s8j05jnm9wa65m1kw08uijdnp` (`status_id`),
  CONSTRAINT `FK_s8j05jnm9wa65m1kw08uijdnp` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.user_rights
CREATE TABLE IF NOT EXISTS `user_rights` (
  `user_rights_id` int(8) NOT NULL AUTO_INCREMENT,
  `menu_id` int(3) NOT NULL DEFAULT '0',
  `rights_id` int(1) NOT NULL DEFAULT '0',
  `status_id` int(1) NOT NULL DEFAULT '1',
  `user_id` int(8) NOT NULL,
  PRIMARY KEY (`user_rights_id`),
  KEY `FK_user_rights_user_id` (`user_id`),
  KEY `FK_user_rights_status_id` (`status_id`),
  KEY `FK_user_rights_rights_id` (`rights_id`),
  KEY `FK_5lf00jvu1c53tfdsoxk9iy4e1` (`menu_id`),
  CONSTRAINT `FK_5lf00jvu1c53tfdsoxk9iy4e1` FOREIGN KEY (`menu_id`) REFERENCES `menu_master` (`menu_id`),
  CONSTRAINT `FK_user_rights_rights_id` FOREIGN KEY (`rights_id`) REFERENCES `rights_master` (`rights_id`),
  CONSTRAINT `FK_user_rights_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_user_rights_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='User''s Menu i.e. user rights to view a menu';

-- Data exporting was unselected.


-- Dumping structure for table testingteam.user_type_master
CREATE TABLE IF NOT EXISTS `user_type_master` (
  `user_type_id` int(8) NOT NULL,
  `user_type_name` varchar(100) NOT NULL,
  `status_id` int(8) NOT NULL,
  PRIMARY KEY (`user_type_id`),
  KEY `FK_user_type_master_status_id` (`status_id`),
  CONSTRAINT `FK_user_type_master_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.vocher_bank_mster
CREATE TABLE IF NOT EXISTS `vocher_bank_mster` (
  `vocher_bank_id` int(11) NOT NULL AUTO_INCREMENT,
  `Vocher_bank_info` varchar(50) DEFAULT NULL,
  `hospital_id` int(8) NOT NULL,
  `status_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`vocher_bank_id`),
  KEY `FK_vocher_bank_status_id` (`status_id`),
  KEY `FK_vocher_bank_hospital_id` (`hospital_id`),
  KEY `FK_vocher_bank_user_id` (`user_id`),
  CONSTRAINT `FK_vocher_bank_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_vocher_bank_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_vocher_bank_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.voucher_payment_details
CREATE TABLE IF NOT EXISTS `voucher_payment_details` (
  `vocher_details_id` int(8) NOT NULL,
  `voucher_receipt_no` varchar(25) DEFAULT NULL,
  `payment_date` date NOT NULL,
  `vocher_bank_id` int(8) NOT NULL,
  `payment_ref_no` varchar(20) DEFAULT NULL,
  `payment_remarks` varchar(250) DEFAULT NULL,
  `payment_amount` double(20,2) DEFAULT NULL,
  `hospital_id` int(8) NOT NULL,
  `user_id` int(8) NOT NULL,
  `advance_type` varchar(3) DEFAULT NULL,
  `status_id` int(8) NOT NULL,
  `last_updated` datetime NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `reason` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`vocher_details_id`),
  KEY `FK_vocher_hospital_id` (`hospital_id`),
  KEY `FK_vocher_user_id` (`user_id`),
  KEY `FK_vocher_satus_id` (`status_id`),
  KEY `FK_vocher_bank_id` (`vocher_bank_id`),
  CONSTRAINT `FK_vocher_bank_id` FOREIGN KEY (`vocher_bank_id`) REFERENCES `vocher_bank_mster` (`vocher_bank_id`),
  CONSTRAINT `FK_vocher_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_vocher_satus_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_vocher_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.ward_master
CREATE TABLE IF NOT EXISTS `ward_master` (
  `ward_id` int(8) NOT NULL,
  `hospital_id` int(8) NOT NULL,
  `ward_short_desc` varchar(200) DEFAULT NULL,
  `ward_desc` varchar(200) NOT NULL,
  `user_id` int(8) NOT NULL,
  `status_id` int(1) NOT NULL,
  `last_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`ward_id`),
  KEY `FK_ward_master_hospital_id` (`hospital_id`),
  KEY `FK_ward_master_user_id` (`user_id`),
  KEY `FK_ward_master_status_id` (`status_id`),
  CONSTRAINT `FK_ward_master_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital_master` (`hospital_id`),
  CONSTRAINT `FK_ward_master_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`),
  CONSTRAINT `FK_ward_master_user_id` FOREIGN KEY (`user_id`) REFERENCES `login_master` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.week_master
CREATE TABLE IF NOT EXISTS `week_master` (
  `week_id` int(8) NOT NULL,
  `week_day_name` varchar(3) NOT NULL,
  `week_day_fullName` varchar(20) DEFAULT NULL,
  `status_id` int(8) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`week_id`),
  KEY `week_master_status_id` (`status_id`),
  CONSTRAINT `week_master_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.working_hour_master
CREATE TABLE IF NOT EXISTS `working_hour_master` (
  `working_hour_id` int(11) NOT NULL,
  `working_hour_name` varchar(10) NOT NULL,
  `status_id` int(1) NOT NULL,
  PRIMARY KEY (`working_hour_id`),
  KEY `work_hour_status_id` (`status_id`),
  CONSTRAINT `work_hour_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.work_session_master
CREATE TABLE IF NOT EXISTS `work_session_master` (
  `work_session_master_id` int(8) NOT NULL,
  `work_session_name` varchar(20) NOT NULL,
  `status_id` int(8) NOT NULL,
  PRIMARY KEY (`work_session_master_id`),
  KEY `work_session_status_id` (`status_id`),
  CONSTRAINT `work_session_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table testingteam.yes_no_master
CREATE TABLE IF NOT EXISTS `yes_no_master` (
  `yes_no_master_id` int(8) NOT NULL,
  `yes_no_desc` varchar(10) NOT NULL,
  `status_id` int(1) NOT NULL,
  PRIMARY KEY (`yes_no_master_id`),
  KEY `yes_no_master_status_id` (`status_id`),
  CONSTRAINT `yes_no_master_status_id` FOREIGN KEY (`status_id`) REFERENCES `status_master` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
