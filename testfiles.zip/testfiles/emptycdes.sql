-- --------------------------------------------------------
-- Host:                         192.168.0.26
-- Server version:               10.1.17-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping structure for table cdesolution.acknowledgement_details_history
CREATE TABLE IF NOT EXISTS `acknowledgement_details_history` (
  `acknowledge_id` int(5) NOT NULL AUTO_INCREMENT,
  `triggered_reply_details_id` int(5) NOT NULL,
  `response_email_id` varchar(200) NOT NULL,
  `subject` text,
  `content` text,
  `status` varchar(2) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`acknowledge_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.acquisition_financing_rehabilitation_master
CREATE TABLE IF NOT EXISTS `acquisition_financing_rehabilitation_master` (
  `acq_finance_rehab_id` int(8) NOT NULL DEFAULT '0',
  `acq_finance_rehab_desc` varchar(60) NOT NULL DEFAULT '',
  `cdfi_code` varchar(20) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`acq_finance_rehab_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.address_info
CREATE TABLE IF NOT EXISTS `address_info` (
  `address_id` int(10) NOT NULL DEFAULT '0',
  `cde_id` int(10) NOT NULL DEFAULT '0',
  `sub_cde_id` int(10) NOT NULL DEFAULT '0',
  `group_id` int(10) NOT NULL DEFAULT '0',
  `qalicb_id` int(10) NOT NULL DEFAULT '0',
  `project_id` int(10) NOT NULL DEFAULT '0',
  `investee_id` int(10) NOT NULL DEFAULT '0',
  `personal_id` int(10) NOT NULL DEFAULT '0',
  `investor_id` int(10) NOT NULL DEFAULT '0',
  `type` varchar(10) NOT NULL DEFAULT '',
  `status` varchar(3) NOT NULL DEFAULT 'Y',
  `modified_date` varchar(12) NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`address_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.address_type_master
CREATE TABLE IF NOT EXISTS `address_type_master` (
  `address_type_id` int(3) NOT NULL DEFAULT '0',
  `address_type_desc` varchar(15) NOT NULL DEFAULT '',
  `cdfi_code` varchar(10) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`address_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='INVESTEE / PROJECT';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.admin_master
CREATE TABLE IF NOT EXISTS `admin_master` (
  `admin_master_id` int(3) NOT NULL DEFAULT '0',
  `table_name` varchar(100) NOT NULL DEFAULT '0',
  `primary_key` varchar(100) NOT NULL DEFAULT '0',
  `description` varchar(100) NOT NULL DEFAULT '0',
  `table_desc` varchar(200) NOT NULL DEFAULT '0',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`admin_master_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='This is the master table administration section.';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.allocatee_cde
CREATE TABLE IF NOT EXISTS `allocatee_cde` (
  `alloc_cde_id` int(8) NOT NULL DEFAULT '0',
  `investor_master_id` int(8) NOT NULL DEFAULT '0',
  `cde_id` int(8) NOT NULL DEFAULT '0',
  `status` char(2) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`alloc_cde_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.alloc_agreement
CREATE TABLE IF NOT EXISTS `alloc_agreement` (
  `agreement_id` int(8) NOT NULL DEFAULT '0',
  `cde_id` int(8) NOT NULL DEFAULT '0',
  `alloc_year` int(8) NOT NULL DEFAULT '0',
  `amend_id` int(8) NOT NULL DEFAULT '0',
  `related_party` char(1) NOT NULL DEFAULT 'Y',
  `higher_distress` double(6,3) DEFAULT '-1.000',
  `rates_terms` double(6,3) DEFAULT '-1.000',
  `other_distress` varchar(50) DEFAULT NULL,
  `type_qlici` varchar(30) DEFAULT NULL,
  `type_flexible_product` varchar(30) DEFAULT NULL,
  `system_date` date DEFAULT NULL,
  `effective_date` date DEFAULT NULL,
  `alloc_cdfi` double(6,3) DEFAULT '-1.000',
  `alloc_cdfi_date` varchar(20) DEFAULT NULL,
  `dep_qei_60` varchar(20) DEFAULT NULL,
  `dep_qei_100` varchar(20) DEFAULT NULL,
  `status` char(1) DEFAULT 'Y',
  `nonmetropolitan` double(6,3) DEFAULT '-1.000',
  `targeteddistress` varchar(2) DEFAULT '',
  `unrelated_entities` varchar(2) DEFAULT '',
  `affordable_housing` varchar(2) DEFAULT '',
  `innovative_investment` varchar(2) DEFAULT '',
  `unrelated_cdes` double(6,3) DEFAULT '-1.000',
  `identified_states` double(6,3) DEFAULT '-1.000',
  `innovative_small_qlicis` double(6,3) DEFAULT '-1.000',
  `innovative_short_qlicis` double(6,3) DEFAULT '-1.000',
  `innovative_nonreal_qlicis` double(6,3) DEFAULT '-1.000',
  `restrictions` varchar(2) DEFAULT '',
  `loan_purchase_reinvest` double(6,3) DEFAULT '-1.000',
  `qualified_equity_investment` double(6,3) DEFAULT '-1.000',
  PRIMARY KEY (`agreement_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Allocation Agreement';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.amazon_credential_info
CREATE TABLE IF NOT EXISTS `amazon_credential_info` (
  `amazon_credential_info_id` int(11) NOT NULL,
  `access_key` varchar(50) DEFAULT NULL,
  `secret_key` varchar(50) DEFAULT NULL,
  `bucket_name` varchar(50) DEFAULT NULL,
  `status` char(50) DEFAULT NULL,
  PRIMARY KEY (`amazon_credential_info_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.amortization_type_master
CREATE TABLE IF NOT EXISTS `amortization_type_master` (
  `amortization_type_id` int(8) NOT NULL DEFAULT '0',
  `amortization_type_desc` varchar(60) NOT NULL DEFAULT '',
  `cdfi_code` varchar(20) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`amortization_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Amortization Type Master';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.amort_schedule
CREATE TABLE IF NOT EXISTS `amort_schedule` (
  `seq_id` int(8) NOT NULL AUTO_INCREMENT,
  `trans_type` varchar(15) NOT NULL DEFAULT '',
  `amort_id` int(8) NOT NULL DEFAULT '0',
  `cde_id` int(8) NOT NULL DEFAULT '0',
  `project_id` int(8) NOT NULL DEFAULT '0',
  `cash_details_id` int(8) NOT NULL DEFAULT '0',
  `due_date` date NOT NULL DEFAULT '0000-00-00',
  `bill_date` date NOT NULL DEFAULT '0000-00-00',
  `no_of_days` int(8) NOT NULL DEFAULT '0',
  `total_amount` double(20,2) NOT NULL DEFAULT '0.00',
  `principal_amount` double(20,2) NOT NULL DEFAULT '0.00',
  `interest_amount` double(20,2) NOT NULL DEFAULT '0.00',
  `balance_amount` double(20,2) NOT NULL DEFAULT '0.00',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`seq_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.annual_template
CREATE TABLE IF NOT EXISTS `annual_template` (
  `template_id` int(8) NOT NULL DEFAULT '0',
  `trans_id` varchar(15) NOT NULL DEFAULT '',
  `annual_year` int(4) NOT NULL DEFAULT '0',
  `project_id` int(8) NOT NULL DEFAULT '0',
  `qalicb_id` int(8) NOT NULL DEFAULT '0',
  `cde_id` int(8) NOT NULL DEFAULT '0',
  `ammend_id` int(3) NOT NULL DEFAULT '0',
  `balance_outstanding` double(20,2) DEFAULT '0.00',
  `loan_status` int(3) DEFAULT '0',
  `days_delinquent` int(4) DEFAULT '-1',
  `more_delinquent` int(4) DEFAULT '-1',
  `loan_restructured` int(4) DEFAULT '-1',
  `time_refinanced` int(4) DEFAULT '0',
  `charged_amount` double(20,2) DEFAULT '-1.00',
  `recovered_amount` double(20,2) DEFAULT '-1.00',
  `fair_value` double(20,2) DEFAULT '-1.00',
  `gross_revenue` double(20,2) DEFAULT '0.00',
  `jobs_at_reporting` double(9,2) DEFAULT '0.00',
  `dsfcos_reporting` double(9,2) DEFAULT '0.00',
  `dsfcos_post_investment` double(8,2) DEFAULT '0.00',
  `other_impact1_desc` varchar(150) DEFAULT NULL,
  `other_impact1_num` double(9,2) DEFAULT '0.00',
  `other_impact2_desc` varchar(150) DEFAULT NULL,
  `other_impact2_num` double(9,2) DEFAULT '0.00',
  `effective_date` varchar(10) DEFAULT NULL,
  `prepared_user` varchar(50) DEFAULT NULL,
  `status` char(1) DEFAULT 'Y',
  `int_rate` double(6,3) DEFAULT '-1.000',
  `proj_rate_return` double(20,3) DEFAULT NULL,
  `non_real_amt` double(20,2) DEFAULT '-1.00',
  PRIMARY KEY (`template_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Annual Template';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.annual_year_master
CREATE TABLE IF NOT EXISTS `annual_year_master` (
  `annual_year_master_id` int(11) NOT NULL,
  `annual_year` int(11) DEFAULT NULL,
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`annual_year_master_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.ats_trigger_mail
CREATE TABLE IF NOT EXISTS `ats_trigger_mail` (
  `ats_mail_id` int(10) NOT NULL DEFAULT '0',
  `mail_setup_id` int(10) NOT NULL DEFAULT '0',
  `alert_type_id` int(10) NOT NULL DEFAULT '0',
  `cash_details_id` int(10) NOT NULL DEFAULT '0',
  `due_date` date NOT NULL DEFAULT '0000-00-00',
  `alert_days` int(5) NOT NULL DEFAULT '0',
  `alert_status` char(1) NOT NULL DEFAULT 'N',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`ats_mail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.boardmember_test
CREATE TABLE IF NOT EXISTS `boardmember_test` (
  `test_id` int(8) NOT NULL DEFAULT '0',
  `cde_id` int(3) NOT NULL DEFAULT '0',
  `date_of_test` datetime DEFAULT NULL,
  `total_members` int(3) DEFAULT NULL,
  `qualified_members` int(3) DEFAULT NULL,
  `non_qualified_members` int(3) DEFAULT NULL,
  `result` varchar(6) DEFAULT NULL,
  PRIMARY KEY (`test_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Testing LIC boardmember strength with total board members.';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.boardmember_test_mail
CREATE TABLE IF NOT EXISTS `boardmember_test_mail` (
  `board_test_mail_id` int(10) NOT NULL DEFAULT '0',
  `mail_setup_id` int(10) NOT NULL DEFAULT '0',
  `boardmember_id` int(10) NOT NULL DEFAULT '0',
  `start_date` date NOT NULL DEFAULT '0000-00-00',
  `due_date` date NOT NULL DEFAULT '0000-00-00',
  `next_test_date` date NOT NULL DEFAULT '0000-00-00',
  `alert_days` int(10) NOT NULL DEFAULT '0',
  `alert_status` char(1) NOT NULL DEFAULT 'N',
  `status` char(1) NOT NULL DEFAULT 'N',
  PRIMARY KEY (`board_test_mail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.board_member
CREATE TABLE IF NOT EXISTS `board_member` (
  `member_id` int(5) NOT NULL DEFAULT '0',
  `login_name` varchar(30) DEFAULT '',
  `cde_id` int(8) NOT NULL DEFAULT '0',
  `personal_id` int(8) NOT NULL DEFAULT '0',
  `join_date` date NOT NULL DEFAULT '0000-00-00',
  `ssn` varchar(11) NOT NULL DEFAULT '',
  `member_type` int(3) NOT NULL DEFAULT '0',
  `owner_id` int(3) NOT NULL DEFAULT '0',
  `manpower_id` int(3) NOT NULL DEFAULT '0',
  `type_personal_id` int(8) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `gov_dept` varchar(100) DEFAULT NULL,
  `com_area_served` text,
  `mission` text,
  `status` char(1) DEFAULT 'Y',
  `last_updation_date` datetime DEFAULT NULL,
  `family` char(1) DEFAULT NULL,
  `sent_member_type` int(3) NOT NULL,
  `investor_master_id` int(8) DEFAULT '0',
  PRIMARY KEY (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Board Member Informations';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.board_member_fmail
CREATE TABLE IF NOT EXISTS `board_member_fmail` (
  `member_id` int(5) NOT NULL DEFAULT '0',
  `login_name` varchar(30) DEFAULT '',
  `cde_id` int(8) NOT NULL DEFAULT '0',
  `personal_id` int(8) NOT NULL DEFAULT '0',
  `join_date` date NOT NULL DEFAULT '0000-00-00',
  `ssn` varchar(11) NOT NULL DEFAULT '',
  `member_type` int(3) NOT NULL DEFAULT '0',
  `owner_id` int(3) NOT NULL DEFAULT '0',
  `manpower_id` int(3) NOT NULL DEFAULT '0',
  `type_personal_id` int(8) DEFAULT NULL,
  `title` varchar(200) DEFAULT NULL,
  `gov_dept` varchar(200) DEFAULT NULL,
  `com_area_served` varchar(200) DEFAULT NULL,
  `mission` text,
  `status` char(1) DEFAULT 'Y',
  `last_updation_date` datetime DEFAULT NULL,
  `family` char(1) DEFAULT NULL,
  `exmember_id` int(5) NOT NULL DEFAULT '0',
  `fmail_id` int(8) NOT NULL DEFAULT '0',
  `app_status` char(1) DEFAULT 'Y',
  `app_mem_id` int(5) NOT NULL DEFAULT '0',
  `sent_member_type` int(3) NOT NULL DEFAULT '0',
  `investor_master_id` int(8) DEFAULT '0',
  PRIMARY KEY (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.business_desc_master
CREATE TABLE IF NOT EXISTS `business_desc_master` (
  `business_desc_id` int(11) DEFAULT NULL,
  `business_desc` text,
  `cdfi_code` text,
  `status` varchar(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.business_entity_master
CREATE TABLE IF NOT EXISTS `business_entity_master` (
  `entity_id` int(3) NOT NULL DEFAULT '0',
  `entity_desc` varchar(30) DEFAULT '',
  `cdfi_code` varchar(20) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  `type` varchar(10) DEFAULT '',
  PRIMARY KEY (`entity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Business Entity Master';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.business_type_master
CREATE TABLE IF NOT EXISTS `business_type_master` (
  `btype_id` int(3) NOT NULL DEFAULT '0',
  `btype_desc` text NOT NULL,
  `legal` char(1) DEFAULT 'Y',
  `display_order` int(3) NOT NULL DEFAULT '0',
  `status` char(1) DEFAULT 'Y',
  `investee_option` int(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`btype_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Business Type Master';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.cash_details
CREATE TABLE IF NOT EXISTS `cash_details` (
  `cash_details_id` int(8) NOT NULL DEFAULT '0',
  `investor_id` int(8) NOT NULL DEFAULT '0',
  `cde_id` int(8) NOT NULL DEFAULT '0',
  `received_date` varchar(50) NOT NULL DEFAULT '0000-00-00',
  `amount_received` double(20,2) NOT NULL DEFAULT '0.00',
  `cheque_number` varchar(20) NOT NULL DEFAULT '',
  `bank_drawn` varchar(50) NOT NULL DEFAULT '',
  `cheque_date` varchar(50) NOT NULL DEFAULT '0000-00-00',
  `system_date` varchar(50) NOT NULL DEFAULT '0000-00-00',
  `type` varchar(5) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `other_sources_id` int(3) NOT NULL DEFAULT '0',
  `status` char(1) NOT NULL DEFAULT 'Y',
  `cdfi_id` varchar(20) NOT NULL DEFAULT '',
  `alloc_year` varchar(4) NOT NULL DEFAULT '0',
  `qalicb_id` int(8) NOT NULL DEFAULT '0',
  `mode` int(4) NOT NULL DEFAULT '0',
  `non_qei_id` int(8) NOT NULL DEFAULT '0',
  `qeiid_from_ats` varchar(100) NOT NULL DEFAULT '',
  `investee_id` int(11) NOT NULL DEFAULT '0',
  `project_id` int(8) DEFAULT '0',
  `address1` varchar(100) NOT NULL,
  `address2` varchar(100) NOT NULL,
  `city` varchar(50) NOT NULL,
  `stateId` varchar(2) NOT NULL,
  `zip4` varchar(10) NOT NULL,
  `zip` varchar(10) NOT NULL,
  `nonqei_convert_type` char(2) NOT NULL DEFAULT 'N',
  `cdfi_disburse_id` int(8) DEFAULT '0',
  PRIMARY KEY (`cash_details_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Cash Received Details';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.cash_disbursed
CREATE TABLE IF NOT EXISTS `cash_disbursed` (
  `cash_disbursed_id` int(8) NOT NULL DEFAULT '0',
  `cash_details_id` int(8) NOT NULL DEFAULT '0',
  `project_fund_req_id` int(8) NOT NULL DEFAULT '0',
  `cde_id` int(8) NOT NULL DEFAULT '0',
  `alloc_year` varchar(4) NOT NULL DEFAULT '',
  `project_id` int(8) NOT NULL DEFAULT '0',
  `amount` double(20,2) NOT NULL DEFAULT '0.00',
  `pf_id` int(8) NOT NULL DEFAULT '0',
  `system_date` date NOT NULL DEFAULT '0000-00-00',
  `cash_received_date` date NOT NULL DEFAULT '0000-00-00',
  `trans_type` varchar(15) NOT NULL DEFAULT '',
  `investee_id` int(8) DEFAULT '0',
  `transfer_id` int(8) DEFAULT '0',
  `status` char(2) NOT NULL DEFAULT '',
  `inv_pf_id` int(8) DEFAULT '0',
  `qei_id` varchar(20) NOT NULL DEFAULT '',
  `rqi_id` int(8) DEFAULT '0',
  `fund_type` varchar(10) DEFAULT 'P',
  PRIMARY KEY (`cash_disbursed_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.cash_mode_master
CREATE TABLE IF NOT EXISTS `cash_mode_master` (
  `cash_mode_id` int(4) NOT NULL DEFAULT '0',
  `cash_mode_desc` varchar(30) NOT NULL DEFAULT '',
  `cdfi_code` varchar(20) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`cash_mode_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Cash Mode Master';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.cde_amt_allocation
CREATE TABLE IF NOT EXISTS `cde_amt_allocation` (
  `alloc_id` int(5) NOT NULL DEFAULT '0',
  `cde_id` int(5) NOT NULL DEFAULT '0',
  `alloc_year` int(4) NOT NULL DEFAULT '0',
  `alloc_date` date DEFAULT NULL,
  `valid_from` date NOT NULL DEFAULT '0000-00-00',
  `valid_to` date NOT NULL DEFAULT '0000-00-00',
  `alloc_amount` double(20,2) NOT NULL DEFAULT '0.00',
  `balance_amount` double(20,2) NOT NULL DEFAULT '0.00',
  `allocating_cde` int(5) NOT NULL DEFAULT '0',
  `status` char(1) NOT NULL DEFAULT '',
  `reinvestment_amount` double(20,2) NOT NULL DEFAULT '0.00',
  `reinvestment_balance` double(20,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`alloc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Amount allocated to CDE for a particular year';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.cde_amt_allocation_old
CREATE TABLE IF NOT EXISTS `cde_amt_allocation_old` (
  `alloc_id` int(5) NOT NULL DEFAULT '0',
  `cde_id` int(5) NOT NULL DEFAULT '0',
  `alloc_year` int(4) NOT NULL DEFAULT '0',
  `alloc_date` date DEFAULT NULL,
  `valid_from` date NOT NULL DEFAULT '0000-00-00',
  `valid_to` date NOT NULL DEFAULT '0000-00-00',
  `alloc_amount` double(20,2) NOT NULL DEFAULT '0.00',
  `balance_amount` double(20,2) NOT NULL DEFAULT '0.00',
  `allocating_cde` int(5) NOT NULL DEFAULT '0',
  `status` char(1) NOT NULL DEFAULT '',
  `reinvestment_amount` double(20,2) NOT NULL DEFAULT '0.00',
  `reinvestment_balance` double(20,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`alloc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Amount allocated to CDE for a particular year';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.cde_character
CREATE TABLE IF NOT EXISTS `cde_character` (
  `cde_id` int(5) NOT NULL DEFAULT '0',
  `char_id` int(3) NOT NULL DEFAULT '0',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`cde_id`,`char_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Characteristics that apply to CDE';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.cde_info
CREATE TABLE IF NOT EXISTS `cde_info` (
  `session_id` varchar(40) NOT NULL DEFAULT '',
  `cde_id` int(5) NOT NULL DEFAULT '0',
  `login_name` varchar(30) DEFAULT '',
  `personal_id` int(8) NOT NULL DEFAULT '0',
  `reg_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `cde_type` varchar(15) NOT NULL DEFAULT '',
  `leave_date` varchar(10) NOT NULL DEFAULT '0000-00-00',
  `sei_no` varchar(25) DEFAULT NULL,
  `cdfi_no` varchar(25) DEFAULT NULL,
  `board_type` char(1) NOT NULL DEFAULT '',
  `leaverage_structure` char(1) NOT NULL DEFAULT 'Y',
  `fiscal_date` varchar(10) DEFAULT '0000-00-00',
  `incorp_date` date DEFAULT NULL,
  `fin_begin_year` int(4) DEFAULT NULL,
  `first_name` varchar(100) NOT NULL DEFAULT '',
  `middle_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) NOT NULL DEFAULT '',
  `phone` varchar(20) NOT NULL DEFAULT '',
  `mobile` varchar(20) NOT NULL DEFAULT '',
  `fax` varchar(15) NOT NULL DEFAULT '',
  `email` varchar(100) DEFAULT NULL,
  `minority_cde` char(1) NOT NULL DEFAULT '',
  `women_cde` char(1) NOT NULL DEFAULT '',
  `org_id` int(3) NOT NULL DEFAULT '0',
  `faith_based` char(1) NOT NULL DEFAULT '',
  `org_type` varchar(5) NOT NULL DEFAULT '',
  `service_area` text NOT NULL,
  `service_area_tracts` text NOT NULL,
  `status` char(1) NOT NULL DEFAULT 'Y',
  `service_area_type` int(3) NOT NULL DEFAULT '0',
  `naics_code` varchar(15) DEFAULT NULL,
  `investee_cert_number` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`cde_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Community Development Entities';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.cde_short_desc
CREATE TABLE IF NOT EXISTS `cde_short_desc` (
  `cde_short_id` int(8) NOT NULL AUTO_INCREMENT,
  `cde_id` int(5) NOT NULL,
  `short_name` varchar(30) NOT NULL DEFAULT ' ',
  `status` char(1) NOT NULL,
  PRIMARY KEY (`cde_short_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.cdfi_cash_disbursed
CREATE TABLE IF NOT EXISTS `cdfi_cash_disbursed` (
  `disbursed_id` int(8) NOT NULL DEFAULT '0',
  `cash_disbursed_id` int(8) NOT NULL DEFAULT '0',
  `cdfi_cash_disbursement_id` int(8) NOT NULL DEFAULT '0',
  `cde_id` int(8) NOT NULL DEFAULT '0',
  `status` char(1) NOT NULL DEFAULT '0',
  `investee_id` int(8) DEFAULT '0',
  PRIMARY KEY (`disbursed_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='This is used for cdfi report';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.cdfi_qlici_type
CREATE TABLE IF NOT EXISTS `cdfi_qlici_type` (
  `qlici_type_id` int(3) NOT NULL DEFAULT '0',
  `qlici_type_desc` varchar(15) NOT NULL DEFAULT '',
  `cdfi_code` varchar(10) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`qlici_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='CDE/QALICB';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.cdfi_report_info
CREATE TABLE IF NOT EXISTS `cdfi_report_info` (
  `report_id` int(8) NOT NULL DEFAULT '0',
  `cde_id` int(8) NOT NULL DEFAULT '0',
  `report_name` varchar(50) DEFAULT NULL,
  `file_name` varchar(50) DEFAULT NULL,
  `from_date` date DEFAULT '0000-00-00',
  `to_date` date DEFAULT '0000-00-00',
  `user_name` varchar(50) NOT NULL DEFAULT '',
  `sys_date` date DEFAULT '0000-00-00',
  `downloaded` char(1) DEFAULT 'N',
  `sent_cdfi` char(1) DEFAULT 'N',
  `status` char(1) DEFAULT 'Y',
  PRIMARY KEY (`report_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.cdfi_yesno_master
CREATE TABLE IF NOT EXISTS `cdfi_yesno_master` (
  `yn_id` char(2) NOT NULL DEFAULT '',
  `yn_desc` varchar(20) NOT NULL DEFAULT '',
  `cdfi_code` varchar(10) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`yn_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.character_master
CREATE TABLE IF NOT EXISTS `character_master` (
  `char_id` int(3) NOT NULL DEFAULT '0',
  `char_name` varchar(50) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`char_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Characteristic''s Master that apply to CDE ';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.ciis_ats_reporting
CREATE TABLE IF NOT EXISTS `ciis_ats_reporting` (
  `reporting_id` int(10) NOT NULL DEFAULT '0',
  `mail_setup_id` int(10) NOT NULL DEFAULT '0',
  `cde_id` int(10) NOT NULL DEFAULT '0',
  `start_date` date NOT NULL DEFAULT '0000-00-00',
  `due_date` date NOT NULL DEFAULT '0000-00-00',
  `next_report_date` date NOT NULL DEFAULT '0000-00-00',
  `alert_days` int(10) NOT NULL DEFAULT '0',
  `alert_status` char(1) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT '',
  `alert_type` int(8) DEFAULT NULL,
  PRIMARY KEY (`reporting_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='CIIS and ATS Reporting Table';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.ciis_errors
CREATE TABLE IF NOT EXISTS `ciis_errors` (
  `ciis_id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` varchar(255) DEFAULT NULL,
  `error_content` text,
  `error_notes` text,
  `status` varchar(255) DEFAULT 'Y',
  `field_name` varchar(150) DEFAULT NULL,
  `table_name` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`ciis_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.ciis_qalicb
CREATE TABLE IF NOT EXISTS `ciis_qalicb` (
  `ciis_qalicb_id` int(3) NOT NULL DEFAULT '0',
  `cde_id` int(8) NOT NULL DEFAULT '0',
  `qalicb_id` int(8) NOT NULL DEFAULT '0',
  `system_date` varchar(50) NOT NULL DEFAULT '0000-00-00',
  `status` char(1) NOT NULL DEFAULT 'Y',
  `investee_id` int(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`qalicb_id`,`cde_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.closeout_details
CREATE TABLE IF NOT EXISTS `closeout_details` (
  `closure_id` int(8) NOT NULL DEFAULT '0',
  `project_id` int(8) NOT NULL DEFAULT '0',
  `trans_id` varchar(15) NOT NULL DEFAULT '',
  `annual_year` int(4) NOT NULL DEFAULT '0',
  `closeout_per_id` int(2) NOT NULL DEFAULT '-1',
  `closeout_ref_id` int(2) NOT NULL DEFAULT '-1',
  `closeout_ref_src_id` int(2) NOT NULL DEFAULT '-1',
  `closeout_ref_src_others` text,
  `closeout_conv_equity` char(3) NOT NULL DEFAULT 'E',
  `closeout_restruct_reason` text,
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`closure_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.closeout_error_master
CREATE TABLE IF NOT EXISTS `closeout_error_master` (
  `closure_error_id` int(8) NOT NULL DEFAULT '0',
  `closure_error_content` text,
  `field_name` text,
  `table_name` text,
  `closure_error_notes` text,
  `ciis_error_content` text,
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`closure_error_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.closeout_loanloss_master
CREATE TABLE IF NOT EXISTS `closeout_loanloss_master` (
  `closeout_loanloss_id` int(8) NOT NULL DEFAULT '0',
  `closeout_loanloss_name` varchar(100) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`closeout_loanloss_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.closeout_performing_master
CREATE TABLE IF NOT EXISTS `closeout_performing_master` (
  `closeout_per_id` int(2) NOT NULL DEFAULT '0',
  `closeout_per_name` varchar(100) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`closeout_per_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.closeout_qalicb_details
CREATE TABLE IF NOT EXISTS `closeout_qalicb_details` (
  `closeout_qalicb_id` int(8) NOT NULL,
  `cde_id` int(5) NOT NULL DEFAULT '0',
  `qalicb_id` int(5) NOT NULL DEFAULT '0',
  `table_id` int(5) NOT NULL DEFAULT '0',
  `closeout_qalicb_intend_status` char(3) NOT NULL DEFAULT 'E',
  `closeout_qalicb_acquire_status` char(3) NOT NULL DEFAULT 'E',
  `qalicb_compliance_amount` double(20,2) NOT NULL DEFAULT '0.00',
  `closeout_status_id` int(2) NOT NULL DEFAULT '-1',
  `qalicb_comments` text,
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`closeout_qalicb_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.closeout_refinanced_master
CREATE TABLE IF NOT EXISTS `closeout_refinanced_master` (
  `closeout_ref_id` int(8) NOT NULL DEFAULT '0',
  `closeout_ref_name` varchar(100) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`closeout_ref_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.closeout_refinanced_source_master
CREATE TABLE IF NOT EXISTS `closeout_refinanced_source_master` (
  `closeout_ref_src_id` int(8) NOT NULL DEFAULT '0',
  `closeout_ref_src_name` varchar(100) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`closeout_ref_src_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.closeout_status_master
CREATE TABLE IF NOT EXISTS `closeout_status_master` (
  `closeout_status_id` int(8) NOT NULL DEFAULT '0',
  `closeout_status_name` varchar(100) NOT NULL DEFAULT '',
  `type` char(3) NOT NULL DEFAULT 'E',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`closeout_status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.closeout_trans_details
CREATE TABLE IF NOT EXISTS `closeout_trans_details` (
  `closeout_trans_id` int(8) NOT NULL,
  `trans_id` varchar(20) NOT NULL,
  `project_id` int(5) NOT NULL DEFAULT '0',
  `closeout_per_id` int(2) NOT NULL DEFAULT '0',
  `closeout_ref_id` int(2) NOT NULL DEFAULT '0',
  `closeout_ref_src_id` int(2) NOT NULL DEFAULT '0',
  `closeout_ref_src_others` text,
  `closeout_conv_equity` char(3) NOT NULL DEFAULT 'E',
  `closeout_restruct_reason` text,
  `closeout_qalicb_intend_status` char(3) NOT NULL DEFAULT 'E',
  `closeout_qalicb_acquire_status` char(3) NOT NULL DEFAULT 'E',
  `qalicb_compliance_amount` double(20,2) NOT NULL DEFAULT '-1.00',
  `closeout_status_id` int(2) NOT NULL DEFAULT '0',
  `qalicb_comments` text,
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`closeout_trans_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.collateral_type_master
CREATE TABLE IF NOT EXISTS `collateral_type_master` (
  `collateral_id` int(4) NOT NULL DEFAULT '0',
  `collateral_type` varchar(60) NOT NULL DEFAULT '',
  `cdfi_code` varchar(20) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`collateral_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Collateral Type Master';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.commercial_suboptions_master
CREATE TABLE IF NOT EXISTS `commercial_suboptions_master` (
  `com_suboptions_id` int(4) NOT NULL DEFAULT '0',
  `com_suboptions_desc` varchar(40) NOT NULL DEFAULT '',
  `cdfi_code` varchar(20) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`com_suboptions_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Real Estate - Commercial Purpose - Sub Options Master';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.comparable_master
CREATE TABLE IF NOT EXISTS `comparable_master` (
  `comp_master_id` int(4) NOT NULL DEFAULT '0',
  `comp_name` varchar(100) DEFAULT NULL,
  `cdfi_code` varchar(50) DEFAULT NULL,
  `status` char(2) DEFAULT NULL,
  PRIMARY KEY (`comp_master_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.construction_permanent_financing_master
CREATE TABLE IF NOT EXISTS `construction_permanent_financing_master` (
  `con_per_finance_id` int(8) NOT NULL DEFAULT '0',
  `con_per_finance_desc` varchar(60) NOT NULL DEFAULT '',
  `cdfi_code` varchar(20) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`con_per_finance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.contact_info
CREATE TABLE IF NOT EXISTS `contact_info` (
  `contact_id` int(10) NOT NULL DEFAULT '0',
  `cde_id` int(10) NOT NULL DEFAULT '0',
  `sub_cde_id` int(10) NOT NULL DEFAULT '0',
  `group_id` int(10) NOT NULL DEFAULT '0',
  `qalicb_id` int(10) NOT NULL DEFAULT '0',
  `project_id` int(10) NOT NULL DEFAULT '0',
  `investee_id` int(10) NOT NULL DEFAULT '0',
  `personal_id` int(10) NOT NULL DEFAULT '0',
  `investor_id` int(10) NOT NULL DEFAULT '0',
  `default_setup_id` int(10) NOT NULL DEFAULT '0',
  `reminder_type` int(10) NOT NULL DEFAULT '0',
  `email_id` varchar(500) NOT NULL DEFAULT '',
  `type` varchar(10) NOT NULL DEFAULT '',
  `status` varchar(3) NOT NULL DEFAULT 'Y',
  `modified_date` varchar(12) NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.counties_master
CREATE TABLE IF NOT EXISTS `counties_master` (
  `county_code` varchar(5) NOT NULL DEFAULT '',
  `state` char(2) DEFAULT NULL,
  `county_name` varchar(250) DEFAULT NULL,
  `total_pop` varchar(8) NOT NULL DEFAULT '',
  `msa_code` varchar(4) NOT NULL DEFAULT '',
  `msa_name` varchar(60) DEFAULT NULL,
  `ia_qual` int(1) NOT NULL DEFAULT '0',
  `hz_qual` int(1) NOT NULL DEFAULT '0',
  `hz_type` int(1) NOT NULL DEFAULT '0',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`county_code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Counties Master containing the county codes';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.customized_head_master
CREATE TABLE IF NOT EXISTS `customized_head_master` (
  `customized_head_master_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(50) NOT NULL DEFAULT '0',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`customized_head_master_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.customized_main_sub_head_map_details
CREATE TABLE IF NOT EXISTS `customized_main_sub_head_map_details` (
  `customized_main_sub_id` int(11) NOT NULL AUTO_INCREMENT,
  `customized_head_master_id` int(11) DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL,
  `status` char(1) DEFAULT 'Y',
  PRIMARY KEY (`customized_main_sub_id`),
  KEY `FK_customizedmainsub_customized_head_master_id` (`customized_head_master_id`),
  KEY `FK_customizedmainsub_group_id` (`group_id`),
  CONSTRAINT `FK_customizedmainsub_customized_head_master_id` FOREIGN KEY (`customized_head_master_id`) REFERENCES `customized_head_master` (`customized_head_master_id`),
  CONSTRAINT `FK_customizedmainsub_group_id` FOREIGN KEY (`group_id`) REFERENCES `group_master` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.customized_report_title_map
CREATE TABLE IF NOT EXISTS `customized_report_title_map` (
  `customized_report_title_map_id` int(11) NOT NULL AUTO_INCREMENT,
  `customized_main_sub_id` int(11) NOT NULL,
  `title_block` varchar(250) NOT NULL,
  `status` varchar(1) NOT NULL,
  PRIMARY KEY (`customized_report_title_map_id`),
  KEY `FK_customized_report_title_map_customized_main_sub_id` (`customized_main_sub_id`),
  CONSTRAINT `FK_customized_report_title_map_customized_main_sub_id` FOREIGN KEY (`customized_main_sub_id`) REFERENCES `customized_main_sub_head_map_details` (`customized_main_sub_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.custom_due_date_setup
CREATE TABLE IF NOT EXISTS `custom_due_date_setup` (
  `due_date_id` int(11) NOT NULL,
  `cde_id` int(11) NOT NULL,
  `cde_list` longtext,
  `comments` longtext,
  `completed_date` varchar(255) DEFAULT NULL,
  `content` longtext NOT NULL,
  `default_id` int(11) NOT NULL,
  `due_date` varchar(255) NOT NULL,
  `mail_cc` longtext,
  `mail_to` longtext NOT NULL,
  `reminder_setup_id` int(11) NOT NULL,
  `status` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `system_date` varchar(255) NOT NULL,
  PRIMARY KEY (`due_date_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.cvs_report
CREATE TABLE IF NOT EXISTS `cvs_report` (
  `cvs_id` int(5) NOT NULL DEFAULT '0',
  `description` text NOT NULL,
  `order_id` int(5) NOT NULL DEFAULT '0',
  `group_id` int(5) NOT NULL DEFAULT '0',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`cvs_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='used to get ';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.day_master
CREATE TABLE IF NOT EXISTS `day_master` (
  `day_id` int(11) NOT NULL,
  `day_name` varchar(20) NOT NULL,
  `status` char(1) NOT NULL,
  PRIMARY KEY (`day_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.default_mail_setup
CREATE TABLE IF NOT EXISTS `default_mail_setup` (
  `default_mail_id` int(10) NOT NULL DEFAULT '0',
  `remainder_type` int(10) NOT NULL DEFAULT '0',
  `cde_id` int(10) NOT NULL DEFAULT '0',
  `cde_list` varchar(100) NOT NULL DEFAULT '0',
  `status` varchar(10) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`default_mail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.default_menu
CREATE TABLE IF NOT EXISTS `default_menu` (
  `user_type` int(3) NOT NULL DEFAULT '0',
  `menu_id` int(3) NOT NULL DEFAULT '0',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`user_type`,`menu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Default menu''s for the user';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.default_rights
CREATE TABLE IF NOT EXISTS `default_rights` (
  `user_type` int(3) NOT NULL DEFAULT '0',
  `group_id` int(1) NOT NULL DEFAULT '0',
  `view_rt` int(8) DEFAULT '0',
  `add_rt` int(1) NOT NULL DEFAULT '0',
  `edit_rt` int(1) NOT NULL DEFAULT '0',
  `delete_rt` int(1) NOT NULL DEFAULT '0',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`user_type`,`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Default user''s rights';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.deleted_user_history
CREATE TABLE IF NOT EXISTS `deleted_user_history` (
  `user_name` varchar(50) NOT NULL DEFAULT '',
  `display_name` varchar(30) NOT NULL DEFAULT '',
  `password` varchar(30) NOT NULL DEFAULT '',
  `hint_ques` int(3) NOT NULL DEFAULT '0',
  `hint_ans` varchar(50) DEFAULT '',
  `email_id` varchar(50) NOT NULL DEFAULT '',
  `reg_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `group_id` int(3) NOT NULL DEFAULT '0',
  `personal_id` int(8) DEFAULT '0',
  `table_id` int(8) NOT NULL DEFAULT '0',
  `cde_id` int(8) NOT NULL DEFAULT '0',
  `status` char(1) NOT NULL DEFAULT 'R',
  `pass_exp_days` int(8) NOT NULL DEFAULT '0',
  `pass_exp_date` date DEFAULT NULL,
  `remove_status` char(1) NOT NULL DEFAULT 'N',
  PRIMARY KEY (`user_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.direct_tracing_date
CREATE TABLE IF NOT EXISTS `direct_tracing_date` (
  `tracing_id` int(8) NOT NULL DEFAULT '0',
  `qei_id` varchar(20) NOT NULL DEFAULT '0',
  `cde_id` int(8) NOT NULL DEFAULT '0',
  `option_type` int(3) NOT NULL DEFAULT '0',
  `first_year_test` varchar(20) DEFAULT '0000-00-00',
  `first_date` varchar(20) DEFAULT '0000-00-00',
  `second_date` varchar(20) DEFAULT '0000-00-00',
  `status` char(1) DEFAULT 'Y',
  `first_opt` char(1) NOT NULL DEFAULT 'N',
  PRIMARY KEY (`tracing_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.direct_tracing_detail
CREATE TABLE IF NOT EXISTS `direct_tracing_detail` (
  `detail_id` int(8) NOT NULL DEFAULT '0',
  `test_id` int(8) NOT NULL DEFAULT '0',
  `qei_id` varchar(20) DEFAULT NULL,
  `cde_id` int(8) NOT NULL DEFAULT '0',
  `qei_amount` double(20,2) DEFAULT '0.00',
  `current_qlici` double(20,2) DEFAULT '0.00',
  `previous_qlici` double(20,2) DEFAULT '0.00',
  `test_status` char(1) DEFAULT 'F',
  `status` char(1) DEFAULT 'Y',
  `annual_year` int(3) NOT NULL DEFAULT '0',
  `project_fund` double(15,2) NOT NULL DEFAULT '0.00',
  `op_fund` double(15,2) NOT NULL DEFAULT '0.00',
  `lr_fund` double(15,2) NOT NULL DEFAULT '0.00',
  `pf_percent` double(5,2) NOT NULL DEFAULT '0.00',
  `op_percent` double(5,2) DEFAULT '0.00',
  `lr_percent` double(5,2) DEFAULT '0.00',
  `qei_date` date NOT NULL DEFAULT '0000-00-00',
  `cur_outs_balance` double(15,2) NOT NULL DEFAULT '0.00',
  `cur_qcr_received` double(15,2) NOT NULL DEFAULT '0.00',
  `pre_outs_balance` double(15,2) NOT NULL DEFAULT '0.00',
  `pre_qcr_received` double(15,2) NOT NULL DEFAULT '0.00',
  `pre_test_id` int(8) NOT NULL DEFAULT '0',
  `pre_detail_id` int(8) NOT NULL DEFAULT '0',
  `pre_lr_fund` double(15,2) NOT NULL DEFAULT '0.00',
  `fcos_fund` double(15,2) NOT NULL DEFAULT '0.00',
  `fcos_percent` double(5,2) NOT NULL DEFAULT '0.00',
  `pre_fcos_fund` double(15,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`detail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.direct_tracing_test
CREATE TABLE IF NOT EXISTS `direct_tracing_test` (
  `test_id` int(8) NOT NULL DEFAULT '0',
  `cde_id` int(8) NOT NULL DEFAULT '0',
  `option_type` int(3) NOT NULL DEFAULT '0',
  `test_date` date DEFAULT NULL,
  `report_date` date DEFAULT NULL,
  `status` char(1) DEFAULT 'Y',
  PRIMARY KEY (`test_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.duedate_email_setup
CREATE TABLE IF NOT EXISTS `duedate_email_setup` (
  `duedate_email_setupid` int(10) NOT NULL AUTO_INCREMENT,
  `personal_id` int(11) NOT NULL,
  `entity_id` int(11) NOT NULL,
  `duedate_id` int(10) NOT NULL,
  `status` char(3) NOT NULL,
  `cde_id` int(10) NOT NULL,
  `table_id` int(10) NOT NULL,
  `rtype` int(10) NOT NULL,
  `type` char(3) NOT NULL,
  `mail_type` char(3) NOT NULL,
  `email` varchar(600) DEFAULT NULL,
  PRIMARY KEY (`duedate_email_setupid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.duedate_entity_reference
CREATE TABLE IF NOT EXISTS `duedate_entity_reference` (
  `duedate_reference_id` int(11) NOT NULL,
  `duedate_id` int(11) NOT NULL,
  `entity_id` int(11) NOT NULL,
  `status` char(1) NOT NULL,
  PRIMARY KEY (`duedate_reference_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.duedate_occurence_setup
CREATE TABLE IF NOT EXISTS `duedate_occurence_setup` (
  `occurence_id` int(8) NOT NULL AUTO_INCREMENT,
  `duedate_id` int(8) NOT NULL,
  `cde_id` int(8) NOT NULL,
  `remainder_type` int(8) NOT NULL,
  `occurence_status` char(2) NOT NULL,
  `occurence_date` varchar(10) NOT NULL DEFAULT '0000-00-00',
  `status` char(2) NOT NULL DEFAULT 'Y',
  `system_date` varchar(20) NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`occurence_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.duedate_setup
CREATE TABLE IF NOT EXISTS `duedate_setup` (
  `duedate_id` int(10) NOT NULL DEFAULT '0',
  `default_mail_id` int(10) NOT NULL DEFAULT '0',
  `cde_id` int(10) NOT NULL DEFAULT '0',
  `remainder_type` int(10) NOT NULL DEFAULT '0',
  `due_date` varchar(15) NOT NULL DEFAULT '0000-00-00',
  `start_duedate` date NOT NULL DEFAULT '0000-00-00',
  `next_duedate` varchar(15) DEFAULT '0000-00-00',
  `subject` text,
  `content` longblob,
  `status` char(1) NOT NULL DEFAULT 'Y',
  `default_due_id` int(10) NOT NULL DEFAULT '0',
  `replay_status` varchar(5) DEFAULT 'N',
  `mail_delivery_option_id` int(11) NOT NULL,
  `mail_reply_status` varchar(2) DEFAULT 'Y',
  `occurence_others_duedate_count_id` int(11) DEFAULT NULL,
  `occurence_others_interval` int(11) DEFAULT NULL,
  `occurence_type_id` varchar(2) NOT NULL,
  `occurence_week_id` int(2) DEFAULT NULL,
  `occurence_day_id` int(2) DEFAULT NULL,
  `running_status` varchar(2) NOT NULL,
  `reminder_cycle_id` int(2) NOT NULL DEFAULT '0',
  `reminder_cycle_times` int(11) NOT NULL DEFAULT '0',
  `reminder_endDate` varchar(15) DEFAULT '0000-00-00',
  PRIMARY KEY (`duedate_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.due_date_setup
CREATE TABLE IF NOT EXISTS `due_date_setup` (
  `due_date_id` int(8) NOT NULL DEFAULT '0',
  `reminder_setup_id` int(8) NOT NULL DEFAULT '0',
  `cde_id` int(8) NOT NULL DEFAULT '0',
  `due_date` varchar(15) NOT NULL DEFAULT '0000-00-00',
  `subject` varchar(200) NOT NULL,
  `content` text NOT NULL,
  `mail_to` text NOT NULL,
  `mail_cc` text,
  `completed_date` varchar(15) DEFAULT '0000-00-00',
  `comments` text,
  `system_date` varchar(15) NOT NULL DEFAULT '0000-00-00',
  `default_id` int(8) NOT NULL DEFAULT '0',
  `status` varchar(1) NOT NULL DEFAULT 'Y',
  `cde_list` text,
  PRIMARY KEY (`due_date_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.email_attach_info
CREATE TABLE IF NOT EXISTS `email_attach_info` (
  `email_attach_id` int(8) NOT NULL AUTO_INCREMENT,
  `table_id` int(8) NOT NULL DEFAULT '0',
  `cde_id` int(8) NOT NULL DEFAULT '0',
  `due_date_id` int(8) NOT NULL DEFAULT '0',
  `reminder_type` int(2) NOT NULL DEFAULT '0',
  `due_date` date DEFAULT '0000-00-00',
  `file_name` varchar(100) NOT NULL DEFAULT '',
  `original_file_name` text NOT NULL,
  `file_content_type` varchar(100) NOT NULL DEFAULT '',
  `file_location` varchar(100) NOT NULL DEFAULT '',
  `uploaded_date_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `file_group_id` int(8) NOT NULL DEFAULT '0',
  `file_size` bigint(12) NOT NULL DEFAULT '0',
  `session_id` varchar(255) NOT NULL DEFAULT '0',
  `status` char(3) NOT NULL DEFAULT '''Y''',
  `default_email_attach_id` int(8) NOT NULL DEFAULT '0',
  `due_date_ref_id` text,
  PRIMARY KEY (`email_attach_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.email_reminder_setup
CREATE TABLE IF NOT EXISTS `email_reminder_setup` (
  `reminder_setup_id` int(8) NOT NULL DEFAULT '0',
  `cde_id` int(8) NOT NULL DEFAULT '0',
  `setup_name` varchar(200) NOT NULL,
  `TYPE` varchar(3) NOT NULL,
  `system_date` varchar(15) NOT NULL DEFAULT '0000-00-00',
  `STATUS` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`reminder_setup_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.entity_master
CREATE TABLE IF NOT EXISTS `entity_master` (
  `entity_id` int(3) NOT NULL DEFAULT '0',
  `entity_desc` varchar(30) DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  `type` varchar(10) DEFAULT '',
  PRIMARY KEY (`entity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Entity type description as LLC/LLP/Individual/Trust etc...';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.equity_likely_features_master
CREATE TABLE IF NOT EXISTS `equity_likely_features_master` (
  `equity_likely_features_id` int(8) NOT NULL DEFAULT '0',
  `equity_likely_features_desc` char(60) NOT NULL DEFAULT '',
  `cdfi_code` char(20) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`equity_likely_features_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Equity Likely Features Master table';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.errors_group_master
CREATE TABLE IF NOT EXISTS `errors_group_master` (
  `errors_group_id` int(1) NOT NULL,
  `errors_group_name` varchar(200) NOT NULL,
  `status` char(1) NOT NULL,
  PRIMARY KEY (`errors_group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.errors_master
CREATE TABLE IF NOT EXISTS `errors_master` (
  `errors_master_id` int(10) NOT NULL AUTO_INCREMENT,
  `errors_description` text NOT NULL,
  `errors_group_id` int(3) NOT NULL,
  `status` char(1) NOT NULL,
  `last_modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`errors_master_id`),
  KEY `FK1_error_master_error_group` (`errors_group_id`),
  CONSTRAINT `FK1_error_master1_error_group` FOREIGN KEY (`errors_group_id`) REFERENCES `errors_group_master` (`errors_group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.error_master
CREATE TABLE IF NOT EXISTS `error_master` (
  `error_id` varchar(5) NOT NULL DEFAULT '0',
  `error_desc` text NOT NULL,
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`error_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Displaying Custom Error Messages';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.ethnicity_master
CREATE TABLE IF NOT EXISTS `ethnicity_master` (
  `eth_id` int(3) NOT NULL DEFAULT '0',
  `eth_desc` varchar(50) DEFAULT '',
  `cdfi_code` varchar(20) DEFAULT NULL,
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`eth_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Ethnicity master as Hispanic/Non-Hispanic';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.excel_field_describtion
CREATE TABLE IF NOT EXISTS `excel_field_describtion` (
  `desc_id` int(11) NOT NULL,
  `group_id` int(5) NOT NULL,
  `field_desc` varchar(400) DEFAULT '""',
  `field_name` varchar(100) DEFAULT '""',
  `table_name` varchar(100) DEFAULT '""',
  `status` varchar(5) DEFAULT 'Y',
  PRIMARY KEY (`desc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.fcos_details
CREATE TABLE IF NOT EXISTS `fcos_details` (
  `fcos_id` int(8) NOT NULL,
  `cash_details_id` int(8) NOT NULL,
  `qei_id` varchar(15) NOT NULL,
  `organization` varchar(200) DEFAULT NULL,
  `activity` varchar(200) DEFAULT NULL,
  `ind_trained_no` varchar(20) DEFAULT NULL,
  `grp_trained_no` varchar(20) DEFAULT NULL,
  `ind_trained_hrs` varchar(20) DEFAULT NULL,
  `grp_trained_hrs` varchar(20) DEFAULT NULL,
  `comments` varchar(200) DEFAULT NULL,
  `status` char(2) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`fcos_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.flexible_product_details_master
CREATE TABLE IF NOT EXISTS `flexible_product_details_master` (
  `flexible_product_details_id` int(3) NOT NULL DEFAULT '0',
  `flexible_product_desc` text,
  `display_order` int(3) DEFAULT '0',
  `status` char(1) DEFAULT 'Y',
  PRIMARY KEY (`flexible_product_details_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.fmail_info
CREATE TABLE IF NOT EXISTS `fmail_info` (
  `fmail_id` int(8) NOT NULL DEFAULT '0',
  `send_by_user` varchar(50) NOT NULL DEFAULT '',
  `cde_id` int(8) NOT NULL DEFAULT '0',
  `group_id` int(8) NOT NULL DEFAULT '0',
  `table_id` int(8) NOT NULL DEFAULT '0',
  `email_id` varchar(100) NOT NULL DEFAULT '',
  `send_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `fmail_type` varchar(20) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'N',
  `member_id` int(8) NOT NULL DEFAULT '0',
  `qalicb_id` int(8) NOT NULL DEFAULT '0',
  `ins_date_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `app_date_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `app_mem_id` int(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`fmail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.fund_info_copy
CREATE TABLE IF NOT EXISTS `fund_info_copy` (
  `fund_id` int(8) NOT NULL DEFAULT '0',
  `ammend_id` int(5) NOT NULL DEFAULT '0',
  `cde_id` int(5) NOT NULL DEFAULT '0',
  `investor_id` int(8) NOT NULL DEFAULT '0',
  `fund_date` date NOT NULL DEFAULT '0000-00-00',
  `fund_commit_year` int(4) DEFAULT NULL,
  `fund_amount` double(31,16) DEFAULT NULL,
  `status` char(2) DEFAULT 'Y',
  `fund_type` varchar(10) DEFAULT '',
  `end_date` varchar(20) DEFAULT NULL,
  `group_id` int(8) NOT NULL DEFAULT '0',
  `slno` int(2) NOT NULL DEFAULT '0',
  `sub_group_id` int(8) NOT NULL DEFAULT '0',
  `tier_type` int(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`fund_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.fund_info_history
CREATE TABLE IF NOT EXISTS `fund_info_history` (
  `fund_id` int(8) NOT NULL DEFAULT '0',
  `ammend_id` int(5) NOT NULL DEFAULT '0',
  `cde_id` int(5) NOT NULL DEFAULT '0',
  `investor_id` int(8) NOT NULL DEFAULT '0',
  `fund_date` date NOT NULL DEFAULT '0000-00-00',
  `fund_commit_year` int(4) DEFAULT NULL,
  `fund_amount` double(30,16) DEFAULT NULL,
  `status` char(2) DEFAULT 'Y',
  `fund_type` varchar(10) DEFAULT '',
  `end_date` varchar(20) DEFAULT NULL,
  `group_id` int(8) NOT NULL DEFAULT '0',
  `slno` int(2) NOT NULL DEFAULT '0',
  `sub_group_id` int(8) NOT NULL DEFAULT '0',
  `tier_type` int(8) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.gender_master
CREATE TABLE IF NOT EXISTS `gender_master` (
  `gender_id` int(3) NOT NULL DEFAULT '0',
  `gender_desc` varchar(20) NOT NULL DEFAULT '',
  `cdfi_code` varchar(10) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  `gender_cdfi_id` char(1) NOT NULL DEFAULT '',
  PRIMARY KEY (`gender_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Gender / Sex';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.geographic_master
CREATE TABLE IF NOT EXISTS `geographic_master` (
  `geo_id` int(3) NOT NULL DEFAULT '0',
  `geo_desc` varchar(50) DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`geo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Goegraphic Information''s Master table';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.global_boardmember_setup
CREATE TABLE IF NOT EXISTS `global_boardmember_setup` (
  `setup_id` int(10) NOT NULL AUTO_INCREMENT,
  `duedate_id` int(10) NOT NULL DEFAULT '0',
  `cde_id` int(10) NOT NULL DEFAULT '0',
  `email_to_address` text,
  `email_cc_address` text,
  `status` char(1) NOT NULL DEFAULT 'Y',
  `alert_type` int(3) NOT NULL DEFAULT '0',
  `default_mail_id` int(10) NOT NULL DEFAULT '0',
  `contact_to_address` text,
  `contact_cc_address` text,
  PRIMARY KEY (`setup_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.global_cde_setup
CREATE TABLE IF NOT EXISTS `global_cde_setup` (
  `update_id` int(5) NOT NULL DEFAULT '0',
  `setup_id` int(5) NOT NULL DEFAULT '0',
  `cde_id` int(5) NOT NULL DEFAULT '0',
  `alert_id` int(5) NOT NULL DEFAULT '0',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`update_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.global_fund_setup
CREATE TABLE IF NOT EXISTS `global_fund_setup` (
  `setup_id` int(10) NOT NULL DEFAULT '0',
  `cde_id` int(10) NOT NULL DEFAULT '0',
  `group_id` int(10) NOT NULL DEFAULT '0',
  `table_id` int(10) NOT NULL DEFAULT '0',
  `pf_percent` double(5,2) NOT NULL DEFAULT '0.00',
  `op_percent` double(5,2) NOT NULL DEFAULT '0.00',
  `lr_percent` double(5,2) NOT NULL DEFAULT '0.00',
  `system_date` date NOT NULL DEFAULT '0000-00-00',
  `status` char(1) NOT NULL DEFAULT 'Y',
  `boardmember_test` int(10) NOT NULL DEFAULT '0',
  `qalicb_test` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`setup_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.global_mail_remainder
CREATE TABLE IF NOT EXISTS `global_mail_remainder` (
  `remainder_id` int(10) NOT NULL DEFAULT '0',
  `duedate_id` int(10) NOT NULL DEFAULT '0',
  `cde_id` int(10) NOT NULL DEFAULT '0',
  `subcde_id` int(10) DEFAULT '0',
  `remainder_type` int(10) NOT NULL DEFAULT '0',
  `remainder_value` int(10) NOT NULL DEFAULT '0',
  `status` char(1) NOT NULL DEFAULT 'Y',
  `running_status` varchar(2) NOT NULL,
  `default_mail_id` int(10) NOT NULL DEFAULT '0',
  `default_remain_id` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`remainder_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.global_mail_service
CREATE TABLE IF NOT EXISTS `global_mail_service` (
  `service_id` int(10) NOT NULL DEFAULT '0',
  `cde_id` int(10) NOT NULL DEFAULT '0',
  `master_service_id` int(10) NOT NULL DEFAULT '0',
  `service_status` char(1) NOT NULL DEFAULT 'N',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`service_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Global Mail Services ';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.grouping_master
CREATE TABLE IF NOT EXISTS `grouping_master` (
  `group_id` int(3) NOT NULL DEFAULT '0',
  `group_name` varchar(30) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Group Master for identifying CDE/Board member/Subsidary/Qual';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.group_master
CREATE TABLE IF NOT EXISTS `group_master` (
  `group_id` int(3) NOT NULL DEFAULT '0',
  `group_name` varchar(30) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Group Master for identifying CDE/Board member/Subsidary/Qual';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.guarantee_master
CREATE TABLE IF NOT EXISTS `guarantee_master` (
  `guarantee_id` int(8) NOT NULL DEFAULT '0',
  `guarantee_desc` varchar(60) NOT NULL DEFAULT '',
  `cdfi_code` varchar(20) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`guarantee_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Guarantee Master';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.helpdesk_problem
CREATE TABLE IF NOT EXISTS `helpdesk_problem` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `pcategory` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.higher_distress_areas_master
CREATE TABLE IF NOT EXISTS `higher_distress_areas_master` (
  `hda_id` int(8) NOT NULL DEFAULT '0',
  `hda_desc` text NOT NULL,
  `cdfi_code` varchar(20) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  `priority_id` int(8) NOT NULL DEFAULT '0',
  `hda_short_name` varchar(200) NOT NULL,
  PRIMARY KEY (`hda_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.hispanic_origin_master
CREATE TABLE IF NOT EXISTS `hispanic_origin_master` (
  `hispanic_id` char(3) NOT NULL DEFAULT '0',
  `hispanic_desc` char(20) DEFAULT NULL,
  `cdfi_code` char(5) DEFAULT NULL,
  `status` char(2) DEFAULT NULL,
  PRIMARY KEY (`hispanic_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.history
CREATE TABLE IF NOT EXISTS `history` (
  `h_id` int(8) NOT NULL DEFAULT '0',
  `table_name` varchar(30) NOT NULL DEFAULT '',
  `field_name` varchar(50) NOT NULL DEFAULT '',
  `key_id` varchar(20) NOT NULL DEFAULT '',
  `old_value` varchar(255) NOT NULL DEFAULT '',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `from_date` date NOT NULL DEFAULT '0000-00-00',
  `to_date` date NOT NULL DEFAULT '0000-00-00',
  `action` varchar(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`h_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='History Cache table that stores all the historical info.';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.housing_suboptions_master
CREATE TABLE IF NOT EXISTS `housing_suboptions_master` (
  `house_suboptions_id` int(4) NOT NULL DEFAULT '0',
  `house_suboptions_desc` varchar(40) NOT NULL DEFAULT '',
  `cdfi_code` varchar(20) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`house_suboptions_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Real Estate - Housing Purpose - Sub Options Master';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.idlefund_trigger_mail
CREATE TABLE IF NOT EXISTS `idlefund_trigger_mail` (
  `idlefund_mail_id` int(10) NOT NULL DEFAULT '0',
  `mail_setup_id` int(10) NOT NULL DEFAULT '0',
  `investor_id` int(10) NOT NULL DEFAULT '0',
  `pf_id` int(10) NOT NULL DEFAULT '0',
  `due_date` date NOT NULL DEFAULT '0000-00-00',
  `days_idle` int(10) NOT NULL DEFAULT '0',
  `alert_days` int(10) NOT NULL DEFAULT '0',
  `alert_status` char(1) NOT NULL DEFAULT 'N',
  `status` char(1) NOT NULL DEFAULT 'N',
  PRIMARY KEY (`idlefund_mail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Trigger Mail Setup For Idle Fund ';

-- Data exporting was unselected.


-- Dumping structure for procedure cdesolution.ilr_qei_source
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `ilr_qei_source`(IN `cdeId` TEXT, IN `yearId` TEXT, IN `fromDate` VARCHAR(10), IN `toDate` VARCHAR(10))
BEGIN
    
    SELECT c1.*, COALESCE(c2.lr_q_fund, 0) lr_q_fund FROM 
(SELECT b1.*, COALESCE(b2.invqlici, 0) invqlici FROM 
(SELECT a1.*, COALESCE(a2.qlici,0) qlici FROM 
(SELECT pfm.pf_id, pfm.cash_details_id, pfm.qei_id, cd.qeiid_from_ats,  pfm.pf_date, pfm.cde_id, 
  pfm.alloc_year,  pfm.total_amt, pfm.fcos_fund, pfm.op_fund, pfm.lr_fund,  pfm.project_fund   
 FROM project_fund_master pfm, cash_details cd
WHERE 
pfm.pf_date>=fromDate AND pfm.pf_date<=toDate
AND FIND_IN_SET(pfm.cde_id, cdeId)
AND FIND_IN_SET(pfm.alloc_year, yearId)
AND pfm.type = 'I'  AND cd.cash_details_id = pfm.cash_details_id
AND pfm.status!='D' AND cd.status != 'D' 
ORDER BY cd.qeiid_from_ats) AS a1
LEFT JOIN (
SELECT a.qei_id, SUM(COALESCE(a.disbAmt,0) - COALESCE(b.receivedAmt,0)) AS qlici 
FROM   
(SELECT cd.qei_id,SUM(COALESCE(cd.amount,0)) AS disbAmt 
FROM cash_disbursed cd,cash_details cc 
WHERE (cd.pf_id!=0 && cd.inv_pf_id=0) AND FIND_IN_SET(cd.cde_id, cdeId) 
AND cc.cash_details_id=cd.cash_details_id 
AND  cd.cash_received_date<=toDate AND cc.type IN('CD') 
AND cd.status!='D' AND  cc.status!='D' GROUP BY cd.qei_id)AS a 
LEFT JOIN ( SELECT cr.qei_id,SUM(COALESCE(cr.received_amt,0))AS receivedAmt 
FROM qalicb_qei_received cr,cash_details cc WHERE FIND_IN_SET(cr.cde_id, cdeId)  
AND cr.pf_id!=0 AND transfer_id=0 AND cc.cash_details_id=cr.cash_details_id
 AND  cr.received_date<=toDate AND cr.type IN ('QEP','QSP','QUP') AND cc.type IN('CQB') 
 AND cr.status!='D' AND cc.status!='D' GROUP BY cr.qei_id)AS b ON a.qei_id=b.qei_id
 GROUP BY a.qei_id
) AS a2 ON a1.qei_id = a2.qei_id ) AS b1
LEFT JOIN (
SELECT a.qei_id, SUM(COALESCE(a.disbAmt,0)- COALESCE(b.receivedAmt,0)) AS invqlici 
 FROM   (
 SELECT cd.qei_id,SUM(COALESCE(cd.amount, 0)) AS disbAmt FROM cash_disbursed cd,cash_details cc 
 WHERE FIND_IN_SET(cd.cde_id, cdeId)  
 AND  (cd.pf_id=0 && cd.inv_pf_id!=0) AND cc.cash_details_id=cd.cash_details_id 
 AND  cd.cash_received_date<=toDate AND cc.type IN('QCD') AND cd.status!='D' 
 AND  cc.status!='D' GROUP BY cd.qei_id)AS a 
 LEFT JOIN ( SELECT cr.qei_id,SUM(COALESCE(cr.received_amt, 0))AS receivedAmt 
 FROM qalicb_qei_received cr,cash_details cc 
 WHERE FIND_IN_SET(cr.cde_id, cdeId)   
 AND cr.pf_id!=0 AND transfer_id=0 
 AND cc.cash_details_id=cr.cash_details_id 
 AND  cr.received_date<=toDate AND cr.type IN ('QEP','QSP','QUP') 
 AND cc.type IN('ICQB') AND  cr.status!='D' AND cc.status!='D' 
 GROUP BY cr.qei_id)AS b ON a.qei_id=b.qei_id
 
  GROUP BY a.qei_id
)AS  b2 ON b1.qei_id = b2.qei_id ) AS c1
LEFT JOIN (
SELECT lr.qei_id, SUM(COALESCE(lr.qalicb_lr_fund,0)) lr_q_fund
  FROM cash_details cc,lr_splitup_history lr  
  WHERE FIND_IN_SET(lr.cde_id, cdeId)   
  AND lr.cash_details_id=cc.cash_details_id AND cc.type='QLR' 
  AND cc.received_date <=toDate AND lr.status!='D' 
  AND cc.status!='D' AND lr.fund_type = 'QLR' GROUP BY lr.qei_id
) AS c2 ON c1.qei_id = c2.qei_id
ORDER BY c1.qeiid_from_ats;
    END//
DELIMITER ;


-- Dumping structure for table cdesolution.interest_rate_history
CREATE TABLE IF NOT EXISTS `interest_rate_history` (
  `interest_rate_id` int(7) NOT NULL,
  `trans_id` varchar(15) NOT NULL,
  `cde_id` int(7) NOT NULL,
  `qalicb_id` int(7) NOT NULL,
  `project_id` int(7) NOT NULL,
  `ammend_id` int(7) NOT NULL,
  `interest_rate` double(6,3) DEFAULT '-1.000',
  `interest_rate_date` varchar(10) NOT NULL DEFAULT '0000-00-00',
  `system_date` varchar(10) NOT NULL DEFAULT '0000-00-00',
  `from_status` char(2) DEFAULT 'I',
  `status` char(2) DEFAULT 'Y',
  PRIMARY KEY (`interest_rate_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.interest_type_master
CREATE TABLE IF NOT EXISTS `interest_type_master` (
  `interest_type_id` int(4) NOT NULL DEFAULT '0',
  `interest_type_desc` varchar(60) NOT NULL DEFAULT '',
  `cdfi_code` varchar(20) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`interest_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Interest Type Master';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.investee_project_fund_master
CREATE TABLE IF NOT EXISTS `investee_project_fund_master` (
  `pf_id` int(8) NOT NULL DEFAULT '0',
  `cash_details_id` int(8) NOT NULL DEFAULT '0',
  `cde_id` int(8) NOT NULL DEFAULT '0',
  `alloc_year` varchar(4) NOT NULL DEFAULT '',
  `investor_id` int(8) NOT NULL DEFAULT '0',
  `total_amt` double(20,2) NOT NULL DEFAULT '0.00',
  `project_fund` double(20,2) NOT NULL DEFAULT '0.00',
  `op_fund` double(20,2) DEFAULT '0.00',
  `lr_fund` double(20,2) DEFAULT '0.00',
  `pf_percent` double(5,2) NOT NULL DEFAULT '0.00',
  `op_percent` double(5,2) DEFAULT '0.00',
  `lr_percent` double(5,2) DEFAULT '0.00',
  `system_date` date NOT NULL DEFAULT '0000-00-00',
  `pf_date` date NOT NULL DEFAULT '0000-00-00',
  `type` char(3) NOT NULL DEFAULT '',
  `pf_bal_fund` double(20,2) NOT NULL DEFAULT '0.00',
  `op_bal_fund` double(20,2) DEFAULT '0.00',
  `qei_id` varchar(15) DEFAULT NULL,
  `qei_date` date DEFAULT '0000-00-00',
  `disburse_cash_id` int(8) DEFAULT '0',
  `open_disburse_id` int(8) DEFAULT '0',
  `src_type` varchar(4) DEFAULT NULL,
  `status` char(1) NOT NULL DEFAULT 'Y',
  `investee_id` int(8) NOT NULL DEFAULT '0',
  `src_trans_type` varchar(15) NOT NULL DEFAULT '',
  `pf_due_date` varchar(10) DEFAULT '0000-00-00',
  PRIMARY KEY (`pf_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.investee_suboption_master
CREATE TABLE IF NOT EXISTS `investee_suboption_master` (
  `investee_suboption_id` int(3) NOT NULL DEFAULT '0',
  `investee_suboption_desc` varchar(40) NOT NULL DEFAULT '',
  `cdfi_code` varchar(20) DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`investee_suboption_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='InvesteeSuboption Master contains RealEstate/Non Real-Estate';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.investee_type_master
CREATE TABLE IF NOT EXISTS `investee_type_master` (
  `investee_type_id` int(3) NOT NULL DEFAULT '0',
  `investee_type_desc` varchar(40) NOT NULL DEFAULT '',
  `cdfi_code` varchar(20) DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`investee_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='InvesteeType Master contains Indiv/Business/Micro-enterprise';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.investor_cde_map
CREATE TABLE IF NOT EXISTS `investor_cde_map` (
  `map_id` int(8) NOT NULL DEFAULT '0',
  `cde_id` int(8) NOT NULL DEFAULT '0',
  `investor_id` int(8) NOT NULL DEFAULT '0',
  `group_id` int(8) NOT NULL DEFAULT '0',
  `status` char(1) NOT NULL DEFAULT '0',
  `fund_commit_year` int(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`map_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.investor_cde_ownership
CREATE TABLE IF NOT EXISTS `investor_cde_ownership` (
  `ownership_id` int(255) NOT NULL AUTO_INCREMENT,
  `cde_id` int(255) DEFAULT NULL,
  `investor_id` int(255) DEFAULT NULL,
  `group_id` int(255) DEFAULT NULL,
  `sub_group_id` int(255) DEFAULT NULL,
  `tier_type` int(10) DEFAULT NULL,
  `percentage` double(255,2) DEFAULT NULL,
  `effective_date` varchar(255) DEFAULT NULL,
  `ammend_id` int(255) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`ownership_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.investor_cde_ownership_history
CREATE TABLE IF NOT EXISTS `investor_cde_ownership_history` (
  `ownership_id` int(255) NOT NULL AUTO_INCREMENT,
  `cde_id` int(255) DEFAULT NULL,
  `investor_id` int(255) DEFAULT NULL,
  `group_id` int(255) DEFAULT NULL,
  `sub_group_id` int(255) DEFAULT NULL,
  `tier_type` int(10) DEFAULT NULL,
  `percentage` double(255,2) DEFAULT NULL,
  `effective_date` varchar(255) DEFAULT NULL,
  `ammend_id` int(255) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`ownership_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.investor_cde_relation
CREATE TABLE IF NOT EXISTS `investor_cde_relation` (
  `relation_id` int(255) NOT NULL AUTO_INCREMENT,
  `cde_id` int(255) DEFAULT NULL,
  `tier1_investor_id` int(255) DEFAULT NULL,
  `investor_group_id` int(255) DEFAULT NULL,
  `status` varchar(10) DEFAULT 'Y',
  PRIMARY KEY (`relation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.investor_info_copy
CREATE TABLE IF NOT EXISTS `investor_info_copy` (
  `investor_id` int(8) NOT NULL DEFAULT '0',
  `cde_id` int(5) NOT NULL DEFAULT '0',
  `personal_id` int(8) DEFAULT '0',
  `entity_id` int(3) NOT NULL DEFAULT '0',
  `investor_type` int(3) NOT NULL DEFAULT '0',
  `investor_indication` char(3) NOT NULL DEFAULT '',
  `taxpay_no` varchar(15) DEFAULT NULL,
  `investment_type` char(1) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT '',
  `leaverage` char(1) DEFAULT '',
  `commit_from_sub` char(1) DEFAULT '',
  `allocation_year` int(4) DEFAULT '0',
  `only_parent` char(1) DEFAULT '',
  `relation_status` char(1) NOT NULL DEFAULT '',
  `child_cash_drawn` char(1) NOT NULL DEFAULT 'N',
  `investor_master_id` int(8) DEFAULT '0',
  PRIMARY KEY (`investor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.investor_login_info
CREATE TABLE IF NOT EXISTS `investor_login_info` (
  `user_id` int(8) NOT NULL DEFAULT '0',
  `user_name` varchar(50) NOT NULL DEFAULT '',
  `display_name` varchar(30) NOT NULL DEFAULT '',
  `password` varchar(30) NOT NULL DEFAULT '',
  `hint_ques` int(3) NOT NULL DEFAULT '0',
  `hint_ans` varchar(50) DEFAULT '',
  `email_id` varchar(50) NOT NULL DEFAULT '',
  `reg_date` date NOT NULL DEFAULT '0000-00-00',
  `change_date` date NOT NULL DEFAULT '0000-00-00',
  `from_date` date NOT NULL DEFAULT '0000-00-00',
  `to_date` date NOT NULL DEFAULT '0000-00-00',
  `group_id` int(3) NOT NULL DEFAULT '0',
  `personal_id` int(8) DEFAULT '0',
  `table_id` int(8) NOT NULL DEFAULT '0',
  `cde_id` int(8) NOT NULL DEFAULT '0',
  `status` char(1) NOT NULL DEFAULT 'R',
  `total_logins` int(8) NOT NULL DEFAULT '0',
  `ammend_id` int(8) NOT NULL DEFAULT '0',
  `pass_exp_days` int(8) NOT NULL DEFAULT '0',
  `pass_exp_date` date DEFAULT NULL,
  `remove_status` char(1) NOT NULL DEFAULT 'N',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='User''s Login name and password';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.investor_login_master
CREATE TABLE IF NOT EXISTS `investor_login_master` (
  `user_name` varchar(50) NOT NULL DEFAULT '',
  `display_name` varchar(30) NOT NULL DEFAULT '',
  `password` varchar(30) NOT NULL DEFAULT '',
  `hint_ques` int(3) NOT NULL DEFAULT '0',
  `hint_ans` varchar(50) DEFAULT '',
  `email_id` varchar(50) NOT NULL DEFAULT '',
  `reg_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `group_id` int(3) NOT NULL DEFAULT '0',
  `personal_id` int(8) DEFAULT '0',
  `table_id` int(8) NOT NULL DEFAULT '0',
  `cde_id` int(8) NOT NULL DEFAULT '0',
  `status` char(1) NOT NULL DEFAULT 'R',
  `pass_exp_days` int(8) NOT NULL DEFAULT '0',
  `pass_exp_date` date DEFAULT NULL,
  `remove_status` char(1) NOT NULL DEFAULT 'N',
  PRIMARY KEY (`user_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='User''s Login name and password';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.investor_master
CREATE TABLE IF NOT EXISTS `investor_master` (
  `investor_master_id` int(8) NOT NULL DEFAULT '0',
  `investor_id` int(8) NOT NULL DEFAULT '0',
  `status` char(2) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`investor_master_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.investor_menu_master
CREATE TABLE IF NOT EXISTS `investor_menu_master` (
  `menu_id` int(3) NOT NULL DEFAULT '0',
  `menu_name` varchar(50) NOT NULL DEFAULT '',
  `link` varchar(150) DEFAULT NULL,
  `menu_type` varchar(10) NOT NULL DEFAULT '',
  `group_head` int(3) DEFAULT NULL,
  `sub_group_head` int(3) DEFAULT NULL,
  `priority_id` int(4) NOT NULL DEFAULT '0',
  `width` int(3) NOT NULL DEFAULT '0',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`menu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.investor_relation_copy
CREATE TABLE IF NOT EXISTS `investor_relation_copy` (
  `investor_id` int(8) NOT NULL DEFAULT '0',
  `tier1_id` int(8) NOT NULL DEFAULT '0',
  `tier2_id` int(8) NOT NULL DEFAULT '0',
  `status` char(1) DEFAULT 'Y',
  `tier3_id` int(8) NOT NULL DEFAULT '0',
  `cde_id` int(8) NOT NULL DEFAULT '0',
  `group_id` int(8) NOT NULL DEFAULT '0',
  `slno` int(2) NOT NULL DEFAULT '0',
  `owner_per` double(5,2) NOT NULL DEFAULT '0.00',
  `ammend_id` int(8) DEFAULT '0',
  `sub_group_id` int(8) DEFAULT '0',
  `tier_type` int(8) DEFAULT '0',
  `invest_relate_id` int(8) DEFAULT '0',
  `investor_master_id` int(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`investor_id`,`cde_id`,`tier1_id`,`tier2_id`,`tier3_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.investor_relation_history
CREATE TABLE IF NOT EXISTS `investor_relation_history` (
  `investor_id` int(8) DEFAULT '0',
  `tier1_id` int(8) DEFAULT '0',
  `tier2_id` int(8) DEFAULT '0',
  `status` char(1) DEFAULT 'Y',
  `tier3_id` int(8) DEFAULT '0',
  `cde_id` int(8) DEFAULT '0',
  `group_id` int(8) DEFAULT '0',
  `slno` int(2) DEFAULT '0',
  `owner_per` double(5,2) DEFAULT '0.00',
  `ammend_id` int(8) DEFAULT '0',
  `sub_group_id` int(8) DEFAULT '0',
  `tier_type` int(8) DEFAULT '0',
  `invest_relate_id` int(8) DEFAULT '0',
  `investor_master_id` int(8) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.investor_type_master
CREATE TABLE IF NOT EXISTS `investor_type_master` (
  `investor_type` int(3) NOT NULL DEFAULT '0',
  `investor_type_desc` text,
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`investor_type`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Type of the Investor - Master''s table';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.investor_user_menu
CREATE TABLE IF NOT EXISTS `investor_user_menu` (
  `user_name` varchar(30) NOT NULL DEFAULT '0',
  `menu_id` int(3) NOT NULL DEFAULT '0',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`user_name`,`menu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Menu Master for a particular user';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.investor_user_rights
CREATE TABLE IF NOT EXISTS `investor_user_rights` (
  `user_name` varchar(30) NOT NULL DEFAULT '',
  `group_id` int(3) NOT NULL DEFAULT '0',
  `view_rt` int(1) NOT NULL DEFAULT '0',
  `add_rt` int(1) NOT NULL DEFAULT '0',
  `edit_rt` int(1) NOT NULL DEFAULT '0',
  `delete_rt` int(1) NOT NULL DEFAULT '0',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`user_name`,`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.inv_duedate_info
CREATE TABLE IF NOT EXISTS `inv_duedate_info` (
  `inv_duedate_id` int(10) NOT NULL DEFAULT '0',
  `cde_id` int(10) NOT NULL DEFAULT '0',
  `remainder_type` int(10) NOT NULL DEFAULT '0',
  `due_date` date NOT NULL DEFAULT '0000-00-00',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`inv_duedate_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.jobtype_report_master
CREATE TABLE IF NOT EXISTS `jobtype_report_master` (
  `job_type_id` int(8) NOT NULL,
  `job_type_desc` text NOT NULL,
  `cdfi_code` text NOT NULL,
  `status` varchar(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`job_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.job_estimate_master
CREATE TABLE IF NOT EXISTS `job_estimate_master` (
  `job_estimate_id` int(8) NOT NULL,
  `job_estimate_desc` text NOT NULL,
  `cdfi_code` text NOT NULL,
  `status` varchar(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`job_estimate_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.lic_ownertype_master
CREATE TABLE IF NOT EXISTS `lic_ownertype_master` (
  `owner_id` int(3) NOT NULL DEFAULT '0',
  `owner_desc` varchar(50) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`owner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Type of ownership in LIC';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.lien_position_master
CREATE TABLE IF NOT EXISTS `lien_position_master` (
  `lien_position_id` int(4) NOT NULL DEFAULT '0',
  `lien_position_desc` varchar(60) NOT NULL DEFAULT '',
  `cdfi_code` varchar(20) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`lien_position_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Project Loan - Lien Position master';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.loan_closed_master
CREATE TABLE IF NOT EXISTS `loan_closed_master` (
  `loan_closed_id` int(3) NOT NULL DEFAULT '0',
  `loan_closed_desc` varchar(25) NOT NULL DEFAULT '',
  `cdfi_code` varchar(10) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`loan_closed_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Loan Closed Status';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.loan_forgiveness
CREATE TABLE IF NOT EXISTS `loan_forgiveness` (
  `Loan_forgive_id` int(10) NOT NULL DEFAULT '0',
  `Cash_details_id` int(10) NOT NULL DEFAULT '0',
  `Cde_id` int(10) NOT NULL DEFAULT '0',
  `Qalicb_id` int(10) NOT NULL DEFAULT '0',
  `Project_id` int(10) NOT NULL DEFAULT '0',
  `Trans_id` varchar(15) NOT NULL DEFAULT '',
  `Disburse_cash_id` int(10) NOT NULL DEFAULT '0',
  `forgive_date` date NOT NULL DEFAULT '0000-00-00',
  `forgive_amt` double(10,2) NOT NULL DEFAULT '0.00',
  `Src_type` varchar(10) NOT NULL,
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`Loan_forgive_id`,`Cash_details_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.loan_invest_master
CREATE TABLE IF NOT EXISTS `loan_invest_master` (
  `loan_invest_id` int(8) NOT NULL DEFAULT '0',
  `loan_invest_desc` char(60) NOT NULL DEFAULT '',
  `cdfi_code` char(20) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`loan_invest_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Project Loan Investment - Fresh / Refinanced';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.loan_status_master
CREATE TABLE IF NOT EXISTS `loan_status_master` (
  `loan_status_id` int(3) NOT NULL DEFAULT '0',
  `loan_status_desc` varchar(50) NOT NULL DEFAULT '',
  `cdfi_code` varchar(10) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`loan_status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Loan Closed Status';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.loan_type_master
CREATE TABLE IF NOT EXISTS `loan_type_master` (
  `loan_type_id` int(8) NOT NULL DEFAULT '0',
  `loan_type_desc` varchar(60) NOT NULL DEFAULT '',
  `cdfi_code` varchar(20) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`loan_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='LoanType Master - Term Loan / LOC';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.login_info
CREATE TABLE IF NOT EXISTS `login_info` (
  `user_id` int(8) NOT NULL DEFAULT '0',
  `user_name` varchar(50) NOT NULL DEFAULT '',
  `display_name` varchar(30) NOT NULL DEFAULT '',
  `password` varchar(30) NOT NULL DEFAULT '',
  `hint_ques` int(3) NOT NULL DEFAULT '0',
  `hint_ans` varchar(50) DEFAULT '',
  `email_id` varchar(50) NOT NULL DEFAULT '',
  `reg_date` date DEFAULT '0000-00-00',
  `change_date` date DEFAULT '0000-00-00',
  `from_date` date DEFAULT '0000-00-00',
  `to_date` date DEFAULT '0000-00-00',
  `group_id` int(3) NOT NULL DEFAULT '0',
  `personal_id` int(8) DEFAULT '0',
  `table_id` int(8) NOT NULL DEFAULT '0',
  `cde_id` int(8) NOT NULL DEFAULT '0',
  `status` char(1) NOT NULL DEFAULT 'R',
  `total_logins` int(8) NOT NULL DEFAULT '0',
  `ammend_id` int(8) NOT NULL DEFAULT '0',
  `pass_exp_days` int(8) NOT NULL DEFAULT '0',
  `pass_exp_date` date DEFAULT NULL,
  `remove_status` char(1) NOT NULL DEFAULT 'N',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='User''s Login name and password';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.login_master
CREATE TABLE IF NOT EXISTS `login_master` (
  `user_name` varchar(50) NOT NULL DEFAULT '',
  `display_name` varchar(30) NOT NULL DEFAULT '',
  `password` varchar(30) NOT NULL DEFAULT '',
  `hint_ques` int(3) NOT NULL DEFAULT '0',
  `hint_ans` varchar(50) DEFAULT '',
  `email_id` varchar(50) NOT NULL DEFAULT '',
  `reg_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `group_id` int(3) NOT NULL DEFAULT '0',
  `personal_id` int(8) DEFAULT '0',
  `table_id` int(8) NOT NULL DEFAULT '0',
  `cde_id` int(8) NOT NULL DEFAULT '0',
  `status` char(1) NOT NULL DEFAULT 'R',
  `pass_exp_days` int(8) NOT NULL DEFAULT '0',
  `pass_exp_date` date DEFAULT NULL,
  `remove_status` char(1) NOT NULL DEFAULT 'N',
  PRIMARY KEY (`user_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='User''s Login name and password';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.login_menu
CREATE TABLE IF NOT EXISTS `login_menu` (
  `user_id` int(8) NOT NULL DEFAULT '0',
  `menu_id` int(8) NOT NULL DEFAULT '0',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`user_id`,`menu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.logo_upload_info
CREATE TABLE IF NOT EXISTS `logo_upload_info` (
  `logo_upload_id` int(8) NOT NULL DEFAULT '0',
  `cde_id` int(8) NOT NULL DEFAULT '0',
  `gen_file_name` varchar(200) NOT NULL DEFAULT '',
  `file_name` varchar(200) NOT NULL DEFAULT '',
  `file_content_type` varchar(100) NOT NULL DEFAULT '',
  `file_location` varchar(100) NOT NULL DEFAULT '',
  `upload_date` date NOT NULL DEFAULT '0000-00-00',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`logo_upload_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.lr_splitup_history
CREATE TABLE IF NOT EXISTS `lr_splitup_history` (
  `splitup_id` int(8) NOT NULL DEFAULT '0',
  `cash_details_id` int(8) NOT NULL DEFAULT '0',
  `pf_id` int(8) NOT NULL DEFAULT '0',
  `pf_cash_details_id` int(8) NOT NULL DEFAULT '0',
  `qei_id` varchar(15) NOT NULL,
  `pf_date` varchar(20) NOT NULL DEFAULT '0000-00-00',
  `type` varchar(8) NOT NULL,
  `qalicb_lr_fund` double(20,2) NOT NULL DEFAULT '0.00',
  `cde_id` int(8) NOT NULL,
  `alloc_year` varchar(4) DEFAULT NULL,
  `total_amt` double(20,2) NOT NULL DEFAULT '0.00',
  `project_fund` double(20,2) NOT NULL DEFAULT '0.00',
  `op_fund` double(20,2) DEFAULT '0.00',
  `lr_fund` double(20,2) DEFAULT '0.00',
  `pf_percent` double(5,2) NOT NULL DEFAULT '0.00',
  `op_percent` double(5,2) DEFAULT '0.00',
  `lr_percent` double(5,2) DEFAULT '0.00',
  `pf_bal_fund` double(20,2) NOT NULL DEFAULT '0.00',
  `op_bal_fund` double(20,2) DEFAULT '0.00',
  `system_date` varchar(20) NOT NULL DEFAULT '0000-00-00',
  `status` varchar(1) NOT NULL DEFAULT 'Y',
  `fund_type` char(4) DEFAULT NULL,
  PRIMARY KEY (`splitup_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.mail_alert_type
CREATE TABLE IF NOT EXISTS `mail_alert_type` (
  `alert_type_id` int(10) NOT NULL DEFAULT '0',
  `alert_type_name` varchar(50) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`alert_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='alert type for trigger mai';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.mail_delivery_option_master
CREATE TABLE IF NOT EXISTS `mail_delivery_option_master` (
  `mail_delivery_option_master_id` int(11) NOT NULL,
  `mail_delivery_name` varchar(255) NOT NULL,
  `status` char(1) DEFAULT NULL,
  PRIMARY KEY (`mail_delivery_option_master_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.mail_global_setup
CREATE TABLE IF NOT EXISTS `mail_global_setup` (
  `mail_setup_id` int(10) NOT NULL DEFAULT '0',
  `cde_id` int(10) NOT NULL DEFAULT '0',
  `group_id` int(10) NOT NULL DEFAULT '0',
  `table_id` int(10) NOT NULL DEFAULT '0',
  `alert_type_id` int(10) NOT NULL DEFAULT '0',
  `alert_range_id` int(10) NOT NULL DEFAULT '0',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`mail_setup_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.mail_service_master
CREATE TABLE IF NOT EXISTS `mail_service_master` (
  `service_id` int(10) NOT NULL DEFAULT '0',
  `service_type` int(10) NOT NULL DEFAULT '0',
  `mail_description` text NOT NULL,
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`service_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Mail Services Master for All types of Mails';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.mandatory_group_master
CREATE TABLE IF NOT EXISTS `mandatory_group_master` (
  `mandatory_group_id` int(3) NOT NULL DEFAULT '0',
  `group_name` varchar(30) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`mandatory_group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='mandatory group master is a master table for mandatory_info';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.mandatory_icon_master
CREATE TABLE IF NOT EXISTS `mandatory_icon_master` (
  `mandatory_icon_id` int(3) NOT NULL,
  `icon_desc` varchar(600) DEFAULT NULL,
  `mandatory_type_id` int(2) DEFAULT NULL,
  PRIMARY KEY (`mandatory_icon_id`),
  KEY `FK_mandatory_type_id` (`mandatory_type_id`),
  CONSTRAINT `FK_mandatory_type_id` FOREIGN KEY (`mandatory_type_id`) REFERENCES `mandatory_type_master` (`mandatory_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.mandatory_info
CREATE TABLE IF NOT EXISTS `mandatory_info` (
  `mandatory_id` int(11) NOT NULL AUTO_INCREMENT,
  `mandatory_group_id` int(11) DEFAULT NULL,
  `description` text,
  `table_name` varchar(150) DEFAULT NULL,
  `field_name` varchar(150) DEFAULT NULL,
  `nmtc_required` char(3) DEFAULT NULL,
  `cdfi_required` char(3) DEFAULT NULL,
  `mandatory` char(3) DEFAULT NULL,
  `error_message` text,
  `status` char(3) DEFAULT NULL,
  `order_id` int(11) DEFAULT NULL,
  `ciis_desc` text,
  `customized_report_title_map_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`mandatory_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.mandatory_type_master
CREATE TABLE IF NOT EXISTS `mandatory_type_master` (
  `mandatory_type_id` int(2) NOT NULL,
  `mandatory_type_desc` varchar(250) DEFAULT NULL,
  `mandatory_type_status` char(1) DEFAULT NULL,
  PRIMARY KEY (`mandatory_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.manpower_master
CREATE TABLE IF NOT EXISTS `manpower_master` (
  `manpower_id` int(3) NOT NULL DEFAULT '0',
  `manpower_desc` varchar(50) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`manpower_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.member_cde
CREATE TABLE IF NOT EXISTS `member_cde` (
  `member_cde_id` int(8) NOT NULL DEFAULT '0',
  `member_id` int(8) NOT NULL DEFAULT '0',
  `cde_id` int(5) NOT NULL DEFAULT '0',
  `sub_cde_id` int(5) NOT NULL DEFAULT '0',
  `join_date` varchar(100) NOT NULL,
  `leave_date` varchar(100) DEFAULT NULL,
  `status` char(1) NOT NULL DEFAULT '',
  `investor_master_id` int(8) DEFAULT '0',
  PRIMARY KEY (`member_cde_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Board Member relation with a particular CDE';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.member_cde_history
CREATE TABLE IF NOT EXISTS `member_cde_history` (
  `member_cde_history_id` int(8) NOT NULL DEFAULT '0',
  `member_id` int(8) NOT NULL DEFAULT '0',
  `cde_id` int(5) NOT NULL DEFAULT '0',
  `sub_cde_id` int(5) NOT NULL DEFAULT '0',
  `join_date` varchar(100) NOT NULL,
  `leave_date` varchar(100) DEFAULT NULL,
  `status` char(1) NOT NULL DEFAULT '',
  `investor_master_id` int(8) DEFAULT '0',
  PRIMARY KEY (`member_cde_history_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Board Member relation with a particular CDE';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.member_type_master
CREATE TABLE IF NOT EXISTS `member_type_master` (
  `member_type_id` int(3) NOT NULL DEFAULT '0',
  `member_type_desc` varchar(50) NOT NULL DEFAULT '',
  `link` varchar(70) DEFAULT NULL,
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`member_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Board Member Type Master';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.menus_master
CREATE TABLE IF NOT EXISTS `menus_master` (
  `menu_id` int(3) NOT NULL AUTO_INCREMENT,
  `menu_name` varchar(50) NOT NULL DEFAULT '',
  `link` varchar(150) DEFAULT NULL,
  `menu_type` varchar(10) NOT NULL DEFAULT '',
  `group_head` int(3) DEFAULT NULL,
  `sub_group_head` int(3) DEFAULT NULL,
  `priority_id` int(4) NOT NULL DEFAULT '0',
  `width` int(3) NOT NULL DEFAULT '0',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`menu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.menu_master
CREATE TABLE IF NOT EXISTS `menu_master` (
  `menu_id` int(3) NOT NULL DEFAULT '0',
  `menu_name` varchar(50) NOT NULL DEFAULT '',
  `link` varchar(150) DEFAULT NULL,
  `menu_type` varchar(10) NOT NULL DEFAULT '',
  `group_head` int(3) DEFAULT NULL,
  `sub_group_head` int(3) DEFAULT NULL,
  `priority_id` int(4) NOT NULL DEFAULT '0',
  `width` int(3) NOT NULL DEFAULT '0',
  `status` char(1) NOT NULL DEFAULT 'Y'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.month_master
CREATE TABLE IF NOT EXISTS `month_master` (
  `month_id` int(11) NOT NULL,
  `month_name` varchar(100) NOT NULL,
  `status` char(1) NOT NULL,
  PRIMARY KEY (`month_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.naics_master
CREATE TABLE IF NOT EXISTS `naics_master` (
  `naics_id` int(11) NOT NULL DEFAULT '0',
  `naics_code` varchar(10) NOT NULL DEFAULT '0',
  `naic_desc` text NOT NULL,
  `main_grp_id` int(8) NOT NULL DEFAULT '0',
  `sub_grp_id` int(8) NOT NULL DEFAULT '0',
  `status` char(1) DEFAULT 'Y',
  PRIMARY KEY (`naics_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Naics Code Information';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.naics_old_master
CREATE TABLE IF NOT EXISTS `naics_old_master` (
  `naics_id` int(11) NOT NULL DEFAULT '0',
  `naics_code` varchar(10) NOT NULL DEFAULT '0',
  `naic_desc` text NOT NULL,
  `main_grp_id` int(8) NOT NULL DEFAULT '0',
  `sub_grp_id` int(8) NOT NULL DEFAULT '0',
  `status` char(1) DEFAULT 'Y',
  PRIMARY KEY (`naics_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Naics Code Information';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.network_access_master
CREATE TABLE IF NOT EXISTS `network_access_master` (
  `network_access_master_id` int(11) NOT NULL AUTO_INCREMENT,
  `network_name` varchar(50) NOT NULL,
  `ip_address` varchar(50) NOT NULL,
  `subnet_address` varchar(50) NOT NULL,
  `personal_id` int(11) NOT NULL,
  `status` varchar(50) NOT NULL,
  PRIMARY KEY (`network_access_master_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.nmtc_criteria_master
CREATE TABLE IF NOT EXISTS `nmtc_criteria_master` (
  `nmtc_criteria_id` int(3) NOT NULL DEFAULT '0',
  `nmtc_criteria_desc` varchar(30) NOT NULL DEFAULT '',
  `cdfi_code` varchar(10) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`nmtc_criteria_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='NMTC Eligibilty Criteria';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.nmtc_eligible_master
CREATE TABLE IF NOT EXISTS `nmtc_eligible_master` (
  `nmtc_eligible_id` int(3) NOT NULL DEFAULT '0',
  `nmtc_eligible_desc` varchar(50) NOT NULL DEFAULT '',
  `cdfi_code` varchar(25) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`nmtc_eligible_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='NMTC Eligibilty Criteria';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.non_qei_info
CREATE TABLE IF NOT EXISTS `non_qei_info` (
  `non_qei_id` int(8) NOT NULL DEFAULT '0',
  `non_qei_name` varchar(100) NOT NULL DEFAULT '',
  `type` int(8) NOT NULL DEFAULT '0',
  `remarks` varchar(200) DEFAULT NULL,
  `cde_id` int(8) NOT NULL DEFAULT '0',
  `investee_id` int(8) DEFAULT '0',
  `status` char(3) NOT NULL DEFAULT '',
  PRIMARY KEY (`non_qei_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.notification_details
CREATE TABLE IF NOT EXISTS `notification_details` (
  `notification_details_id` int(10) NOT NULL AUTO_INCREMENT,
  `duedate_id` int(10) NOT NULL,
  `notification_id` varchar(10) DEFAULT '2',
  `status` varchar(3) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`notification_details_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.notification_master
CREATE TABLE IF NOT EXISTS `notification_master` (
  `Notification_master_id` int(10) NOT NULL,
  `Notification_desc` varchar(250) CHARACTER SET latin1 NOT NULL,
  `Status` char(2) NOT NULL,
  PRIMARY KEY (`Notification_master_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.occurence_day_master
CREATE TABLE IF NOT EXISTS `occurence_day_master` (
  `occurence_day_id` int(11) NOT NULL,
  `occurence_day_desc` varchar(255) NOT NULL,
  `occurence_day_desc_display` varchar(15) NOT NULL,
  `status` char(1) NOT NULL,
  PRIMARY KEY (`occurence_day_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.occurence_others_duedates_master
CREATE TABLE IF NOT EXISTS `occurence_others_duedates_master` (
  `occurence_others_duedates_master_id` int(11) NOT NULL,
  `status` char(1) NOT NULL,
  PRIMARY KEY (`occurence_others_duedates_master_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.occurence_pattern_master
CREATE TABLE IF NOT EXISTS `occurence_pattern_master` (
  `occurence_pattern_id` int(11) NOT NULL,
  `occurence_pattern_name` varchar(255) NOT NULL,
  `status` char(1) NOT NULL,
  PRIMARY KEY (`occurence_pattern_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.occurence_type_master
CREATE TABLE IF NOT EXISTS `occurence_type_master` (
  `occurence_type_id` varchar(255) NOT NULL,
  `occurence_name` varchar(255) NOT NULL,
  `occurence_display_name` varchar(15) NOT NULL,
  `occurence_name_display` varchar(255) NOT NULL,
  `occurence_display_status` varchar(15) NOT NULL,
  `status` char(1) NOT NULL,
  PRIMARY KEY (`occurence_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.occurence_week_master
CREATE TABLE IF NOT EXISTS `occurence_week_master` (
  `occurence_week_id` int(11) NOT NULL,
  `occurence_week_desc` varchar(255) NOT NULL,
  `occurence_week_desc_display` varchar(15) NOT NULL,
  `status` char(1) NOT NULL,
  PRIMARY KEY (`occurence_week_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.org_master
CREATE TABLE IF NOT EXISTS `org_master` (
  `org_id` int(3) NOT NULL DEFAULT '0',
  `org_structure` varchar(50) NOT NULL DEFAULT '',
  `cdfi_code` varchar(10) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`org_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Legal structure of CDE organization';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.org_type_master
CREATE TABLE IF NOT EXISTS `org_type_master` (
  `org_type_id` varchar(5) NOT NULL DEFAULT '',
  `org_type_desc` varchar(50) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`org_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='CDE Organization Type';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.origination_master
CREATE TABLE IF NOT EXISTS `origination_master` (
  `org_master_id` int(4) NOT NULL DEFAULT '0',
  `org_name` varchar(100) DEFAULT NULL,
  `cdfi_code` varchar(50) DEFAULT NULL,
  `status` char(2) DEFAULT NULL,
  PRIMARY KEY (`org_master_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.other_sources_master
CREATE TABLE IF NOT EXISTS `other_sources_master` (
  `other_sources_id` int(8) NOT NULL DEFAULT '0',
  `other_sources_desc` varchar(60) NOT NULL DEFAULT '',
  `cdfi_code` varchar(20) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`other_sources_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Project Fund Requirements from Other Sources Master';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.ownership_per
CREATE TABLE IF NOT EXISTS `ownership_per` (
  `group_id` int(8) NOT NULL DEFAULT '0',
  `investor_id` int(8) NOT NULL DEFAULT '0',
  `amend_id` int(8) NOT NULL DEFAULT '0',
  `effective_date` date NOT NULL DEFAULT '0000-00-00',
  `owner_per` double(5,2) NOT NULL DEFAULT '0.00',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`group_id`,`investor_id`,`amend_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.personal_info
CREATE TABLE IF NOT EXISTS `personal_info` (
  `personal_id` int(8) NOT NULL DEFAULT '0',
  `group_id` int(3) NOT NULL DEFAULT '0',
  `organization` varchar(100) DEFAULT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `middle_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `sex` char(1) DEFAULT '',
  `address1` varchar(100) DEFAULT '',
  `address2` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT '',
  `state_id` char(2) DEFAULT NULL,
  `zip` varchar(10) DEFAULT '',
  `country` varchar(30) DEFAULT NULL,
  `website` varchar(150) DEFAULT NULL,
  `cims_code` varchar(100) DEFAULT NULL,
  `phone` varchar(20) NOT NULL DEFAULT '',
  `alt_phone` varchar(20) NOT NULL DEFAULT '',
  `fax` varchar(15) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `county_code` varchar(5) DEFAULT NULL,
  `census_tractno` text,
  `taxpayer` varchar(50) NOT NULL DEFAULT '',
  `taxpayer_id` varchar(10) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  `contact_personal_id` int(8) DEFAULT '0',
  `address_id` int(8) DEFAULT '0',
  `comments` text NOT NULL,
  PRIMARY KEY (`personal_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Personal Information Table';

-- Data exporting was unselected.


-- Dumping structure for procedure cdesolution.procedureName
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `procedureName`( )
BEGIN
select * from login_info ;         
END//
DELIMITER ;


-- Dumping structure for procedure cdesolution.procedureNameSample
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `procedureNameSample`( )
BEGIN
select * from login_info ;         
END//
DELIMITER ;


-- Dumping structure for procedure cdesolution.procedureNameSample1
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `procedureNameSample1`( )
BEGIN
select * from login_info ;         
END//
DELIMITER ;


-- Dumping structure for table cdesolution.project_annual_template
CREATE TABLE IF NOT EXISTS `project_annual_template` (
  `proj_template_id` int(8) NOT NULL DEFAULT '0',
  `project_id` int(8) NOT NULL DEFAULT '0',
  `qalicb_id` int(8) NOT NULL DEFAULT '0',
  `cde_id` int(8) NOT NULL DEFAULT '0',
  `annual_year` int(4) NOT NULL DEFAULT '0',
  `gross_revenue` double(20,2) DEFAULT '-1.00',
  `jobs_at_reporting` double(20,2) DEFAULT '-1.00',
  `dsfcos_reporting` double(20,2) DEFAULT '-1.00',
  `other_impact1_desc` varchar(150) DEFAULT NULL,
  `other_impact1_num` double(15,2) DEFAULT '-1.00',
  `other_impact2_desc` varchar(150) DEFAULT NULL,
  `other_impact2_num` double(15,2) DEFAULT '-1.00',
  `effective_date` varchar(10) DEFAULT NULL,
  `prepared_user` varchar(150) DEFAULT NULL,
  `status` char(1) DEFAULT 'Y',
  `at_status` text,
  `blended_rate` double(20,3) DEFAULT '-1.000',
  `comp_interest_rate` double(20,3) DEFAULT '-1.000',
  PRIMARY KEY (`proj_template_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.project_criteria
CREATE TABLE IF NOT EXISTS `project_criteria` (
  `proj_criteria_id` int(8) NOT NULL DEFAULT '0',
  `qalicb_id` int(8) NOT NULL DEFAULT '0',
  `project_id` int(8) NOT NULL DEFAULT '0',
  `loan_val_ratio` double(20,3) NOT NULL DEFAULT '-1.000',
  `debt_cov_ratio` double(20,3) NOT NULL DEFAULT '-1.000',
  `loan_reserve_req` double(6,2) NOT NULL DEFAULT '-1.00',
  `rate_terms` text NOT NULL,
  `blended_rate` double(20,3) DEFAULT '-1.000',
  `comp_interest_rate` double(20,3) NOT NULL DEFAULT '-1.000',
  `proj_org_fees` double(15,2) NOT NULL DEFAULT '-1.00',
  `std_value_ratio` double(20,3) NOT NULL DEFAULT '-1.000',
  `std_debt_ratio` double(20,3) NOT NULL DEFAULT '-1.000',
  `std_loan_req` int(8) NOT NULL DEFAULT '-1',
  `com_facility_opt` char(1) DEFAULT NULL,
  `cap_education_fty` double(20,2) NOT NULL DEFAULT '-1.00',
  `cap_childcare_fty` double(20,2) NOT NULL DEFAULT '-1.00',
  `cap_health_fty` double(20,2) NOT NULL DEFAULT '-1.00',
  `cap_arts_fty` double(20,2) NOT NULL DEFAULT '-1.00',
  `cap_other_fty` double(20,2) NOT NULL DEFAULT '-1.00',
  `cap_opt_status` text NOT NULL,
  `type` int(8) NOT NULL DEFAULT '0',
  `status` char(1) NOT NULL DEFAULT 'Y',
  `gross_loan` double(20,2) NOT NULL DEFAULT '-1.00',
  `dsfs_loan` double(20,2) NOT NULL DEFAULT '-1.00',
  `jobs_loan` double(20,2) NOT NULL DEFAULT '-1.00',
  `blended_rate_comp` int(8) DEFAULT '0',
  `blended_rate_other` text,
  `std_org_fee_comp` int(8) DEFAULT '0',
  `std_org_fee_other` text,
  `std_loan_ratio_comp` int(8) DEFAULT '0',
  `std_loan_ratio_other` text,
  `std_debt_comp` int(8) DEFAULT '0',
  `std_debt_other` text,
  `std_loan_loss_comp` int(8) DEFAULT '0',
  `std_loan_loss_other` text,
  `cap_education_fty_opt` char(2) NOT NULL DEFAULT 'N',
  `cap_childcare_fty_opt` char(2) NOT NULL DEFAULT 'N',
  `cap_health_fty_opt` char(2) NOT NULL DEFAULT 'N',
  `cap_arts_fty_opt` char(2) NOT NULL DEFAULT 'N',
  `cap_other_fty_opt` char(2) NOT NULL DEFAULT 'N',
  `jobs_loan_opt` char(2) NOT NULL DEFAULT 'N',
  `below_market_rate_opt` char(2) NOT NULL DEFAULT 'E',
  `below_market_rate_agreement_opt` char(2) NOT NULL DEFAULT 'E',
  `low_std_org_fee_opt` char(2) NOT NULL DEFAULT 'E',
  `high_loan_val_ratio_opt` char(2) NOT NULL DEFAULT 'E',
  `flex_borrower_credit_opt` char(2) NOT NULL DEFAULT 'E',
  `low_std_debt_ratio_opt` char(2) NOT NULL DEFAULT 'E',
  `low_std_loan_loss_req_opt` char(2) NOT NULL DEFAULT 'E',
  `loanloss_id` int(8) NOT NULL DEFAULT '-1',
  `loanloss_other` text NOT NULL,
  `loanloss_reserves` double(20,2) NOT NULL DEFAULT '-1.00',
  PRIMARY KEY (`proj_criteria_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.project_equity_master
CREATE TABLE IF NOT EXISTS `project_equity_master` (
  `project_equity_id` int(8) NOT NULL DEFAULT '0',
  `trans_id` varchar(15) NOT NULL DEFAULT '',
  `project_id` int(8) NOT NULL DEFAULT '0',
  `qalicb_id` int(8) NOT NULL DEFAULT '0',
  `ammend_id` int(3) NOT NULL DEFAULT '0',
  `ds_fcos` double(8,2) NOT NULL DEFAULT '0.00',
  `full_time_equivalent` double(8,2) NOT NULL DEFAULT '0.00',
  `gross_revenue` double(20,2) NOT NULL DEFAULT '0.00',
  `rate_of_return` double(5,2) NOT NULL DEFAULT '-1.00',
  `other_terms` varchar(50) NOT NULL DEFAULT '',
  `equity_likely_features_id` int(8) NOT NULL DEFAULT '0',
  `effective_date` varchar(10) NOT NULL DEFAULT '0000-00-00',
  `system_date` varchar(10) NOT NULL DEFAULT '0000-00-00',
  `actual_projected` char(1) NOT NULL DEFAULT '',
  `hda` text NOT NULL,
  `status` char(1) NOT NULL DEFAULT '',
  `amount` double(20,2) NOT NULL DEFAULT '-1.00',
  `hda_other` text,
  `rate_terms` text NOT NULL,
  `loan_fee` double(20,2) NOT NULL DEFAULT '-1.00',
  `equity_desc` longtext,
  `refinancing_type` int(3) NOT NULL DEFAULT '0',
  `advance_purchase_commitment` char(1) NOT NULL DEFAULT 'N',
  `seller_organization` varchar(100) DEFAULT NULL,
  `const_per_financing_type` int(3) NOT NULL DEFAULT '0',
  `take_acquisition_financing_type` int(3) NOT NULL DEFAULT '0',
  `acq_financing_rehab_type` int(3) NOT NULL DEFAULT '0',
  `rehabilitation_amount` double(20,2) NOT NULL DEFAULT '-1.00',
  `comp_int_rate` double(6,3) DEFAULT '-1.000',
  `std_orgination_fee` double(15,2) DEFAULT '-1.00',
  `std_peri_int_only_pay` int(8) DEFAULT '-1',
  `std_amort_period` int(8) DEFAULT '-1',
  `tradi_form_collateral` char(1) DEFAULT NULL,
  `purpose` int(3) NOT NULL DEFAULT '0',
  `projected_grant` int(8) NOT NULL DEFAULT '-1',
  `seq_id` int(8) NOT NULL DEFAULT '0',
  `use_std_org_fee` int(8) NOT NULL DEFAULT '-1',
  `projectedqei_id` varchar(20) DEFAULT '',
  `projected_grant_opt` varchar(2) DEFAULT 'N',
  `restruct_trans_id` varchar(20) NOT NULL,
  `equity_injection_amount` double(20,2) NOT NULL DEFAULT '-1.00',
  `non_real_amount` double(20,2) DEFAULT '-1.00',
  PRIMARY KEY (`project_equity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Maintaining equity info on projects';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.project_fs_master
CREATE TABLE IF NOT EXISTS `project_fs_master` (
  `project_fs_id` int(8) NOT NULL DEFAULT '0',
  `trans_id` varchar(15) NOT NULL DEFAULT '',
  `project_id` int(8) NOT NULL DEFAULT '0',
  `qalicb_id` int(8) NOT NULL DEFAULT '0',
  `ammend_id` int(3) NOT NULL DEFAULT '0',
  `ds_fcos` double(8,2) NOT NULL DEFAULT '0.00',
  `full_time_equivalent` double(8,2) NOT NULL DEFAULT '0.00',
  `gross_revenue` double(20,2) NOT NULL DEFAULT '0.00',
  `rate_of_return` double(5,2) NOT NULL DEFAULT '0.00',
  `other_terms` varchar(50) NOT NULL DEFAULT '',
  `effective_date` date NOT NULL DEFAULT '0000-00-00',
  `system_date` date NOT NULL DEFAULT '0000-00-00',
  `actual_projected` char(1) NOT NULL DEFAULT 'P',
  `hda` text NOT NULL,
  `status` char(1) NOT NULL DEFAULT '',
  `amount` double(20,2) NOT NULL DEFAULT '0.00',
  `hda_other` text,
  `fs_desc` longtext,
  `purpose` int(3) DEFAULT NULL,
  `refinancing_type` int(3) DEFAULT '0',
  `rate_terms` text,
  `comp_int_rate` double(6,3) DEFAULT '-1.000',
  `std_orgination_fee` int(8) DEFAULT '-1',
  `std_peri_int_only_pay` int(8) DEFAULT '-1',
  `std_amort_period` int(8) DEFAULT '-1',
  `tradi_form_collateral` char(1) DEFAULT NULL,
  `projected_grant` int(8) NOT NULL DEFAULT '-1',
  `seq_id` int(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`project_fs_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Maintaining financial services info on projects';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.project_fund_master
CREATE TABLE IF NOT EXISTS `project_fund_master` (
  `pf_id` int(8) NOT NULL DEFAULT '0',
  `cash_details_id` int(8) NOT NULL DEFAULT '0',
  `cde_id` int(8) NOT NULL DEFAULT '0',
  `alloc_year` varchar(4) DEFAULT NULL,
  `investor_id` int(8) NOT NULL DEFAULT '0',
  `type` varchar(5) NOT NULL DEFAULT '',
  `total_amt` double(20,2) NOT NULL DEFAULT '0.00',
  `project_fund` double(20,2) NOT NULL DEFAULT '0.00',
  `op_fund` double(20,2) DEFAULT NULL,
  `lr_fund` double(20,2) DEFAULT NULL,
  `pf_percent` double(5,2) NOT NULL DEFAULT '0.00',
  `op_percent` double(5,2) DEFAULT NULL,
  `lr_percent` double(5,2) DEFAULT NULL,
  `pf_date` varchar(50) NOT NULL DEFAULT '0000-00-00',
  `system_date` varchar(50) NOT NULL DEFAULT '0000-00-00',
  `pf_bal_fund` double(20,2) NOT NULL DEFAULT '0.00',
  `op_bal_fund` double(20,2) DEFAULT '0.00',
  `qei_id` varchar(15) DEFAULT NULL,
  `disburse_cash_id` int(8) DEFAULT '0',
  `non_qei_id` int(8) DEFAULT '0',
  `status` char(2) NOT NULL DEFAULT '',
  `fcos_fund` double(20,2) DEFAULT '0.00',
  `fcos_percent` double(20,2) DEFAULT '0.00',
  `src_type` varchar(6) DEFAULT NULL,
  `inv_pf_id` int(8) NOT NULL DEFAULT '0',
  `inv_pf_date` varchar(50) DEFAULT '0000-00-00',
  `pf_due_date` varchar(10) DEFAULT '0000-00-00',
  `lr_bal_fund` double(20,2) DEFAULT '0.00',
  PRIMARY KEY (`pf_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.project_fund_req
CREATE TABLE IF NOT EXISTS `project_fund_req` (
  `fund_id` int(4) NOT NULL DEFAULT '0',
  `project_id` int(8) NOT NULL DEFAULT '0',
  `qlici_type` int(4) NOT NULL DEFAULT '0',
  `trans_type` varchar(15) NOT NULL DEFAULT '',
  `system_date` date NOT NULL DEFAULT '0000-00-00',
  `date_required` date NOT NULL DEFAULT '0000-00-00',
  `amount_required` double(20,2) NOT NULL DEFAULT '0.00',
  `balance_allocation` double(20,2) NOT NULL DEFAULT '0.00',
  `status` char(2) NOT NULL DEFAULT 'N',
  `type` varchar(10) NOT NULL,
  `unschedule_fund_req` double(20,2) NOT NULL DEFAULT '0.00',
  `loc_fund_req` double(20,2) NOT NULL DEFAULT '0.00',
  `default_status` varchar(2) NOT NULL DEFAULT 'N',
  PRIMARY KEY (`fund_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Project Fund Requirements as split up.';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.project_hda_master
CREATE TABLE IF NOT EXISTS `project_hda_master` (
  `project_hda_id` int(10) NOT NULL,
  `qalicb_id` int(10) NOT NULL DEFAULT '0',
  `project_id` int(10) NOT NULL,
  `investee_id` int(10) NOT NULL,
  `poverty_30` char(3) NOT NULL DEFAULT 'E',
  `poverty_30_desc` varchar(200) DEFAULT NULL,
  `median_60` char(3) NOT NULL DEFAULT 'E',
  `median_60_desc` varchar(200) DEFAULT NULL,
  `unemployment_15` char(3) NOT NULL DEFAULT 'E',
  `unemployment_15_desc` varchar(200) DEFAULT NULL,
  `design_govt` char(3) NOT NULL DEFAULT 'E',
  `design_govt_desc` varchar(200) DEFAULT NULL,
  `design_zone` char(3) NOT NULL DEFAULT 'E',
  `design_zone_desc` varchar(200) DEFAULT NULL,
  `design_hub` char(3) NOT NULL DEFAULT 'E',
  `design_hub_desc` varchar(200) DEFAULT NULL,
  `design_native` char(3) NOT NULL DEFAULT 'E',
  `design_native_desc` varchar(200) DEFAULT NULL,
  `brown_fields` char(3) NOT NULL DEFAULT 'E',
  `brown_fields_desc` varchar(200) DEFAULT NULL,
  `encompass_plan` char(3) NOT NULL DEFAULT 'E',
  `encompass_plan_desc` varchar(200) DEFAULT NULL,
  `others` char(3) NOT NULL DEFAULT 'E',
  `others_desc` text,
  `hot_zone` char(3) NOT NULL DEFAULT 'E',
  `hot_zone_desc` varchar(200) DEFAULT NULL,
  `appal_regional` char(3) NOT NULL DEFAULT 'E',
  `appal_regional_desc` varchar(200) DEFAULT NULL,
  `Colonias` char(3) NOT NULL DEFAULT 'E',
  `Colonias_desc` varchar(200) DEFAULT NULL,
  `medical_area` char(3) NOT NULL DEFAULT 'E',
  `medical_area_desc` varchar(200) DEFAULT NULL,
  `tif_zone` char(3) NOT NULL DEFAULT 'E',
  `tif_zone_desc` varchar(200) DEFAULT NULL,
  `poverty_25` char(3) NOT NULL DEFAULT 'E',
  `poverty_25_desc` varchar(200) DEFAULT NULL,
  `median_70` char(3) NOT NULL DEFAULT 'E',
  `median_70_desc` varchar(200) DEFAULT NULL,
  `unemployment_125` char(3) NOT NULL DEFAULT 'E',
  `unemployment_125_desc` varchar(200) DEFAULT NULL,
  `migration_rural` char(3) NOT NULL DEFAULT 'E',
  `migration_rural_desc` varchar(200) DEFAULT NULL,
  `nonmetro_tract` char(3) NOT NULL DEFAULT 'E',
  `nonmetro_tract_desc` varchar(200) DEFAULT NULL,
  `federal_agency` char(3) NOT NULL DEFAULT 'E',
  `federal_agency_desc` varchar(200) DEFAULT NULL,
  `trade_adjust` char(3) NOT NULL DEFAULT 'E',
  `trade_adjust_desc` varchar(200) DEFAULT NULL,
  `system_date` varchar(20) NOT NULL DEFAULT '0000-00-00 00:00:00',
  `status` char(1) NOT NULL DEFAULT 'Y',
  `lip_60` char(3) NOT NULL DEFAULT 'E',
  `lip_60_desc` varchar(200) DEFAULT NULL,
  `etp_60` char(3) NOT NULL DEFAULT 'E',
  `etp_60_desc` varchar(200) DEFAULT NULL,
  `food_desert` char(3) NOT NULL DEFAULT 'E',
  `food_desert_desc` varchar(200) DEFAULT NULL,
  `target_pop` char(3) NOT NULL DEFAULT 'E',
  `target_pop_desc` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`project_hda_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.project_loan_history
CREATE TABLE IF NOT EXISTS `project_loan_history` (
  `project_loan_id` int(8) NOT NULL DEFAULT '0',
  `trans_id` varchar(15) NOT NULL DEFAULT '',
  `project_id` int(8) NOT NULL DEFAULT '0',
  `qalicb_id` int(8) NOT NULL DEFAULT '0',
  `ammend_id` int(3) NOT NULL DEFAULT '0',
  `ds_fcos` double(8,2) NOT NULL DEFAULT '0.00',
  `full_time_equivalent` double(8,2) NOT NULL DEFAULT '0.00',
  `gross_revenue` double(20,2) NOT NULL DEFAULT '0.00',
  `loan_type` int(3) NOT NULL DEFAULT '0',
  `amortization_type` int(3) NOT NULL DEFAULT '0',
  `amortization_period` int(4) NOT NULL DEFAULT '-1',
  `collateral_type` int(3) NOT NULL DEFAULT '0',
  `collateral_value` double(20,2) NOT NULL DEFAULT '-1.00',
  `guarantee` int(3) NOT NULL DEFAULT '0',
  `loan_term` int(4) NOT NULL DEFAULT '-1',
  `interest_rate` double(6,3) DEFAULT '-1.000',
  `interest_type` int(3) NOT NULL DEFAULT '0',
  `principal_payment_frequency` varchar(10) NOT NULL DEFAULT '0000-00-00',
  `repayment_type` int(4) NOT NULL DEFAULT '0',
  `interest_payment_frequency` int(3) NOT NULL DEFAULT '0',
  `is_refinanced` int(3) NOT NULL DEFAULT '1',
  `transaction_id` varchar(10) NOT NULL DEFAULT '',
  `forgivable_loan_status` char(3) NOT NULL DEFAULT '',
  `forgivable_loan_amount` double(20,2) DEFAULT '0.00',
  `forgivable_loan_date` varchar(10) NOT NULL DEFAULT '0000-00-00',
  `loan_fee` double(20,2) NOT NULL DEFAULT '-1.00',
  `other_fee` double(20,2) NOT NULL DEFAULT '0.00',
  `kicker` int(3) NOT NULL DEFAULT '0',
  `points_changed` double(9,6) NOT NULL DEFAULT '-1.000000',
  `lien_position` int(3) NOT NULL DEFAULT '0',
  `loan_status` int(3) NOT NULL DEFAULT '0',
  `hda` text NOT NULL,
  `rate_terms` text NOT NULL,
  `nmtc_eligibility_criteria` int(3) NOT NULL DEFAULT '0',
  `fips_1990` varchar(11) NOT NULL DEFAULT '',
  `effective_date` date NOT NULL DEFAULT '0000-00-00',
  `system_date` date NOT NULL DEFAULT '0000-00-00',
  `actual_projected` char(1) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  `amount` double(20,2) NOT NULL DEFAULT '0.00',
  `other_source` double(20,2) NOT NULL DEFAULT '0.00',
  `hda_other` text,
  `equity_injection_amount` double(20,2) NOT NULL DEFAULT '0.00',
  `refinancing_type` int(3) NOT NULL DEFAULT '0',
  `advance_purchase_commitment` char(1) NOT NULL DEFAULT 'Y',
  `seller_organization` varchar(50) NOT NULL DEFAULT '',
  `const_per_financing_type` int(3) NOT NULL DEFAULT '0',
  `take_acquisition_financing_type` int(3) NOT NULL DEFAULT '0',
  `acq_financing_rehab_type` int(3) NOT NULL DEFAULT '0',
  `rehabilitation_amount` double(20,2) NOT NULL DEFAULT '0.00',
  `loan_desc` longtext,
  `period_inte_only_pay` int(8) DEFAULT '-1',
  `comp_int_rate` double(6,3) DEFAULT '-1.000',
  `std_orgination_fee` double(15,2) DEFAULT '-1.00',
  `std_peri_int_only_pay` int(8) DEFAULT '-1',
  `std_amort_period` int(8) DEFAULT '-1',
  `tradi_form_collateral` char(1) DEFAULT NULL,
  `purpose` int(3) NOT NULL DEFAULT '0',
  `projected_grant` int(8) NOT NULL DEFAULT '-1',
  `use_std_org_fee` int(8) NOT NULL DEFAULT '0',
  `seq_id` int(8) NOT NULL DEFAULT '0',
  `projectedqei_id` varchar(20) DEFAULT '',
  `interest_rate_desc` text NOT NULL,
  `interest_type_desc` text NOT NULL,
  `investor_exception` text,
  `risk_rating` text NOT NULL,
  `maturity_date` varchar(10) DEFAULT '0000-00-00',
  `billing_date` varchar(10) DEFAULT '00',
  `restruct_trans_id` varchar(20) NOT NULL,
  `amort_period_length` int(8) DEFAULT '-1',
  PRIMARY KEY (`project_loan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.project_loan_master
CREATE TABLE IF NOT EXISTS `project_loan_master` (
  `project_loan_id` int(8) NOT NULL DEFAULT '0',
  `trans_id` varchar(15) NOT NULL DEFAULT '',
  `project_id` int(8) NOT NULL DEFAULT '0',
  `qalicb_id` int(8) NOT NULL DEFAULT '0',
  `ammend_id` int(3) NOT NULL DEFAULT '0',
  `ds_fcos` double(8,2) NOT NULL DEFAULT '0.00',
  `full_time_equivalent` double(8,2) NOT NULL DEFAULT '0.00',
  `gross_revenue` double(20,2) NOT NULL DEFAULT '0.00',
  `loan_type` int(3) NOT NULL DEFAULT '0',
  `amortization_type` int(3) NOT NULL DEFAULT '0',
  `amortization_period` int(4) NOT NULL DEFAULT '-1',
  `collateral_type` int(3) NOT NULL DEFAULT '0',
  `collateral_value` double(20,2) NOT NULL DEFAULT '-1.00',
  `guarantee` int(3) NOT NULL DEFAULT '0',
  `loan_term` int(4) NOT NULL DEFAULT '-1',
  `interest_rate` double(6,3) DEFAULT '-1.000',
  `interest_type` int(3) NOT NULL DEFAULT '0',
  `principal_payment_frequency` varchar(10) NOT NULL DEFAULT '0000-00-00',
  `repayment_type` int(4) NOT NULL DEFAULT '0',
  `interest_payment_frequency` int(3) NOT NULL DEFAULT '0',
  `is_refinanced` int(3) NOT NULL DEFAULT '1',
  `transaction_id` varchar(10) NOT NULL DEFAULT '',
  `forgivable_loan_status` char(3) NOT NULL DEFAULT '',
  `forgivable_loan_amount` double(20,2) DEFAULT '0.00',
  `forgivable_loan_date` varchar(10) NOT NULL DEFAULT '0000-00-00',
  `loan_fee` double(20,2) NOT NULL DEFAULT '-1.00',
  `other_fee` double(20,2) NOT NULL DEFAULT '0.00',
  `kicker` int(3) NOT NULL DEFAULT '0',
  `points_changed` double(9,6) NOT NULL DEFAULT '-1.000000',
  `lien_position` int(3) NOT NULL DEFAULT '0',
  `loan_status` int(3) NOT NULL DEFAULT '0',
  `hda` text NOT NULL,
  `rate_terms` text NOT NULL,
  `nmtc_eligibility_criteria` int(3) NOT NULL DEFAULT '0',
  `fips_1990` varchar(11) NOT NULL DEFAULT '',
  `effective_date` varchar(10) NOT NULL DEFAULT '0000-00-00',
  `system_date` varchar(10) NOT NULL DEFAULT '0000-00-00',
  `actual_projected` char(1) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  `amount` double(20,2) NOT NULL DEFAULT '-1.00',
  `other_source` double(20,2) NOT NULL DEFAULT '0.00',
  `hda_other` text,
  `equity_injection_amount` double(20,2) NOT NULL DEFAULT '-1.00',
  `refinancing_type` int(3) NOT NULL DEFAULT '0',
  `advance_purchase_commitment` char(1) NOT NULL DEFAULT 'Y',
  `seller_organization` varchar(50) NOT NULL DEFAULT '',
  `const_per_financing_type` int(3) NOT NULL DEFAULT '0',
  `take_acquisition_financing_type` int(3) NOT NULL DEFAULT '0',
  `acq_financing_rehab_type` int(3) NOT NULL DEFAULT '0',
  `rehabilitation_amount` double(20,2) NOT NULL DEFAULT '-1.00',
  `loan_desc` longtext,
  `period_inte_only_pay` int(8) DEFAULT '-1',
  `comp_int_rate` double(6,3) DEFAULT '-1.000',
  `std_orgination_fee` double(15,2) DEFAULT '-1.00',
  `std_peri_int_only_pay` int(8) DEFAULT '-1',
  `std_amort_period` int(8) DEFAULT '-1',
  `tradi_form_collateral` char(1) DEFAULT NULL,
  `purpose` int(3) NOT NULL DEFAULT '0',
  `projected_grant` int(8) NOT NULL DEFAULT '-1',
  `use_std_org_fee` int(8) NOT NULL DEFAULT '0',
  `seq_id` int(8) NOT NULL DEFAULT '0',
  `projectedqei_id` varchar(20) DEFAULT '',
  `interest_rate_desc` text NOT NULL,
  `interest_type_desc` text NOT NULL,
  `investor_exception` text,
  `risk_rating` text NOT NULL,
  `maturity_date` varchar(10) DEFAULT '0000-00-00',
  `billing_date` varchar(10) DEFAULT '00',
  `projected_grant_opt` varchar(2) DEFAULT 'N',
  `restruct_trans_id` varchar(20) NOT NULL,
  `amort_period_length` int(8) DEFAULT '-1',
  `non_real_amount` double(20,2) DEFAULT '-1.00',
  PRIMARY KEY (`project_loan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Project Loan Requirements Master';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.project_master
CREATE TABLE IF NOT EXISTS `project_master` (
  `project_id` int(8) NOT NULL DEFAULT '0',
  `qalicb_id` int(8) NOT NULL DEFAULT '0',
  `personal_id` int(8) NOT NULL DEFAULT '0',
  `cde_alloc_year` varchar(4) NOT NULL DEFAULT '',
  `register_date` varchar(10) DEFAULT '0000-00-00',
  `phone` varchar(20) NOT NULL DEFAULT '',
  `fax` varchar(20) NOT NULL DEFAULT '',
  `race` varchar(40) NOT NULL DEFAULT '',
  `ethnicity` varchar(40) NOT NULL DEFAULT '',
  `geo_info` varchar(40) NOT NULL DEFAULT '',
  `project_start_date` varchar(10) DEFAULT '0000-00-00',
  `total_project_cost` double(20,2) NOT NULL DEFAULT '-1.00',
  `qei_amount` double(20,2) NOT NULL DEFAULT '-1.00',
  `non_qei_amount` double(20,2) NOT NULL DEFAULT '-1.00',
  `cde_amount` double(20,2) NOT NULL DEFAULT '-1.00',
  `non_cde_amount` double(20,2) NOT NULL DEFAULT '-1.00',
  `test_start_id` int(8) NOT NULL DEFAULT '0',
  `delete_date` varchar(10) DEFAULT '0000-00-00',
  `re_purpose_id` int(4) NOT NULL DEFAULT '0',
  `re_options` varchar(15) NOT NULL DEFAULT '',
  `commercial_purpose` int(4) NOT NULL DEFAULT '0',
  `housing_purpose` int(4) NOT NULL DEFAULT '0',
  `projected_fte` double(20,2) NOT NULL DEFAULT '0.00',
  `total_people_served` double(20,2) NOT NULL DEFAULT '0.00',
  `sqfeet` double(20,2) NOT NULL DEFAULT '0.00',
  `rent_per_sqfeet` double(20,2) NOT NULL DEFAULT '-1.00',
  `total_housing_units` int(9) NOT NULL DEFAULT '0',
  `affordable_housing_units` int(9) NOT NULL DEFAULT '0',
  `project_status` char(1) NOT NULL DEFAULT 'N',
  `equity_total` double(20,2) NOT NULL DEFAULT '-1.00',
  `loan_total` double(20,2) NOT NULL DEFAULT '-1.00',
  `fs_total` double(20,2) NOT NULL DEFAULT '0.00',
  `status` char(1) NOT NULL DEFAULT 'Y',
  `establish_date` varchar(10) DEFAULT '0000-00-00',
  `nmtc_eligibility_criteria` int(3) NOT NULL DEFAULT '0',
  `fips_1990` varchar(11) NOT NULL DEFAULT '',
  `equity_injection_amount` varchar(20) DEFAULT '-1',
  `other_source` double(20,2) DEFAULT '-1.00',
  `hda` text,
  `hda_other` text,
  `project_num` int(8) NOT NULL DEFAULT '-1',
  `project_program` double(20,2) NOT NULL DEFAULT '-1.00',
  `investee_id` int(8) DEFAULT '0',
  `prj_private_invest` double(20,2) DEFAULT '-1.00',
  `hda_fema` char(1) DEFAULT NULL,
  `borrower_fund_reserved` double(20,2) DEFAULT '0.00',
  `borrower_fund_reserved_percent` double(20,2) DEFAULT '0.00',
  `multi_prj_num` varchar(50) NOT NULL,
  `multi_prj_status` char(2) DEFAULT 'E',
  PRIMARY KEY (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Project Informations Master';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.project_other_sources
CREATE TABLE IF NOT EXISTS `project_other_sources` (
  `project_id` int(8) NOT NULL DEFAULT '0',
  `other_sources_id` int(4) NOT NULL DEFAULT '0',
  `amount` double(20,2) NOT NULL DEFAULT '0.00',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`project_id`,`other_sources_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Project Other Sources of Investments';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.project_other_taxcredit
CREATE TABLE IF NOT EXISTS `project_other_taxcredit` (
  `project_other_id` int(8) NOT NULL DEFAULT '0',
  `project_id` int(8) NOT NULL DEFAULT '0',
  `tax_credit_id` int(4) NOT NULL DEFAULT '0',
  `other_sources_id` int(4) NOT NULL DEFAULT '0',
  `name` varchar(60) NOT NULL DEFAULT '',
  `lein_position_id` int(4) NOT NULL DEFAULT '0',
  `amount` double(20,2) NOT NULL DEFAULT '0.00',
  `status` char(1) NOT NULL DEFAULT 'Y',
  `equity_injection_amount` double(20,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`project_other_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Project Information''s relating to other tax credit program''s';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.project_purpose_master
CREATE TABLE IF NOT EXISTS `project_purpose_master` (
  `purpose_id` int(4) NOT NULL DEFAULT '0',
  `purpose_desc` char(90) NOT NULL DEFAULT '',
  `cdfi_code` char(20) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`purpose_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.project_rate_terms_master
CREATE TABLE IF NOT EXISTS `project_rate_terms_master` (
  `prt_id` int(8) NOT NULL DEFAULT '0',
  `prt_desc` varchar(100) NOT NULL DEFAULT '',
  `cdfi_code` varchar(20) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`prt_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.project_src_comp_details
CREATE TABLE IF NOT EXISTS `project_src_comp_details` (
  `src_comp_id` int(8) NOT NULL DEFAULT '0',
  `project_id` int(8) NOT NULL DEFAULT '0',
  `qalicb_id` int(8) NOT NULL DEFAULT '0',
  `cde_id` int(8) NOT NULL DEFAULT '0',
  `investee_id` int(8) NOT NULL DEFAULT '0',
  `qei_proceed_amt` double(20,2) DEFAULT '-1.00',
  `fes_investor_amt` double(20,2) DEFAULT '-1.00',
  `fes_borrower_amt` double(20,2) DEFAULT '-1.00',
  `fes_others_amt` double(20,2) DEFAULT '-1.00',
  `ogs_investor_amt` double(20,2) DEFAULT '-1.00',
  `ogs_borrower_amt` double(20,2) DEFAULT '-1.00',
  `ogs_others_amt` double(20,2) DEFAULT '-1.00',
  `bes_investor_amt` double(20,2) DEFAULT '-1.00',
  `bes_borrower_amt` double(20,2) DEFAULT '-1.00',
  `bes_others_amt` double(20,2) DEFAULT '-1.00',
  `osc_investor_amt` double(20,2) DEFAULT '-1.00',
  `osc_borrower_amt` double(20,2) DEFAULT '-1.00',
  `osc_others_amt` double(20,2) DEFAULT '-1.00',
  `status` char(1) DEFAULT 'Y'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.proj_com_facility
CREATE TABLE IF NOT EXISTS `proj_com_facility` (
  `proj_com_id` int(4) NOT NULL DEFAULT '0',
  `project_id` int(4) NOT NULL DEFAULT '0',
  `qalicb_id` int(4) NOT NULL DEFAULT '0',
  `office_sqfeet` double(20,2) NOT NULL DEFAULT '-1.00',
  `retail_sqfeet` double(20,2) NOT NULL DEFAULT '-1.00',
  `manfact_sqfeet` double(20,2) NOT NULL DEFAULT '-1.00',
  `hu_sale` int(9) NOT NULL DEFAULT '-1',
  `hu_rental` int(9) NOT NULL DEFAULT '-1',
  `ahu_sale` int(9) NOT NULL DEFAULT '-1',
  `ahu_rental` int(9) NOT NULL DEFAULT '-1',
  `status` char(1) NOT NULL DEFAULT 'Y',
  `type` varchar(10) NOT NULL DEFAULT '',
  `dk_status` varchar(50) DEFAULT NULL,
  `sqfeet_total` int(8) NOT NULL DEFAULT '-1',
  `jobs_business` double(20,2) NOT NULL DEFAULT '-1.00',
  `jobs_const` double(20,2) NOT NULL DEFAULT '-1.00',
  `jobs_tenant` double(20,2) NOT NULL DEFAULT '-1.00',
  `job_type_id` int(8) DEFAULT '0',
  `job_estimate_id` int(8) DEFAULT '0',
  `job_estimate_other` text,
  `manfact_sqfeet_status` varchar(1) DEFAULT 'N',
  `office_sqfeet_status` varchar(1) DEFAULT 'N',
  `retail_sqfeet_status` varchar(1) DEFAULT 'N',
  `hu_sale_status` varchar(1) DEFAULT 'N',
  `hu_rental_status` varchar(1) DEFAULT 'N',
  `ahu_sale_status` varchar(1) DEFAULT 'N',
  `ahu_rental_status` varchar(1) DEFAULT 'N',
  `jobs_business_status` varchar(1) DEFAULT 'N',
  `jobs_const_status` varchar(1) DEFAULT 'N',
  `jobs_tenant_status` varchar(1) DEFAULT 'N',
  `sqfeet_total_status` varchar(1) DEFAULT 'N',
  `actual_jobs_business` double(20,2) NOT NULL DEFAULT '-1.00',
  `actual_jobs_business_status` char(2) DEFAULT 'N',
  `actual_jobs_const` double(20,2) NOT NULL DEFAULT '-1.00',
  `actual_jobs_const_status` char(2) DEFAULT 'N',
  `actual_jobs_tenant` double(20,2) NOT NULL DEFAULT '-1.00',
  `actual_jobs_tenant_status` char(2) DEFAULT 'N',
  PRIMARY KEY (`proj_com_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.purpose_master
CREATE TABLE IF NOT EXISTS `purpose_master` (
  `purpose_id` int(4) NOT NULL DEFAULT '0',
  `purpose_desc` varchar(90) NOT NULL DEFAULT '',
  `cdfi_code` varchar(20) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`purpose_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Purpose List';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.qalicb_bprofile
CREATE TABLE IF NOT EXISTS `qalicb_bprofile` (
  `bprofile_id` int(4) NOT NULL DEFAULT '0',
  `qalicb_id` int(3) NOT NULL DEFAULT '0',
  `bprofile_desc` text,
  `naics_code` varchar(6) NOT NULL DEFAULT '',
  `sic_code` varchar(4) NOT NULL DEFAULT '',
  `tax_status` int(3) NOT NULL DEFAULT '0',
  `minority_owned` char(1) NOT NULL DEFAULT 'N',
  `women_owned` char(1) NOT NULL DEFAULT 'N',
  `lowincome_owned` char(1) NOT NULL DEFAULT 'N',
  `status` char(1) NOT NULL DEFAULT 'Y',
  `business_desc_id` int(8) DEFAULT '0',
  PRIMARY KEY (`bprofile_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Business Profile for QALICB';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.qalicb_impact_profile
CREATE TABLE IF NOT EXISTS `qalicb_impact_profile` (
  `impact_id` int(4) NOT NULL DEFAULT '0',
  `qalicb_id` int(3) NOT NULL DEFAULT '0',
  `borrower_name` varchar(50) NOT NULL DEFAULT '',
  `fico_score` varchar(10) NOT NULL DEFAULT '',
  `gender` char(1) NOT NULL DEFAULT 'M',
  `eth_id` int(3) NOT NULL DEFAULT '0',
  `race_id` int(3) NOT NULL DEFAULT '0',
  `borrower_type` char(100) NOT NULL DEFAULT 'P',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`impact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='QALICB Borrowers Impact Profile';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.qalicb_info
CREATE TABLE IF NOT EXISTS `qalicb_info` (
  `qalicb_id` int(5) NOT NULL DEFAULT '0',
  `cde_id` int(4) NOT NULL DEFAULT '0',
  `personal_id` int(8) NOT NULL DEFAULT '0',
  `qalicb_investee` int(1) NOT NULL DEFAULT '0',
  `related_entity` char(1) NOT NULL DEFAULT 'O',
  `religious` char(1) NOT NULL DEFAULT 'O',
  `register_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `leave_date` varchar(20) NOT NULL DEFAULT '0000-00-00',
  `date_business_established` varchar(20) DEFAULT '0000-00-00',
  `first_name` varchar(100) NOT NULL DEFAULT '',
  `middle_name` varchar(100) DEFAULT '',
  `last_name` varchar(100) NOT NULL DEFAULT '',
  `phone` varchar(50) NOT NULL DEFAULT '',
  `alt_phone` varchar(20) NOT NULL DEFAULT '',
  `fax` varchar(20) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `federal_id` varchar(20) NOT NULL DEFAULT '',
  `cde_controlled` char(1) NOT NULL DEFAULT 'Y',
  `nmtc_proceeds` varchar(100) NOT NULL DEFAULT '',
  `investee_type` int(3) NOT NULL DEFAULT '0',
  `entity_type` int(3) NOT NULL DEFAULT '0',
  `investee_suboption` int(3) NOT NULL DEFAULT '0',
  `total_borrowers` int(4) NOT NULL DEFAULT '1',
  `bprofile_id` int(4) NOT NULL DEFAULT '0',
  `future_test_status` char(1) NOT NULL DEFAULT 'N',
  `status` char(1) NOT NULL DEFAULT 'Y',
  `last_update_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `investee_id` int(8) DEFAULT '0',
  PRIMARY KEY (`qalicb_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='QALICB Information''s';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.qalicb_mail
CREATE TABLE IF NOT EXISTS `qalicb_mail` (
  `mail_id` int(5) NOT NULL DEFAULT '0',
  `qalicb_id` int(5) DEFAULT NULL,
  `amendment_id` int(5) DEFAULT NULL,
  `30_days` char(1) DEFAULT '0',
  `15_days` char(1) DEFAULT '0',
  `7_days` char(1) DEFAULT '0',
  `3_days` char(1) DEFAULT '0',
  `1_days` char(1) DEFAULT '0',
  `status` char(1) DEFAULT NULL,
  PRIMARY KEY (`mail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.qalicb_qei_received
CREATE TABLE IF NOT EXISTS `qalicb_qei_received` (
  `qalicb_qei_id` int(8) NOT NULL DEFAULT '0',
  `cash_details_id` int(8) NOT NULL DEFAULT '0',
  `pf_id` int(8) NOT NULL DEFAULT '0',
  `disburse_cash_id` int(8) NOT NULL DEFAULT '0',
  `qei_id` varchar(100) DEFAULT NULL,
  `project_id` int(8) NOT NULL DEFAULT '0',
  `qalicb_id` int(8) NOT NULL DEFAULT '0',
  `cde_id` int(8) NOT NULL DEFAULT '0',
  `qlici_type` int(3) NOT NULL DEFAULT '0',
  `trans_type` varchar(15) NOT NULL DEFAULT '',
  `alloc_year` varchar(4) NOT NULL DEFAULT '0',
  `received_amt` double(20,2) NOT NULL DEFAULT '0.00',
  `received_date` date NOT NULL DEFAULT '0000-00-00',
  `sys_date` date NOT NULL DEFAULT '0000-00-00',
  `type` varchar(5) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT '',
  `src_from` varchar(5) DEFAULT NULL,
  `src_to` varchar(5) DEFAULT NULL,
  `transfer_id` int(8) NOT NULL DEFAULT '0',
  `trans_cap_name` varchar(100) NOT NULL DEFAULT '',
  `src_trans_type` varchar(15) NOT NULL DEFAULT '',
  `disburse_type` varchar(5) DEFAULT NULL,
  `open_disburse_id` int(8) DEFAULT '0',
  `origin_disburse_id` int(8) DEFAULT '0',
  PRIMARY KEY (`qalicb_qei_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for procedure cdesolution.qalicb_qei_source
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `qalicb_qei_source`(IN `cdeId` INT(8), IN `disburseDate` VARCHAR(10), IN `qeiType` INT(2), IN `opType` INT(2))
BEGIN
SELECT pf.pf_id,pf.investor_id, pf.organization, pf.bal_amount,
pf.inv_pf_date,pf.pf_date,pf.type,pf.qei_id,pf.qeiid_from_ats,pf.alloc_year
FROM (SELECT pf.pf_id,pf.investor_id, p.organization, ROUND(SUM(IF(qeiType = 1, (pf.pf_bal_fund-pf.lr_fund-pf.fcos_fund),(pf.pf_bal_fund))),4) AS bal_amount,
pf.inv_pf_date,pf.pf_date,pf.type,pf.qei_id,cc.qeiid_from_ats,pf.alloc_year FROM project_fund_master pf,
investor_info_copy i, personal_info p, cash_details cc  WHERE pf.cde_id = cdeId 
AND pf.pf_date <= disburseDate
AND pf.status != 'D'  AND IF(qeiType =1, pf.type IN ('QEP','QFS','QSP','QUP'), pf.type IN ('IQEP','IQSP','IQUP','IQES','IQEU')) AND 
pf.cash_details_id = cc.cash_details_id AND cc.status!='D' AND i.investor_id = pf.investor_id 
AND p.personal_id=i.personal_id AND  
(pf.pf_bal_fund-pf.lr_fund-pf.fcos_fund)>0 GROUP BY TYPE,pf_date,pf.qei_id) AS pf LEFT JOIN 
(SELECT pf.qei_id,pf.total_amt, pf.pf_date FROM project_fund_master pf,cash_details cc 
WHERE pf.cde_id = cdeId AND pf.pf_date<= disburseDate  AND pf.type='I' AND 
cc.cash_details_id=pf.cash_details_id AND cc.status!='D' AND pf.status != 'D' ) AS qe ON pf.qei_id = qe.qei_id
WHERE (IF(opType = 1,(DATE_SUB((DATE_ADD(qe.pf_date,INTERVAL 7 YEAR)),INTERVAL 1 DAY) >= disburseDate), (DATE_SUB((DATE_ADD(qe.pf_date,INTERVAL 7 YEAR)),INTERVAL 1 DAY) < disburseDate))) ORDER BY pf.pf_date,pf.pf_id ASC;
END//
DELIMITER ;


-- Dumping structure for procedure cdesolution.qalicb_qei_source_all
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `qalicb_qei_source_all`(IN `cdeId` INT(8), IN `disburseDate` VARCHAR(10), IN `qeiType` INT(2))
BEGIN
SELECT pf.pf_id,pf.investor_id, p.organization, ROUND(SUM(IF(qeiType = 1, (pf.pf_bal_fund-pf.lr_fund-pf.fcos_fund),(pf.pf_bal_fund))),4) AS bal_amount,pf.inv_pf_date,
pf.pf_date,pf.type,pf.qei_id,cc.qeiid_from_ats,pf.alloc_year FROM project_fund_master pf,
investor_info_copy i, personal_info p, cash_details cc  WHERE pf.cde_id = cdeId 
AND pf.pf_date <= disburseDate
AND pf.status != 'D'  AND IF(qeiType =1, pf.type IN ('QEP','QFS','QSP','QUP'), pf.type IN ('IQEP','IQSP','IQUP','IQES','IQEU')) AND 
pf.cash_details_id = cc.cash_details_id AND cc.status!='D' AND i.investor_id = pf.investor_id 
AND p.personal_id=i.personal_id AND  
(pf.pf_bal_fund-pf.lr_fund-pf.fcos_fund)>0 GROUP BY TYPE,pf_date,pf.qei_id;
END//
DELIMITER ;


-- Dumping structure for table cdesolution.qalicb_test
CREATE TABLE IF NOT EXISTS `qalicb_test` (
  `qtest_id` int(8) NOT NULL DEFAULT '0',
  `qalicb_id` int(5) NOT NULL DEFAULT '0',
  `date_of_test` date NOT NULL DEFAULT '0000-00-00',
  `amendment_id` int(5) DEFAULT '0',
  `total_gross_income` double(20,2) NOT NULL DEFAULT '-1.00',
  `lic_gross_income` double(20,2) NOT NULL DEFAULT '-1.00',
  `total_tang_prop` double(20,2) NOT NULL DEFAULT '-1.00',
  `lic_tang_prop` double(20,2) NOT NULL DEFAULT '-1.00',
  `total_service_provided` double(20,2) NOT NULL DEFAULT '-1.00',
  `lic_service_provided` double(20,2) NOT NULL DEFAULT '-1.00',
  `res_rent_income` double(20,2) NOT NULL DEFAULT '-1.00',
  `com_rent_income` double(20,2) NOT NULL DEFAULT '-1.00',
  `test_result` char(1) NOT NULL DEFAULT 'F',
  `business_type` varchar(50) DEFAULT NULL,
  `new_business` char(1) DEFAULT NULL,
  `cde_controlled` char(1) DEFAULT NULL,
  `status` char(1) DEFAULT NULL,
  PRIMARY KEY (`qtest_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='QALICB Test Information''s';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.qalicb_test_mail
CREATE TABLE IF NOT EXISTS `qalicb_test_mail` (
  `qalicb_test_mail_id` int(10) NOT NULL DEFAULT '0',
  `mail_setup_id` int(10) NOT NULL DEFAULT '0',
  `qalicb_id` int(10) NOT NULL DEFAULT '0',
  `start_date` date NOT NULL DEFAULT '0000-00-00',
  `due_date` date NOT NULL DEFAULT '0000-00-00',
  `next_test_date` date NOT NULL DEFAULT '0000-00-00',
  `alert_days` int(10) DEFAULT '0',
  `alert_status` char(1) DEFAULT 'N',
  `status` char(1) DEFAULT 'N',
  PRIMARY KEY (`qalicb_test_mail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.qei_commit_history
CREATE TABLE IF NOT EXISTS `qei_commit_history` (
  `qei_fund_id` int(8) NOT NULL DEFAULT '0',
  `ammend_id` int(5) NOT NULL DEFAULT '0',
  `cde_id` int(5) NOT NULL DEFAULT '0',
  `investor_id` int(8) NOT NULL DEFAULT '0',
  `fund_date` varchar(50) NOT NULL DEFAULT '0000-00-00',
  `fund_commit_year` int(4) DEFAULT NULL,
  `fund_amount` double(30,16) DEFAULT NULL,
  `status` char(2) DEFAULT 'Y',
  `fund_type` varchar(10) DEFAULT '',
  `end_date` varchar(20) DEFAULT NULL,
  `group_id` int(8) NOT NULL DEFAULT '0',
  `slno` int(2) NOT NULL DEFAULT '0',
  `sub_group_id` int(8) NOT NULL DEFAULT '0',
  `tier_type` int(8) NOT NULL DEFAULT '0',
  `qei_ammend_id` int(5) NOT NULL DEFAULT '0',
  `qei_id` varchar(20) DEFAULT '',
  PRIMARY KEY (`qei_fund_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.qei_modify_details
CREATE TABLE IF NOT EXISTS `qei_modify_details` (
  `qei_mod_id` int(8) NOT NULL DEFAULT '0',
  `cde_id` int(8) NOT NULL DEFAULT '0',
  `cash_details_id` int(8) NOT NULL DEFAULT '0',
  `received_date` date DEFAULT NULL,
  `days_inc` int(8) NOT NULL DEFAULT '0',
  `alloc_year` int(8) NOT NULL DEFAULT '0',
  `system_date` date DEFAULT NULL,
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`qei_mod_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.qei_notify_mail
CREATE TABLE IF NOT EXISTS `qei_notify_mail` (
  `qei_notify_id` int(10) NOT NULL DEFAULT '0',
  `mail_setup_id` int(10) NOT NULL DEFAULT '0',
  `alert_type_id` int(10) NOT NULL DEFAULT '0',
  `cash_details_id` int(10) NOT NULL DEFAULT '0',
  `due_date` date NOT NULL DEFAULT '0000-00-00',
  `alert_days` int(5) NOT NULL DEFAULT '0',
  `alert_status` char(1) NOT NULL DEFAULT 'N',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`qei_notify_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.qlici_allow_master
CREATE TABLE IF NOT EXISTS `qlici_allow_master` (
  `allow_id` int(3) NOT NULL DEFAULT '0',
  `allow_desc` text,
  `qalicb_type` int(1) DEFAULT '1',
  `display_order` int(3) DEFAULT '0',
  `status` char(1) DEFAULT 'Y',
  PRIMARY KEY (`allow_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.qlici_level_master
CREATE TABLE IF NOT EXISTS `qlici_level_master` (
  `qlici_level_id` int(3) NOT NULL DEFAULT '0',
  `qlici_level_desc` varchar(15) NOT NULL DEFAULT '',
  `cdfi_code` varchar(10) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`qlici_level_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='QLICI Level Master - Original / Re-investment';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.qlici_type_master
CREATE TABLE IF NOT EXISTS `qlici_type_master` (
  `qlici_id` int(4) NOT NULL DEFAULT '0',
  `qlici_desc` varchar(50) NOT NULL DEFAULT '',
  `cdfi_code` varchar(20) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`qlici_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='QLICI Master Table.';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.quartz_trigger
CREATE TABLE IF NOT EXISTS `quartz_trigger` (
  `quartz_id` int(3) NOT NULL AUTO_INCREMENT,
  `trigger_date` date DEFAULT NULL,
  `trigger_time` varchar(100) DEFAULT NULL,
  `status` char(1) DEFAULT NULL,
  PRIMARY KEY (`quartz_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.race_master
CREATE TABLE IF NOT EXISTS `race_master` (
  `race_id` int(3) NOT NULL DEFAULT '0',
  `race_desc` varchar(50) NOT NULL DEFAULT '',
  `cdfi_code` varchar(20) DEFAULT NULL,
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`race_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Race Master Table';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.rate_and_terms_master
CREATE TABLE IF NOT EXISTS `rate_and_terms_master` (
  `rate_and_terms_id` int(8) NOT NULL DEFAULT '0',
  `rate_and_terms_desc` char(100) NOT NULL DEFAULT '',
  `cdfi_code` char(20) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`rate_and_terms_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Better rate and Terms Master';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.refinancing_master
CREATE TABLE IF NOT EXISTS `refinancing_master` (
  `refinancing_id` int(8) NOT NULL DEFAULT '0',
  `refinancing_desc` varchar(60) NOT NULL DEFAULT '',
  `cdfi_code` varchar(20) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`refinancing_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.registers
CREATE TABLE IF NOT EXISTS `registers` (
  `register_no` int(11) NOT NULL AUTO_INCREMENT,
  `address` longtext,
  `comapny_name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `suscribed` varchar(255) DEFAULT NULL,
  `system_date` varchar(255) DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`register_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.relation_cde
CREATE TABLE IF NOT EXISTS `relation_cde` (
  `cde_id` int(5) NOT NULL DEFAULT '0',
  `subcde_id` int(5) NOT NULL DEFAULT '0',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`cde_id`,`subcde_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Sudsidary CDE and CDE relations';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.relation_investee_cde
CREATE TABLE IF NOT EXISTS `relation_investee_cde` (
  `cde_id` int(10) NOT NULL DEFAULT '0',
  `investeecde_id` int(10) NOT NULL DEFAULT '0',
  `status` char(1) NOT NULL DEFAULT 'Y',
  `naics_code` varchar(6) NOT NULL DEFAULT '',
  `sic_code` varchar(4) NOT NULL DEFAULT '',
  `gender` char(1) NOT NULL DEFAULT '',
  `hispanic_origin` int(3) NOT NULL DEFAULT '0',
  `race_id` int(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cde_id`,`investeecde_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.relation_investor
CREATE TABLE IF NOT EXISTS `relation_investor` (
  `master_investor_id` int(8) NOT NULL DEFAULT '0',
  `sub_investor_id` int(8) NOT NULL DEFAULT '0',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`master_investor_id`,`sub_investor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.reminder_days_setup
CREATE TABLE IF NOT EXISTS `reminder_days_setup` (
  `reminder_day_id` int(8) NOT NULL DEFAULT '0',
  `reminder_setup_id` int(8) NOT NULL DEFAULT '0',
  `due_date_id` int(8) NOT NULL DEFAULT '0',
  `cde_id` int(8) NOT NULL DEFAULT '0',
  `days` int(8) NOT NULL DEFAULT '0',
  `system_date` varchar(15) NOT NULL DEFAULT '0000-00-00',
  `default_id` int(8) NOT NULL DEFAULT '0',
  `STATUS` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`reminder_day_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.reminder_msg_master
CREATE TABLE IF NOT EXISTS `reminder_msg_master` (
  `reminder_type` int(11) NOT NULL,
  `reminder_header_msg` longtext NOT NULL,
  `reminder_mail_type` varchar(255) DEFAULT NULL,
  `reminder_priority_id` int(11) DEFAULT NULL,
  `reminder_subject_msg` longtext,
  `status` char(1) NOT NULL,
  `cde_based` varchar(255) NOT NULL,
  PRIMARY KEY (`reminder_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.return_inv_master
CREATE TABLE IF NOT EXISTS `return_inv_master` (
  `return_inv_id` int(8) NOT NULL,
  `cde_id` int(8) NOT NULL,
  `investor_id` int(8) NOT NULL DEFAULT '0',
  `non_qei_id` int(8) NOT NULL DEFAULT '0',
  `cash_details_id` int(8) NOT NULL,
  `transfer_id` int(8) NOT NULL DEFAULT '0',
  `return_amt` double(15,2) NOT NULL DEFAULT '0.00',
  `return_date` date NOT NULL,
  `system_date` date NOT NULL,
  `return_type` char(5) NOT NULL,
  `TYPE` char(8) NOT NULL,
  `STATUS` char(2) NOT NULL,
  `trans_cap_name` char(100) NOT NULL,
  `bal_amt` double(15,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`return_inv_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.return_to_investor
CREATE TABLE IF NOT EXISTS `return_to_investor` (
  `ret_investor_id` int(8) NOT NULL,
  `cde_id` int(8) NOT NULL,
  `investor_id` int(8) NOT NULL,
  `qalicb_id` int(8) NOT NULL DEFAULT '0',
  `investee_id` int(8) NOT NULL DEFAULT '0',
  `project_id` int(8) NOT NULL DEFAULT '0',
  `alloc_year` varchar(4) NOT NULL,
  `pf_id` int(8) NOT NULL,
  `ret_amount` double(21,2) NOT NULL DEFAULT '0.00',
  `pf_type` varchar(5) NOT NULL,
  `pf_date` varchar(10) NOT NULL,
  `ret_date` varchar(10) NOT NULL,
  `ret_amount_balance` double(21,2) NOT NULL DEFAULT '0.00',
  `qei_id` varchar(15) NOT NULL,
  `cash_details_id` int(8) NOT NULL,
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`ret_investor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.re_options_master
CREATE TABLE IF NOT EXISTS `re_options_master` (
  `re_options_id` int(4) NOT NULL DEFAULT '0',
  `re_options_desc` varchar(40) NOT NULL DEFAULT '',
  `cdfi_code` varchar(20) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`re_options_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Real Estate - Options Master';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.re_purpose_master
CREATE TABLE IF NOT EXISTS `re_purpose_master` (
  `re_purpose_id` int(4) NOT NULL DEFAULT '0',
  `re_purpose_desc` varchar(100) NOT NULL DEFAULT '',
  `cdfi_code` varchar(20) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`re_purpose_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Real Estate - Purpose Master';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.rqi_fund_master
CREATE TABLE IF NOT EXISTS `rqi_fund_master` (
  `rqi_id` int(8) NOT NULL DEFAULT '0',
  `cde_id` int(8) NOT NULL,
  `qalicb_id` int(8) NOT NULL,
  `project_id` int(8) NOT NULL,
  `trans_type` varchar(50) NOT NULL,
  `cash_details_id` int(8) NOT NULL,
  `disburse_cash_id` int(8) NOT NULL,
  `amount_received` double(20,2) NOT NULL,
  `received_date` date NOT NULL,
  `rqi_type` varchar(6) NOT NULL,
  `rqi_desc` varchar(50) NOT NULL,
  `balance_amt` double(20,2) NOT NULL,
  `system_date` date NOT NULL,
  `status` char(2) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`rqi_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.safe_harbor_asset
CREATE TABLE IF NOT EXISTS `safe_harbor_asset` (
  `asset_id` int(8) NOT NULL DEFAULT '0',
  `cde_id` int(8) NOT NULL DEFAULT '0',
  `report_date` date DEFAULT NULL,
  `test_date` date NOT NULL DEFAULT '0000-00-00',
  `asset_amount` double(20,2) DEFAULT '0.00',
  `status` char(1) DEFAULT 'Y',
  PRIMARY KEY (`asset_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.safe_harbor_test
CREATE TABLE IF NOT EXISTS `safe_harbor_test` (
  `test_id` int(8) NOT NULL DEFAULT '0',
  `cde_id` int(8) NOT NULL DEFAULT '0',
  `current_asset` double(20,2) DEFAULT '0.00',
  `current_qlici` double(20,2) DEFAULT '0.00',
  `previous_asset` decimal(20,2) DEFAULT '0.00',
  `previous_qlici` double(20,2) DEFAULT '0.00',
  `test_date` date NOT NULL DEFAULT '0000-00-00',
  `report_date` date NOT NULL DEFAULT '0000-00-00',
  `test_status` char(1) DEFAULT 'F',
  `repayment_status` int(1) DEFAULT NULL,
  `status` char(1) DEFAULT 'Y',
  PRIMARY KEY (`test_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.sa_type_master
CREATE TABLE IF NOT EXISTS `sa_type_master` (
  `sa_type_id` int(8) NOT NULL DEFAULT '0',
  `sa_type_desc` varchar(60) NOT NULL DEFAULT '',
  `cdfi_code` varchar(20) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`sa_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Service Area Type Master';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.sessions_master
CREATE TABLE IF NOT EXISTS `sessions_master` (
  `session_master_id` int(11) NOT NULL AUTO_INCREMENT,
  `session_id` varchar(100) NOT NULL DEFAULT '',
  `ipaddress` varchar(200) DEFAULT '',
  `host_name` varchar(400) DEFAULT '',
  `start_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `end_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_name` varchar(30) NOT NULL DEFAULT '',
  `cde_name` varchar(100) DEFAULT '',
  `status` char(1) DEFAULT NULL,
  PRIMARY KEY (`session_master_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Session Master for tracking user sessions';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.session_action_master
CREATE TABLE IF NOT EXISTS `session_action_master` (
  `session_action_master_id` int(11) NOT NULL AUTO_INCREMENT,
  `session_action_desc` varchar(200) DEFAULT NULL,
  `status` char(10) DEFAULT NULL,
  PRIMARY KEY (`session_action_master_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.session_master
CREATE TABLE IF NOT EXISTS `session_master` (
  `session_id` varchar(100) NOT NULL DEFAULT '',
  `ipaddress` varchar(15) DEFAULT '',
  `start_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `end_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_name` varchar(30) NOT NULL DEFAULT '',
  `cde_name` varchar(100) DEFAULT '',
  `status` char(1) DEFAULT NULL,
  PRIMARY KEY (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Session Master for tracking user sessions';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.session_master_info
CREATE TABLE IF NOT EXISTS `session_master_info` (
  `session_master_info_id` int(15) NOT NULL AUTO_INCREMENT,
  `session_master_id` int(15) NOT NULL,
  `page_url` varchar(500) NOT NULL,
  `page_module_id` int(3) NOT NULL,
  `page_block_heading` varchar(500) NOT NULL,
  `accessed_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `session_action_id` int(11) NOT NULL,
  `action_description` varchar(1000) NOT NULL,
  PRIMARY KEY (`session_master_info_id`),
  KEY `FK_session_master_id` (`session_master_id`),
  KEY `FK_session_action_id` (`session_action_id`),
  KEY `FK_session_module_master_id` (`page_module_id`),
  CONSTRAINT `FK_session_action_id` FOREIGN KEY (`session_action_id`) REFERENCES `session_action_master` (`session_action_master_id`),
  CONSTRAINT `FK_session_master_id` FOREIGN KEY (`session_master_id`) REFERENCES `sessions_master` (`session_master_id`),
  CONSTRAINT `FK_session_module_master_id` FOREIGN KEY (`page_module_id`) REFERENCES `session_module_master` (`session_module_master_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.session_module_master
CREATE TABLE IF NOT EXISTS `session_module_master` (
  `session_module_master_id` int(2) NOT NULL,
  `module_description` varchar(500) DEFAULT NULL,
  `status` char(1) DEFAULT NULL,
  PRIMARY KEY (`session_module_master_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.state_master
CREATE TABLE IF NOT EXISTS `state_master` (
  `state_id` char(2) NOT NULL DEFAULT '',
  `state_name` varchar(50) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`state_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='State Master contains all states';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.substantial_option_master
CREATE TABLE IF NOT EXISTS `substantial_option_master` (
  `option_id` int(3) NOT NULL DEFAULT '0',
  `description` varchar(70) DEFAULT '0',
  `status` char(1) DEFAULT 'Y',
  PRIMARY KEY (`option_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.substantial_test_setup
CREATE TABLE IF NOT EXISTS `substantial_test_setup` (
  `setup_id` int(8) NOT NULL DEFAULT '0',
  `cde_id` int(8) NOT NULL DEFAULT '0',
  `test_type` int(3) NOT NULL DEFAULT '0',
  `option_type` int(3) NOT NULL DEFAULT '0',
  `first_date` varchar(50) DEFAULT NULL,
  `second_date` varchar(50) DEFAULT NULL,
  `status` char(1) DEFAULT '0',
  `login_name` varchar(100) DEFAULT NULL,
  `ip_address` varchar(20) NOT NULL DEFAULT '000.000.000.000',
  PRIMARY KEY (`setup_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.substantial_type_master
CREATE TABLE IF NOT EXISTS `substantial_type_master` (
  `type_id` int(3) NOT NULL DEFAULT '0',
  `description` varchar(30) DEFAULT NULL,
  `status` char(1) DEFAULT 'Y',
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.super_admin_users
CREATE TABLE IF NOT EXISTS `super_admin_users` (
  `user_name` varchar(50) NOT NULL DEFAULT '',
  `password` varchar(30) NOT NULL DEFAULT '0',
  `email_id` varchar(50) NOT NULL DEFAULT '',
  `reg_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `cde_ids` text NOT NULL,
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`user_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.take_acquisition_financing_master
CREATE TABLE IF NOT EXISTS `take_acquisition_financing_master` (
  `take_acq_finance_id` int(8) NOT NULL DEFAULT '0',
  `take_acq_finance_desc` varchar(60) NOT NULL DEFAULT '',
  `cdfi_code` varchar(20) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`take_acq_finance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.task_assign_info
CREATE TABLE IF NOT EXISTS `task_assign_info` (
  `assign_id` int(8) NOT NULL DEFAULT '0',
  `task_id` int(8) DEFAULT '0',
  `assignedto_user` varchar(50) DEFAULT NULL,
  `assignedto_cde_id` int(8) DEFAULT '0',
  `assignedto_group_id` int(8) DEFAULT '0',
  `assignedto_table_id` int(8) DEFAULT '0',
  `task_status` varchar(20) DEFAULT NULL,
  `message_status` varchar(10) NOT NULL DEFAULT 'Unread',
  `status` char(1) DEFAULT 'Y',
  PRIMARY KEY (`assign_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.task_info
CREATE TABLE IF NOT EXISTS `task_info` (
  `task_id` int(8) NOT NULL DEFAULT '0',
  `assignedby_user` varchar(50) DEFAULT NULL,
  `priority` varchar(10) DEFAULT NULL,
  `assignedby_cde_id` int(8) DEFAULT '0',
  `assignedby_group_id` int(8) DEFAULT '0',
  `assignedby_table_id` int(8) DEFAULT '0',
  `message` longtext,
  `subject` varchar(100) DEFAULT NULL,
  `file_name` varchar(50) DEFAULT NULL,
  `file_location` varchar(50) DEFAULT NULL,
  `task_date_time` date DEFAULT NULL,
  `reply_id` int(8) DEFAULT '0',
  `sysdate` date DEFAULT NULL,
  `status` char(1) DEFAULT 'Y',
  PRIMARY KEY (`task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.tax_credit_master
CREATE TABLE IF NOT EXISTS `tax_credit_master` (
  `tax_credit_id` int(3) NOT NULL DEFAULT '0',
  `tax_credit_desc` varchar(100) NOT NULL DEFAULT '',
  `cdfi_code` varchar(20) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`tax_credit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Tax Credit Master';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.tax_status_master
CREATE TABLE IF NOT EXISTS `tax_status_master` (
  `tax_status_id` int(1) NOT NULL DEFAULT '0',
  `tax_status_desc` varchar(30) NOT NULL DEFAULT '',
  `cdfi_code` varchar(20) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`tax_status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Tax Status Master contails Non-Profit/For-Profit';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.temp_board_info
CREATE TABLE IF NOT EXISTS `temp_board_info` (
  `rec_id` int(8) unsigned NOT NULL DEFAULT '0',
  `inform_dif` int(2) unsigned NOT NULL DEFAULT '0',
  `cde_id` int(8) unsigned NOT NULL DEFAULT '0',
  `cde_name` varchar(50) DEFAULT NULL,
  `personal_id` int(8) NOT NULL DEFAULT '0',
  `group_id` int(3) NOT NULL DEFAULT '0',
  `member_id` int(5) NOT NULL DEFAULT '0',
  `login_name` varchar(30) NOT NULL DEFAULT '',
  `organization` varchar(100) NOT NULL DEFAULT '',
  `first_name` varchar(30) NOT NULL DEFAULT '',
  `middle_name` varchar(30) NOT NULL DEFAULT '',
  `last_name` varchar(30) NOT NULL DEFAULT '',
  `sex` char(1) NOT NULL DEFAULT '',
  `address1` varchar(60) NOT NULL DEFAULT '',
  `address2` varchar(100) NOT NULL DEFAULT '',
  `city` varchar(30) NOT NULL DEFAULT '',
  `state_id` char(2) NOT NULL DEFAULT '',
  `zip` varchar(10) NOT NULL DEFAULT '',
  `zip4` varchar(10) NOT NULL DEFAULT '',
  `country` varchar(30) NOT NULL DEFAULT '',
  `website` varchar(150) NOT NULL DEFAULT '',
  `phone_acode` varchar(20) NOT NULL DEFAULT '',
  `phone1` varchar(10) NOT NULL DEFAULT '',
  `phone2` varchar(10) NOT NULL DEFAULT '',
  `phone_extn` varchar(10) NOT NULL DEFAULT '',
  `alt_phone` varchar(20) NOT NULL DEFAULT '',
  `alt_phone1` varchar(10) NOT NULL DEFAULT '',
  `alt_phone2` varchar(10) NOT NULL DEFAULT '',
  `fax_acode` varchar(15) NOT NULL DEFAULT '',
  `fax1` varchar(10) NOT NULL DEFAULT '',
  `fax2` varchar(10) NOT NULL DEFAULT '',
  `email` varchar(50) NOT NULL DEFAULT '',
  `county_code` varchar(5) NOT NULL DEFAULT '',
  `census_tractno` varchar(255) NOT NULL DEFAULT '',
  `taxpayer` varchar(50) NOT NULL DEFAULT '',
  `taxpayer_id` varchar(10) NOT NULL DEFAULT '',
  `federal_id` varchar(10) NOT NULL DEFAULT '',
  `federal_id1` varchar(10) NOT NULL DEFAULT '',
  `federal_id2` varchar(10) NOT NULL DEFAULT '',
  `join_date` date NOT NULL DEFAULT '0000-00-00',
  `ssn` varchar(11) NOT NULL DEFAULT '--',
  `member_type` int(3) NOT NULL DEFAULT '0',
  `owner_id` int(3) NOT NULL DEFAULT '0',
  `manpower_id` int(3) NOT NULL DEFAULT '0',
  `type_personal_id` int(8) NOT NULL DEFAULT '0',
  `title` varchar(30) NOT NULL DEFAULT '',
  `gov_dept` varchar(30) NOT NULL DEFAULT '',
  `com_area_served` varchar(100) NOT NULL DEFAULT '',
  `mission` text,
  `upload_status` char(1) NOT NULL DEFAULT 'N',
  `ins_date_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `fmail_id` int(8) NOT NULL DEFAULT '0',
  `status` char(1) NOT NULL DEFAULT 'N',
  `family` char(1) DEFAULT NULL,
  PRIMARY KEY (`rec_id`,`inform_dif`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.temp_project_master
CREATE TABLE IF NOT EXISTS `temp_project_master` (
  `qrec_id` int(8) NOT NULL DEFAULT '0',
  `rec_id` int(8) NOT NULL DEFAULT '0',
  `cde_id` int(5) NOT NULL DEFAULT '0',
  `personal_id` int(8) NOT NULL DEFAULT '0',
  `group_id` int(3) NOT NULL DEFAULT '0',
  `porganization` varchar(100) DEFAULT NULL,
  `paddress1` varchar(60) NOT NULL DEFAULT '',
  `paddress2` varchar(100) DEFAULT NULL,
  `pcity` varchar(30) NOT NULL DEFAULT '',
  `pstate_id` char(2) DEFAULT NULL,
  `pzip` varchar(10) NOT NULL DEFAULT '',
  `pzip4` varchar(10) DEFAULT NULL,
  `pcensus_tractno` varchar(255) DEFAULT NULL,
  `pfirst_name` varchar(30) DEFAULT NULL,
  `pmiddle_name` varchar(30) DEFAULT '',
  `plast_name` varchar(30) DEFAULT NULL,
  `pemail` varchar(50) DEFAULT NULL,
  `pphone1` varchar(5) NOT NULL DEFAULT '',
  `pphone2` varchar(5) NOT NULL DEFAULT '',
  `pphone3` varchar(6) NOT NULL DEFAULT '',
  `pphone4` varchar(6) NOT NULL DEFAULT '',
  `palt_phone1` varchar(5) NOT NULL DEFAULT '',
  `palt_phone2` varchar(5) NOT NULL DEFAULT '',
  `palt_phone3` varchar(6) NOT NULL DEFAULT '',
  `pfax1` varchar(5) DEFAULT NULL,
  `pfax2` varchar(5) DEFAULT NULL,
  `pfax3` varchar(6) DEFAULT NULL,
  `project_id` int(8) NOT NULL DEFAULT '0',
  `qalicb_id` int(8) NOT NULL DEFAULT '0',
  `cde_alloc_year` varchar(4) NOT NULL DEFAULT '',
  `register_date` date NOT NULL DEFAULT '0000-00-00',
  `phone1` varchar(5) NOT NULL DEFAULT '',
  `phone2` varchar(5) NOT NULL DEFAULT '',
  `phone3` varchar(6) NOT NULL DEFAULT '',
  `phone4` varchar(6) NOT NULL DEFAULT '',
  `fax1` varchar(5) NOT NULL DEFAULT '',
  `fax2` varchar(5) NOT NULL DEFAULT '',
  `fax3` varchar(6) NOT NULL DEFAULT '',
  `nmtc_eligibility_criteria` int(3) NOT NULL DEFAULT '0',
  `fips_1990` varchar(10) NOT NULL DEFAULT '',
  `equity_injection_amount` varchar(17) DEFAULT NULL,
  `other_source` varchar(17) DEFAULT NULL,
  `hda` text,
  `hda_other` text,
  `geo_info` varchar(40) NOT NULL DEFAULT '',
  `loan_val_ratio` double(31,16) NOT NULL DEFAULT '-1.0000000000000000',
  `debt_cov_ratio` double(31,16) NOT NULL DEFAULT '-1.0000000000000000',
  `loan_reserve_req` int(8) NOT NULL DEFAULT '0',
  `rate_terms` text NOT NULL,
  `blended_rate` double(31,16) NOT NULL DEFAULT '-1.0000000000000000',
  `comp_interest_rate` double(31,16) NOT NULL DEFAULT '-1.0000000000000000',
  `proj_org_fees` int(8) NOT NULL DEFAULT '-1',
  `std_value_ratio` double(31,16) NOT NULL DEFAULT '-1.0000000000000000',
  `std_debt_ratio` double(31,16) NOT NULL DEFAULT '-1.0000000000000000',
  `std_loan_req` int(8) NOT NULL DEFAULT '-1',
  `com_facility_opt` char(1) DEFAULT NULL,
  `cap_education_fty` double(31,16) NOT NULL DEFAULT '-1.0000000000000000',
  `cap_childcare_fty` double(31,16) NOT NULL DEFAULT '-1.0000000000000000',
  `cap_health_fty` double(31,16) NOT NULL DEFAULT '-1.0000000000000000',
  `cap_arts_fty` double(31,16) NOT NULL DEFAULT '-1.0000000000000000',
  `cap_other_fty` double(31,16) NOT NULL DEFAULT '-1.0000000000000000',
  `cap_opt_status` text NOT NULL,
  `jobs_business` double(31,16) NOT NULL DEFAULT '-1.0000000000000000',
  `jobs_const` double(31,16) NOT NULL DEFAULT '-1.0000000000000000',
  `jobs_tenant` double(31,16) NOT NULL DEFAULT '-1.0000000000000000',
  `sqfeet_total` double(31,16) NOT NULL DEFAULT '-1.0000000000000000',
  `manfact_sqfeet` double(31,16) NOT NULL DEFAULT '-1.0000000000000000',
  `office_sqfeet` double(31,16) NOT NULL DEFAULT '-1.0000000000000000',
  `retail_sqfeet` double(31,16) NOT NULL DEFAULT '-1.0000000000000000',
  `hu_sale` int(9) NOT NULL DEFAULT '-1',
  `hu_rental` int(9) NOT NULL DEFAULT '-1',
  `ahu_sale` int(9) NOT NULL DEFAULT '-1',
  `ahu_rental` int(9) NOT NULL DEFAULT '-1',
  `rent_per_sqfeet` double(31,16) NOT NULL DEFAULT '-1.0000000000000000',
  `status_outcome_info` char(1) NOT NULL DEFAULT 'Y',
  `type` varchar(10) NOT NULL DEFAULT '',
  `dk_status` text NOT NULL,
  `gross_loan` double(31,16) NOT NULL DEFAULT '-1.0000000000000000',
  `dsfs_loan` double(31,16) NOT NULL DEFAULT '-1.0000000000000000',
  `jobs_loan` double(31,16) NOT NULL DEFAULT '-1.0000000000000000',
  `project_start_date` date NOT NULL DEFAULT '0000-00-00',
  `qei_amount` varchar(20) NOT NULL DEFAULT '',
  `non_qei_amount` varchar(20) NOT NULL DEFAULT '',
  `non_cde_amount` varchar(20) NOT NULL DEFAULT '',
  `equity_total` varchar(20) NOT NULL DEFAULT '',
  `loan_total` varchar(20) NOT NULL DEFAULT '',
  `fs_total` varchar(20) NOT NULL DEFAULT '',
  `establish_date` date DEFAULT '0000-00-00',
  `upload_status` char(1) NOT NULL DEFAULT 'N',
  `ins_date_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `fmail_id` int(8) NOT NULL DEFAULT '0',
  `status` char(1) NOT NULL DEFAULT 'Y',
  `blended_rate_comp` int(8) DEFAULT '0',
  `blended_rate_other` text,
  `std_org_fee_comp` int(8) DEFAULT '0',
  `std_org_fee_other` text,
  `std_loan_ratio_comp` int(8) DEFAULT '0',
  `std_loan_ratio_other` text,
  `std_debt_comp` int(8) DEFAULT '0',
  `std_debt_other` text,
  `std_loan_loss_comp` int(8) DEFAULT '0',
  `std_loan_loss_other` text,
  `project_num` int(8) NOT NULL DEFAULT '-1',
  `project_program` double(17,2) NOT NULL DEFAULT '-1.00',
  PRIMARY KEY (`rec_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.temp_qalicb_info
CREATE TABLE IF NOT EXISTS `temp_qalicb_info` (
  `rec_id` int(8) unsigned NOT NULL DEFAULT '0',
  `cde_id` int(8) unsigned NOT NULL DEFAULT '0',
  `cde_name` varchar(50) NOT NULL DEFAULT '',
  `qalicb_id` int(8) NOT NULL DEFAULT '0',
  `personal_id` int(8) NOT NULL DEFAULT '0',
  `group_id` int(3) NOT NULL DEFAULT '0',
  `organization` varchar(100) DEFAULT NULL,
  `address1` varchar(60) NOT NULL DEFAULT '',
  `address2` varchar(100) DEFAULT NULL,
  `city` varchar(30) NOT NULL DEFAULT '',
  `state_id` char(2) DEFAULT NULL,
  `zip` varchar(10) NOT NULL DEFAULT '',
  `zip1` varchar(10) NOT NULL DEFAULT '',
  `phone_acode` varchar(20) NOT NULL DEFAULT '',
  `phone1` varchar(20) NOT NULL DEFAULT '',
  `phone2` varchar(20) NOT NULL DEFAULT '',
  `phone_extn` varchar(20) NOT NULL DEFAULT '',
  `fax_acode` varchar(20) NOT NULL DEFAULT '',
  `fax1` varchar(20) NOT NULL DEFAULT '',
  `fax2` varchar(20) NOT NULL DEFAULT '',
  `website` varchar(150) DEFAULT NULL,
  `last_name` varchar(30) NOT NULL DEFAULT '',
  `middle_name` varchar(30) DEFAULT '',
  `first_name` varchar(30) NOT NULL DEFAULT '',
  `pri_phone_acode` varchar(20) NOT NULL DEFAULT '',
  `pri_phone1` varchar(20) NOT NULL DEFAULT '',
  `pri_phone2` varchar(20) NOT NULL DEFAULT '',
  `pri_phone_extn` varchar(20) NOT NULL DEFAULT '',
  `pri_mobile` varchar(20) NOT NULL DEFAULT '',
  `pri_mobile1` varchar(20) NOT NULL DEFAULT '',
  `pri_mobile2` varchar(20) NOT NULL DEFAULT '',
  `pri_fax_acode` varchar(20) NOT NULL DEFAULT '',
  `pri_fax1` varchar(20) NOT NULL DEFAULT '',
  `pri_fax2` varchar(20) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `investee_type` int(3) NOT NULL DEFAULT '0',
  `entity_type` int(3) NOT NULL DEFAULT '0',
  `investee_suboption` int(3) NOT NULL DEFAULT '0',
  `cde_controlled` char(1) NOT NULL DEFAULT '',
  `related_entity` char(1) NOT NULL DEFAULT '',
  `religious` char(1) NOT NULL DEFAULT '',
  `federal_id` varchar(20) NOT NULL DEFAULT '',
  `federal_id1` varchar(20) NOT NULL DEFAULT '',
  `date_business_established` date NOT NULL DEFAULT '0000-00-00',
  `total_borrowers` varchar(20) NOT NULL DEFAULT '',
  `bprofile_id` int(4) unsigned NOT NULL DEFAULT '0',
  `bprofile_desc` varchar(100) DEFAULT NULL,
  `naics_code` varchar(6) NOT NULL DEFAULT '',
  `sic_code` varchar(4) NOT NULL DEFAULT '',
  `tax_status` int(3) NOT NULL DEFAULT '0',
  `minority_owned` char(1) NOT NULL DEFAULT 'N',
  `women_owned` char(1) NOT NULL DEFAULT 'N',
  `lowincome_owned` char(1) NOT NULL DEFAULT 'N',
  `total_gross_income` varchar(20) NOT NULL DEFAULT '',
  `lic_gross_income` varchar(20) NOT NULL DEFAULT '',
  `total_tang_prop` varchar(20) NOT NULL DEFAULT '',
  `lic_tang_prop` varchar(20) NOT NULL DEFAULT '',
  `total_service_provided` varchar(20) NOT NULL DEFAULT '',
  `lic_service_provided` varchar(20) NOT NULL DEFAULT '',
  `res_rent_income` varchar(20) NOT NULL DEFAULT '',
  `com_rent_income` varchar(20) NOT NULL DEFAULT '',
  `upload_status` char(1) NOT NULL DEFAULT 'N',
  `ins_date_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `fmail_id` int(8) NOT NULL DEFAULT '0',
  `status` char(1) NOT NULL DEFAULT 'Y',
  `impact_id` int(4) NOT NULL DEFAULT '0',
  `borrower_name` varchar(50) NOT NULL DEFAULT '',
  `fico_score` varchar(20) NOT NULL DEFAULT '',
  `gender` char(1) NOT NULL DEFAULT 'M',
  `eth_id` int(3) NOT NULL DEFAULT '0',
  `race_id` int(3) NOT NULL DEFAULT '0',
  `borrower_type` char(1) NOT NULL DEFAULT 'P',
  PRIMARY KEY (`rec_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.tlr_field_description_master
CREATE TABLE IF NOT EXISTS `tlr_field_description_master` (
  `tlr_id` int(4) NOT NULL DEFAULT '0',
  `group_id` int(4) DEFAULT NULL,
  `field_desc` varchar(400) DEFAULT '""',
  `field_name` varchar(100) DEFAULT '""',
  `table_name` varchar(100) DEFAULT '""',
  `status` varchar(4) DEFAULT 'Y',
  PRIMARY KEY (`tlr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.track_menu_master
CREATE TABLE IF NOT EXISTS `track_menu_master` (
  `menu_id` int(3) NOT NULL DEFAULT '0',
  `menu_name` varchar(30) NOT NULL DEFAULT '',
  `link` varchar(150) DEFAULT NULL,
  `menu_type` varchar(10) NOT NULL DEFAULT '',
  `group_head` int(3) DEFAULT NULL,
  `sub_group_head` int(3) DEFAULT NULL,
  `priority_id` int(4) NOT NULL DEFAULT '0',
  `width` int(3) NOT NULL DEFAULT '0',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`menu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Menu Master containing all menu informations';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.tracts_master
CREATE TABLE IF NOT EXISTS `tracts_master` (
  `tracts_id` varchar(20) NOT NULL DEFAULT '',
  `state` varchar(5) DEFAULT NULL,
  `county_name` varchar(250) DEFAULT NULL,
  `total_pop` varchar(50) NOT NULL DEFAULT '',
  `msa_code` varchar(50) NOT NULL DEFAULT '',
  `msa_name` varchar(60) DEFAULT NULL,
  `ia_qual` int(1) NOT NULL DEFAULT '0',
  `hz_qual` int(1) NOT NULL DEFAULT '0',
  `hz_type` int(1) NOT NULL DEFAULT '0',
  `bea_qual` int(1) NOT NULL DEFAULT '0',
  `nmtc_qual` int(8) NOT NULL DEFAULT '0',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`tracts_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Census Tract Number Master 2010 Table';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.tracts_master_2010
CREATE TABLE IF NOT EXISTS `tracts_master_2010` (
  `tracts_id` varchar(255) NOT NULL,
  `bea_qual` int(11) NOT NULL,
  `county_name` varchar(255) DEFAULT NULL,
  `hz_qual` int(11) NOT NULL,
  `hz_type` int(11) NOT NULL,
  `ia_qual` int(11) NOT NULL,
  `msa_code` varchar(255) NOT NULL,
  `msa_name` varchar(255) DEFAULT NULL,
  `nmtc_qual` int(11) NOT NULL,
  `state` varchar(255) DEFAULT NULL,
  `status` char(1) NOT NULL,
  `total_pop` varchar(255) NOT NULL,
  PRIMARY KEY (`tracts_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.tracts_master_old
CREATE TABLE IF NOT EXISTS `tracts_master_old` (
  `tracts_id` varchar(11) NOT NULL DEFAULT '',
  `state` char(2) DEFAULT NULL,
  `county_name` varchar(250) DEFAULT NULL,
  `total_pop` varchar(8) NOT NULL DEFAULT '',
  `msa_code` varchar(4) NOT NULL DEFAULT '',
  `msa_name` varchar(60) DEFAULT NULL,
  `ia_qual` int(1) NOT NULL DEFAULT '0',
  `hz_qual` int(1) NOT NULL DEFAULT '0',
  `hz_type` int(1) NOT NULL DEFAULT '0',
  `bea_qual` int(1) NOT NULL DEFAULT '0',
  `nmtc_qual` int(1) NOT NULL DEFAULT '0',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`tracts_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Census Tract Number Master Table';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.transaction_comparable
CREATE TABLE IF NOT EXISTS `transaction_comparable` (
  `trans_comp_id` int(8) NOT NULL DEFAULT '0',
  `qalicb_id` int(8) NOT NULL DEFAULT '0',
  `project_id` int(8) NOT NULL DEFAULT '0',
  `trans_type` varchar(15) NOT NULL DEFAULT '',
  `qlici_type` int(4) NOT NULL DEFAULT '0',
  `interest_rate_comp` int(8) NOT NULL DEFAULT '0',
  `interest_rate_other` text NOT NULL,
  `std_org_fee_comp` int(8) NOT NULL DEFAULT '0',
  `std_org_fee_other` text NOT NULL,
  `std_period_comp` int(8) NOT NULL DEFAULT '0',
  `std_period_other` text NOT NULL,
  `std_amort_comp` int(8) NOT NULL DEFAULT '0',
  `std_amort_other` text NOT NULL,
  `traditional_form_comp` int(8) NOT NULL DEFAULT '0',
  `traditional_form_other` text NOT NULL,
  `intrate_org` double(16,3) NOT NULL DEFAULT '-1.000',
  `br_intrate_org` char(2) DEFAULT NULL,
  `cmp_intrate_org` double(16,3) NOT NULL DEFAULT '-1.000',
  `br_alloc_agreement` char(2) DEFAULT NULL,
  `status` char(1) NOT NULL DEFAULT 'Y',
  `comp_int_rate` double(16,3) NOT NULL DEFAULT '-1.000',
  `std_origination_fee` double(20,2) NOT NULL DEFAULT '-1.00',
  `std_peri_int_only_pay` int(8) NOT NULL DEFAULT '-1',
  `std_amort_period` int(8) NOT NULL DEFAULT '-1',
  `tradi_form_collateral` char(2) NOT NULL DEFAULT '',
  `equity_product` char(2) NOT NULL DEFAULT '',
  `equity_terms_cond` char(2) NOT NULL DEFAULT '',
  `debt_equity_features` char(2) NOT NULL DEFAULT '',
  `sub_debt` char(2) NOT NULL DEFAULT '',
  `bm_int_rate` char(2) NOT NULL DEFAULT '',
  `low_std_org_fees` char(2) NOT NULL DEFAULT '',
  `long_std_prd_int` char(2) NOT NULL DEFAULT '',
  `long_std_amort_prd` char(2) NOT NULL DEFAULT '',
  `non_trad_form_collateral` char(2) NOT NULL DEFAULT '',
  PRIMARY KEY (`trans_comp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.transfer_fund_details
CREATE TABLE IF NOT EXISTS `transfer_fund_details` (
  `trans_fund_id` int(8) NOT NULL AUTO_INCREMENT,
  `cash_details_id` int(8) NOT NULL DEFAULT '0',
  `pf_id` int(8) DEFAULT '0',
  `transfer_id` int(8) DEFAULT '0',
  `trans_amount` double(20,2) NOT NULL DEFAULT '0.00',
  `transfer_date` date NOT NULL DEFAULT '0000-00-00',
  `type` char(5) DEFAULT NULL,
  `sys_date` date NOT NULL DEFAULT '0000-00-00',
  `cde_id` int(8) NOT NULL DEFAULT '0',
  `source_date` date NOT NULL DEFAULT '0000-00-00',
  `status` char(2) NOT NULL DEFAULT '',
  `inv_pf_id` int(8) NOT NULL DEFAULT '0',
  `investee_id` int(11) NOT NULL DEFAULT '0',
  `rqi_id` int(8) DEFAULT '0',
  PRIMARY KEY (`trans_fund_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.transfer_fund_master
CREATE TABLE IF NOT EXISTS `transfer_fund_master` (
  `transfer_id` int(8) NOT NULL DEFAULT '0',
  `cash_details_id` int(8) NOT NULL DEFAULT '0',
  `cde_id` int(8) NOT NULL DEFAULT '0',
  `alloc_year` varchar(4) NOT NULL DEFAULT '0',
  `transfer_amt` double(20,2) NOT NULL DEFAULT '0.00',
  `transfer_date` date NOT NULL DEFAULT '0000-00-00',
  `type` varchar(5) NOT NULL DEFAULT '',
  `disburse_cash_id` int(8) DEFAULT NULL,
  `bal_amt` double(20,2) NOT NULL DEFAULT '0.00',
  `trans_cap_name` varchar(100) NOT NULL DEFAULT '',
  `sys_date` date NOT NULL DEFAULT '0000-00-00',
  `status` char(2) NOT NULL DEFAULT '',
  `seq_id` int(8) DEFAULT '0',
  `investee_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`transfer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.trans_kicker_master
CREATE TABLE IF NOT EXISTS `trans_kicker_master` (
  `kicker_id` int(8) NOT NULL DEFAULT '0',
  `kicker_desc` varchar(60) NOT NULL DEFAULT '',
  `cdfi_code` varchar(20) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`kicker_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Interest Type Master';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.trans_map
CREATE TABLE IF NOT EXISTS `trans_map` (
  `org_id` int(8) NOT NULL DEFAULT '0',
  `cde_id` int(8) NOT NULL DEFAULT '0',
  `qalicb_id` int(8) NOT NULL DEFAULT '0',
  `project_id` int(8) NOT NULL DEFAULT '0',
  `trans_id` varchar(15) NOT NULL DEFAULT '',
  `customer_id` varchar(20) NOT NULL DEFAULT '',
  `system_date` varchar(50) DEFAULT NULL,
  `status` char(1) DEFAULT NULL,
  `investee_id` int(8) DEFAULT '0',
  `type` int(3) DEFAULT NULL,
  `client_id` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`org_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.trans_purpose_master
CREATE TABLE IF NOT EXISTS `trans_purpose_master` (
  `purpose_id` int(4) NOT NULL DEFAULT '0',
  `purpose_desc` varchar(90) NOT NULL DEFAULT '',
  `cdfi_code` varchar(20) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`purpose_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.trans_type_master
CREATE TABLE IF NOT EXISTS `trans_type_master` (
  `trans_id` int(3) NOT NULL DEFAULT '0',
  `trans_desc` varchar(30) DEFAULT '',
  `cdfi_code` varchar(20) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`trans_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Transaction Type Master';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.triggered_email_details
CREATE TABLE IF NOT EXISTS `triggered_email_details` (
  `triggered_email_details_id` int(8) NOT NULL AUTO_INCREMENT,
  `cde_id` int(8) NOT NULL,
  `duedate_id` int(8) NOT NULL,
  `due_date` varchar(10) NOT NULL DEFAULT '0000-00-00',
  `reminder_type` int(8) NOT NULL,
  `received_status` char(2) NOT NULL DEFAULT 'N',
  `received_reason` text,
  `received_updated_time` varchar(20) DEFAULT '0000-00-00 00:00:00',
  `status` char(2) NOT NULL DEFAULT 'Y',
  `subject` tinytext,
  `message` tinytext,
  `togtr` varchar(500) NOT NULL,
  `ccgtr` varchar(500) NOT NULL,
  PRIMARY KEY (`triggered_email_details_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.triggered_execute_details
CREATE TABLE IF NOT EXISTS `triggered_execute_details` (
  `triggered_execute_details_id` int(8) NOT NULL AUTO_INCREMENT,
  `triggered_email_details_id` int(8) NOT NULL,
  `triggered_reminder_date` varchar(25) NOT NULL DEFAULT '0000-00-00',
  `triggered_executed_time` varchar(20) NOT NULL DEFAULT '0000-00-00 00:00:00',
  `status` char(2) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`triggered_execute_details_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.triggered_reply_details
CREATE TABLE IF NOT EXISTS `triggered_reply_details` (
  `triggered_reply_details_id` int(8) NOT NULL AUTO_INCREMENT,
  `triggered_execute_details_id` int(8) NOT NULL,
  `replier_name` varchar(100) NOT NULL,
  `replier_email_id` varchar(200) NOT NULL,
  `reply_time` varchar(20) NOT NULL DEFAULT '0000-00-00 00:00:00',
  `reply_notes` text,
  `reply_as` char(2) NOT NULL DEFAULT '',
  `status` char(2) NOT NULL DEFAULT 'Y',
  `client_ip` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`triggered_reply_details_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.triggered_reply_file_details
CREATE TABLE IF NOT EXISTS `triggered_reply_file_details` (
  `triggered_reply_file_details_id` int(8) NOT NULL AUTO_INCREMENT,
  `triggered_reply_details_id` int(8) NOT NULL,
  `file_name` text NOT NULL,
  `file_content_type` varchar(100) DEFAULT NULL,
  `file_location` text NOT NULL,
  `file_org_name` text NOT NULL,
  `file_upload_time` varchar(20) NOT NULL DEFAULT '0000-00-00 00:00:00',
  `file_size` bigint(12) DEFAULT '0',
  `status` char(2) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`triggered_reply_file_details_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.triggermail_bcc
CREATE TABLE IF NOT EXISTS `triggermail_bcc` (
  `cde_id` int(5) NOT NULL DEFAULT '0',
  `status` varchar(2) DEFAULT 'D',
  PRIMARY KEY (`cde_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.triggermail_history
CREATE TABLE IF NOT EXISTS `triggermail_history` (
  `triggermail_history_id` int(8) NOT NULL AUTO_INCREMENT,
  `cde_id` varchar(10) NOT NULL,
  `subjects` text,
  `to_mail` text,
  `cc_mail` text,
  `system_date` varchar(20) NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`triggermail_history_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.trigger_bcc_email
CREATE TABLE IF NOT EXISTS `trigger_bcc_email` (
  `bccmail_id` int(5) NOT NULL DEFAULT '0',
  `email_id` varchar(50) DEFAULT '',
  `status` varchar(2) DEFAULT 'Y',
  PRIMARY KEY (`bccmail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.trigger_mail_cde
CREATE TABLE IF NOT EXISTS `trigger_mail_cde` (
  `serial_no` int(4) NOT NULL AUTO_INCREMENT,
  `cde_id` int(4) DEFAULT NULL,
  `status` char(2) DEFAULT NULL,
  PRIMARY KEY (`serial_no`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.upload_info
CREATE TABLE IF NOT EXISTS `upload_info` (
  `ftp_id` int(8) NOT NULL DEFAULT '0',
  `cde_id` int(8) NOT NULL DEFAULT '0',
  `group_id` int(8) NOT NULL DEFAULT '0',
  `table_id` int(8) NOT NULL DEFAULT '0',
  `doc_name` varchar(255) NOT NULL DEFAULT '',
  `file_name` varchar(100) NOT NULL DEFAULT '',
  `original_file_name` varchar(100) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `file_content_type` varchar(100) NOT NULL DEFAULT '',
  `file_location` varchar(100) NOT NULL DEFAULT '',
  `upload_date_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `sysdate` date NOT NULL DEFAULT '0000-00-00',
  `protected` char(1) NOT NULL DEFAULT '',
  `password` varchar(100) NOT NULL DEFAULT '',
  `status` char(3) NOT NULL DEFAULT '',
  `type_id` int(8) NOT NULL DEFAULT '0',
  `file_group_id` int(4) NOT NULL DEFAULT '0',
  `file_size` bigint(12) NOT NULL DEFAULT '0',
  `session_id` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`ftp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.upload_type_master
CREATE TABLE IF NOT EXISTS `upload_type_master` (
  `type_id` int(8) NOT NULL DEFAULT '0',
  `name` varchar(100) NOT NULL DEFAULT '',
  `type` char(3) NOT NULL DEFAULT '',
  `status` char(3) NOT NULL DEFAULT '',
  `menu_id` int(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.upload_user_activity
CREATE TABLE IF NOT EXISTS `upload_user_activity` (
  `activity_id` int(8) NOT NULL DEFAULT '0',
  `user_name` varchar(50) DEFAULT NULL,
  `ftp_id` int(8) DEFAULT NULL,
  `activity` varchar(50) DEFAULT NULL,
  `date_time` datetime DEFAULT NULL,
  PRIMARY KEY (`activity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.user_eligibility
CREATE TABLE IF NOT EXISTS `user_eligibility` (
  `s.no` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) DEFAULT NULL,
  `attempt_date` date DEFAULT NULL,
  `no_attempts` int(5) DEFAULT NULL,
  PRIMARY KEY (`s.no`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.user_map
CREATE TABLE IF NOT EXISTS `user_map` (
  `user_map_id` int(8) NOT NULL DEFAULT '0',
  `user_id` int(8) NOT NULL DEFAULT '0',
  `user_name` varchar(50) NOT NULL DEFAULT '',
  `group_id` int(3) NOT NULL DEFAULT '0',
  `system_date` date NOT NULL DEFAULT '0000-00-00',
  `cde_list` text NOT NULL,
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`user_map_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.user_menu
CREATE TABLE IF NOT EXISTS `user_menu` (
  `user_name` varchar(30) NOT NULL DEFAULT '0',
  `menu_id` int(3) NOT NULL DEFAULT '0',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`user_name`,`menu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Menu Master for a particular user';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.user_menus
CREATE TABLE IF NOT EXISTS `user_menus` (
  `user_name` varchar(30) NOT NULL DEFAULT '0',
  `menu_id` int(3) NOT NULL DEFAULT '0',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`user_name`,`menu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Menu Master for a particular user';

-- Data exporting was unselected.


-- Dumping structure for table cdesolution.user_rights
CREATE TABLE IF NOT EXISTS `user_rights` (
  `user_name` varchar(30) NOT NULL DEFAULT '',
  `group_id` int(3) NOT NULL DEFAULT '0',
  `view_rt` int(1) NOT NULL DEFAULT '0',
  `add_rt` int(1) NOT NULL DEFAULT '0',
  `edit_rt` int(1) NOT NULL DEFAULT '0',
  `delete_rt` int(1) NOT NULL DEFAULT '0',
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`user_name`,`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='User''s Menu i.e. user rights to view a menu';

-- Data exporting was unselected.


-- Dumping structure for procedure cdesolution.view_suball_test
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `view_suball_test`(IN `cdeId` VARCHAR(200), IN `optionType` VARCHAR(10), IN `testDate` VARCHAR(10), IN `qeiType` INT(2))
BEGIN
SELECT t1.qei_id,t1.test_date,t1.qei_amount,t1.current_qlici,t1.previous_qlici,t1.test_status,
t1.annual_year,t1.test_id,t1.project_fund,t1.op_fund,t1.lr_fund,t1.pf_percent,t1.op_percent,
t1.lr_percent,t1.qei_date,t1.cur_outs_balance,t1.cur_qcr_received,t1.pre_outs_balance,
t1.pre_qcr_received,t1.pre_test_id,t1.pre_detail_id,t1.pre_lr_fund,t1.cde_id, t1.fcos_fund,t1.fcos_percent,t1.pre_fcos_fund
 FROM 
(SELECT dd.qei_id,dt.test_date,dd.qei_amount,dd.current_qlici,dd.previous_qlici,
dd.test_status,dd.annual_year,dt.test_id,dd.project_fund,dd.op_fund,dd.lr_fund,
dd.pf_percent,dd.op_percent,dd.lr_percent,dd.qei_date,dd.cur_outs_balance,
dd.cur_qcr_received,dd.pre_outs_balance,dd.pre_qcr_received,dd.pre_test_id,
dd.pre_detail_id,dd.pre_lr_fund,dt.cde_id, dd.fcos_fund,dd.fcos_percent,dd.pre_fcos_fund   FROM direct_tracing_test dt, 
direct_tracing_detail dd WHERE dd.test_id=dt.test_id AND dd.status!='D' AND dt.status!='D' 
AND dt.cde_id IN (cdeId) AND dt.option_type=optionType 
AND IF(qeiType =1,dt.test_date =testDate,dt.test_date <=testDate)) 
AS t1 INNER JOIN (SELECT DISTINCT MAX(d.test_id) AS test_id FROM direct_tracing_test d, 
direct_tracing_detail d1 WHERE d.test_id=d1.test_id AND d.status !='D' 
AND d1.status!='D' AND d.cde_id IN (cdeId) AND d.option_type=optionType 
AND IF(qeiType =1,d.test_date =testDate,d.test_date <=testDate)
GROUP BY IF(qeiType=3,d.test_id,d.test_date)) AS t2 ON t1.test_id = t2.test_id ORDER BY t1.test_date DESC, t1.qei_date DESC;
END//
DELIMITER ;


-- Dumping structure for table cdesolution.yes_no_master
CREATE TABLE IF NOT EXISTS `yes_no_master` (
  `yes_no_id` char(2) NOT NULL,
  `yes_no_name` varchar(15) NOT NULL,
  `status` char(1) NOT NULL,
  `prefrence_order` int(11) DEFAULT NULL,
  PRIMARY KEY (`yes_no_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
