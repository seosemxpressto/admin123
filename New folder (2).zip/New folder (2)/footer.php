<?php
/**
 * The template for displaying the footer
 *
 * Contains footer content and the closing of the #main and #page div elements.
 *
 * @package WordPress
 * @subpackage Twenty_Fourteen
 * @since Twenty Fourteen 1.0
 */
?>

  
  
  <div id="contact-us-footer">
   <div id="footer-contant"><div id="copy-right" align="right">© 2014 RNK Projects. All Rights Reserved. </div>
  
   <div id="footer-right-logo"><span class="logo-design-text">Design</span><a href="#"><img src="http://testing.rocketdesign.in/rnkprojects/site/wp-content/uploads/2014/08/footer-logo_03.png" width="25" height="27" border="0" align="absmiddle" "/></a></div>
   </div><div style="clear:both;"></div> 
    
   
 </div>



	<?php wp_footer(); ?>
</body>
</html>