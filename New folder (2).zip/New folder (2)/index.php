<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme and one
 * of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query,
 * e.g., it puts together the home page when no home.php file exists.
 *
 * @link http://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Twenty_Fourteen
 * @since Twenty Fourteen 1.0
 */

get_header(); ?>
<style>
#bwg_container1_0 #bwg_container2_0 .bwg_title_spun2_0{
color: #fff !important;
    display: table-cell;
    font-family: erasmedium !important;
    font-size: 23px !important;
line-height:34px;
   
    height: inherit;
    padding: 10px !important;}</style>
<div style=" position: relative;
    z-index: -9;
    top: -86px;"><?php putRevSlider("slider") ?></div>
<?php
$args = array (
    'post_type'              => 'index',    
    'order'                  => 'ASC',
    'posts_per_page'         => '1',
);

// The Query
$query = new WP_Query( $args );

// The Loop
if ( $query->have_posts() ) {
    while ( $query->have_posts() ) {
        $query->the_post();

?>
  <div id="welcome_text" style="margin-top: -85px;" > <?php echo $query->post->post_content;?></div><?php }}?>
    
    <div id="our_expertise_main">
    <div align="center" class="we_are" id="our_expertise_top" style="color:#fff;">Our Expetise</div>
    
    <div id="our_expertise_bottom"><div id="our_expertise_inner">
    <div id="our-expetise1">
      <div align="center"><span><img src="<?php bloginfo( 'template_url'); ?>/images/img1.jpg" /><br />
        <span class="architecture">Architecture Planning</span></span></div>
    </div><div id="our-expetise1">
      <div align="center"><span><img src="<?php bloginfo( 'template_url'); ?>/images/img2.jpg" /><br />
        <span class="architecture">Turnkey Contracting</span></span></div>
    </div><div id="our-expetise1">
      <div align="center"><span><img src="<?php bloginfo( 'template_url'); ?>/images/img3.jpg" /><br />
        <span class="architecture">MEP Service</span></span></div>
    </div><div id="our-expetise1">
      <div align="center"><span><img src="<?php bloginfo( 'template_url'); ?>/images/img4.jpg" /><br />
        <span class="architecture">Interior Design & PMC</span></span></div>
    </div><div id="our-expetise1">
      <div align="center"><span><img src="<?php bloginfo( 'template_url'); ?>/images/img5.jpg" /><br />
        <span class="architecture">Brand Design</span></span></div>
    </div><div id="our-expetise1">
      <div align="center"><span><img src="<?php bloginfo( 'template_url'); ?>/images/img6.jpg" /><br />
        <span class="architecture">ELV Systems</span></span></div>
    </div><div style="float:left"></div>
    </div>
  </div>
</div>

<div id="blog-area1">
<div id="blog"><img src="http://testing.rocketdesign.in/rnkprojects/site/wp-content/uploads/2014/09/our_blog.jpg"><?php dynamic_sidebar( 'sidebar-11' ); ?></div>
<div id="facebook"><img src="http://testing.rocketdesign.in/rnkprojects/site/wp-content/uploads/2014/09/fb.jpg"><?php dynamic_sidebar( 'sidebar-12' ); ?></div>
<div id="twitter"><img src="http://testing.rocketdesign.in/rnkprojects/site/wp-content/uploads/2014/09/twitter.jpg"><?php dynamic_sidebar( 'sidebar-13' ); ?></div>
</div>
<div id="brand"><?php echo do_shortcode('[print_responsive_thumbnail_slider]');?></div>
<div id="footer">
  <div id="footer-contant">
<div id="footer-logo"><span><?php dynamic_sidebar( 'sidebar-14' ); ?></span>
</div>

<div id="footer-nav" class="nav-f"><?php dynamic_sidebar( 'sidebar-15' ); ?></div>
     
<div id="news-letter"><span class="news-l">Subscribe for Newsletter</span><br />
<form action="" method="get"><input name="" type="text" class="text-feild" /></form><br />
<div id="submit-b">submit</div>
</div>


<div id="adress">
<?php dynamic_sidebar( 'sidebar-16' ); ?>
                         
</div>


  </div> 

 

  <div style="clear:both;"></div></div>
<?php
//get_sidebar();
get_footer();
