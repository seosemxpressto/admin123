app.service('stubService', function() {
	
	this.source = "app.controller('previewCtrl', function($scope) {$scope.info = function (){alert('Test123');}});";
	
	this.data = {};
	
});