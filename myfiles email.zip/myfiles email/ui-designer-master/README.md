angular-ui-designer
==================

Create your angular bootstrap ui by drag and drop elements.

UI designer is an implementation of element-builder (https://github.com/wilmveel/element-builder) and makes use of element-service (https://github.com/wilmveel/element-service) to store the data.

This 100% angular base application can be used to create a user interface by drag and drop elements to the canvas. The jQuery ui library is used to make elements dragable and dropable. By clicking the elements you can make select them. This unique meganisme allows the user to select elements on different levels when they are stacked on each other.

An running example of the library can be found on http://willemveelenturf.nl/ui-designer/

The work is still in progress but pleas feel free to help and make this library better.

Wishlist
- Add more elements to the library

Contact
Willem Veelenturf
http://willemveelenturf.nl
willem.veelenturf@gmail.com