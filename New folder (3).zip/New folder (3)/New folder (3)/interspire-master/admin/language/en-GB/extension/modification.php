<?php
/**
 * @package		Interspire eCommerce
 * @copyright	Copyright (C) 2015 Interspire Co.,Ltd. All rights reserved. (Interspire.vn)
 * @credits		See CREDITS.txt for credits and other copyright notices.
 * @license		GNU General Public License version 3; see LICENSE.txt
 */

// Heading
$_['heading_title']     = 'Modifications';

// Text
$_['text_success']      = 'Success: You have modified modifications!';
$_['text_refresh']      = 'Please wait until the modification files created!';
$_['text_list']         = 'Modification List';

// Column
$_['column_name']       = 'Modification Name';
$_['column_author']     = 'Author';
$_['column_version']    = 'Version';
$_['column_status']     = 'Status';
$_['column_date_added'] = 'Date Added';
$_['column_action']     = 'Action';

// Error
$_['error_permission']  = 'Warning: You do not have permission to modify modifications!';
$_['error_remove']      = 'Warning: Failed to remove file/directory "%s" !';