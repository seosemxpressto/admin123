<?php
/**
 * @package		Arastta eCommerce
 * @copyright	Copyright (C) 2015 Arastta Association. All rights reserved. (arastta.org)
 * @license		GNU General Public License version 3; see LICENSE.txt
 */

// Text
$_['text_subject']  = '%s - Anmodning om nulstilling af adgangskode';
$_['text_greeting'] = 'En ny adgangskode blev anmodet fra %s administration.';
$_['text_change']   = 'For at nulstille din adgangskode, skal du klikke på linket nedenfor:';
$_['text_ip']       = 'Forespørgelsen kom fra følgende IP adresse: %s';