<?php
/**
 * @package		Arastta eCommerce
 * @copyright	Copyright (C) 2015 Arastta Association. All rights reserved. (arastta.org)
 * @license		GNU General Public License version 3; see LICENSE.txt
 */

// Heading
$_['heading_title']   = 'Tilladelse nægtet!';

// Text
$_['text_permission'] = 'Du har ikke tilladelse til at tilgå denne side, der henvises til systemadministratoren.';