<?php
/**
 * @package		Arastta eCommerce
 * @copyright	Copyright (C) 2015 Arastta Association. All rights reserved. (arastta.org)
 * @license		GNU General Public License version 3; see LICENSE.txt
 */

// Heading
$_['heading_title']         = 'Kunden Bonuspunkte Übersicht';

// Text
$_['text_list']             = 'Übersicht';

// Column
$_['column_customer']       = 'Kundenname';
$_['column_email']          = 'Email';
$_['column_customer_group'] = 'Kundengruppe';
$_['column_status']         = 'Status';
$_['column_points']         = 'Bonuspunkte';
$_['column_orders']         = 'Anz. Aufträge';
$_['column_total']          = 'Gesamt';
$_['column_action']         = 'Aktion';

// Entry
$_['entry_date_start']      = 'Beginn';
$_['entry_date_end']        = 'Ende';