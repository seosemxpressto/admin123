<?php
/**
 * @package		Arastta eCommerce
 * @copyright	Copyright (C) 2015 Arastta Association. All rights reserved. (arastta.org)
 * @license		GNU General Public License version 3; see LICENSE.txt
 */

// Text
$_['text_footer'] 	= '<i>Danke dass <a href="http://arastta.org" target="_blank">Arastta</a> verwendet wird. | Dt. Version von <a href="http://osworx.net" target="_blank">OSWorX</a></i>';
$_['text_version'] 	= 'Version %s';