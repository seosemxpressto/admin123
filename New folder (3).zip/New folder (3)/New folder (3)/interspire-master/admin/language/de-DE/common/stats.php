<?php
/**
 * @package		Arastta eCommerce
 * @copyright	Copyright (C) 2015 Arastta Association. All rights reserved. (arastta.org)
 * @license		GNU General Public License version 3; see LICENSE.txt
 */

$_['text_complete_status']   = 'Aufträge abgeschlossen'; 
$_['text_processing_status'] = 'Aufträge in Arbeit'; 
$_['text_other_status']      = 'Andere Statusse'; 