<?php
/**
 * @package		Arastta eCommerce
 * @copyright	Copyright (C) 2015 Arastta Association. All rights reserved. (arastta.org)
 * @license		GNU General Public License version 3; see LICENSE.txt
 */

// Heading
$_['heading_title']  = 'Seite nicht gefunden.';

// Text
$_['text_not_found'] = 'Die angeforderte Seite konnte leider nicht gefunden werden.<br />Sollte das Problem weiterhin bestehen, bitte die Shopverwaltung davon informieren (siehe Kontakt) - vielen Dank.';